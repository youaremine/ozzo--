<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
//   computed: {
//       key(){
//           return this.$route.id ? this.$route.name + new Date() : this.$route + new Date()
//       }
//   }
}
</script>
