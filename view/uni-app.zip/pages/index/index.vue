<template>
	<view class="page-index" :class="{'bgf':navIndex >0}">
		<!-- #ifdef H5 -->
		<view class="header">
			<view class="serch-wrapper flex acea-row row-between-wrapper">
				<view v-if="logoUrl" class="logo">
					<!-- <image v-if="!logoUrl" class="logo" src="/static/images/crmeb.png"></image> -->
					<image :src="logoUrl" mode=""></image>
				</view>
				<navigator url="/pages/columnGoods/goods_search/index" :class="logoUrl ? 'input' : 'uninput'" hover-class="none"><text class="iconfont icon-xiazai5"></text>
					搜索商品</navigator>
				<navigator class="btn" url="/pages/chat/customer_list/index?type=0" hover-class="none">
					<view class="iconfont icon-xiaoxi"></view>
					<text class="iconnum bg-color-red" v-if="userInfo.total_unread">{{userInfo.total_unread}}</text>
				</navigator>
			</view>
			<tabNav class="tabNav" :class="{'fixed':isFixed}" :tabTitle="navTop" @changeTab='changeTab'></tabNav>
			<!-- <tabNav class="tabNav" :class="{'fixed':isFixed}" :tabTitle="navTop" @changeTab='changeTab' @emChildTab='emChildTab'
			 @childTab='childTab'></tabNav> -->
		</view>
		<!-- #endif -->
		<!-- #ifdef MP -->
		<view class="mp-header">
			<view class="sys-head" view :style="{ height: statusBarHeight }"></view>
			<view class="serch-box" view style="height: 43px;">
				<view class="serch-wrapper flex">
					<view v-if="logoUrl" class="logo">
						<!-- <image class="logo" src="/static/images/crmeb.png"></image> -->
						<image :src="logoUrl" mode=""></image>
					</view>
					<navigator url="/pages/columnGoods/goods_search/index" :class="logoUrl ? 'input' : 'uninput'" hover-class="none"><text class="iconfont icon-xiazai5"></text>
						搜索商品</navigator>
					<!-- <navigator class="btn" url="/pages/customer_list/index?type=0" hover-class="none">
						<view class="iconfont icon-xiaoxi"></view>
						<text class="iconnum bg-color-red" v-if="userInfo.total_unread">{{userInfo.total_unread}}</text>
					</navigator> -->
				</view>
			</view>
			<tabNav class="tabNav" :tabTitle="navTop" @changeTab='changeTab'></tabNav>
		</view>
		<!-- #endif -->
		<!-- 首页展示 -->
		<view class="page_content" v-if="navIndex == 0" :style="{marginTop:mpHeight+'px'}">
			<!-- #ifdef MP -->
			<!-- <view class="mp-bg"></view> -->
			<!-- #endif -->
			<!-- banner -->
			<view class="swiper" v-if="imgUrls.length">
				<swiper indicator-dots="true" :autoplay="true" :circular="circular" :interval="interval" :duration="duration"
				 indicator-color="#E4E4E4" indicator-active-color="#E93323" previous-margin="40rpx" next-margin="40rpx" :current="swiperCur"
				 @change="swiperChange">
					<block v-for="(item,index) in imgUrls" :key="index">
						<swiper-item :class="{active:index == swiperCur}">
							<navigator :url='item.url' class='slide-navigator acea-row row-between-wrapper' hover-class='none'>
								<image :src="item.pic" class="slide-image"></image>
							</navigator>
						</swiper-item>
					</block>
				</swiper>
			</view>
			<!-- menu -->
			<view class='nav acea-row' v-if="menus.length">
				<block v-for="(item,index) in menus" :key="index">
					<view class="item" @click="goMenuDetail(item)">
						<view class='pictrue'>
							<image :src='item.pic'></image>
						</view>
						<view class="menu-txt area-row">{{item.name}}</view>
					</view>
				</block>
			</view>
			<navigator v-if="ad.home_ad_pic" class="ad" :url="ad.home_ad_url" hover-class="none">
				<image mode="" :src="ad.home_ad_pic"></image>
			</navigator>
			<!--秒杀-->
			<view class="main" v-if="spikeList.length > 0">
				<view class="seckill-count">
					<view class="spike-bd">
						<view class="title line1">限时秒杀</view>
						<view class="spike-distance">
							<text class="text bg-red">距结束</text>
							<countDown :is-day="false" :tip-text="' '" :day-text="' '" :hour-text="':'" :minute-text="':'" :second-text="' '"
							 :datatime="datatime"></countDown>
						</view>
						<navigator url="/pages/activity/goods_seckill/index" class="more-btn" hover-class="none">更多<text class="iconfont icon-jiantou"
							 hover-class='none'></text></navigator>
					</view>
					<view class="spike-wrapper">
						<scroll-view scroll-x="true" style="white-space: nowrap; display: flex" show-scrollbar="false">
							<navigator class="spike-item" v-for="(item,index) in spikeList" :key="index" :url="'/pages/activity/goods_seckill_details/index?id='+item.product_id+'&time='+item.stop+''"
							 hover-class='none'>
								<view class="img-box">
									<image :src="item.image" mode=""></image>
								</view>
								<view class="info">
									<view class="name line1">{{item.store_name}}</view>
									<view class="stock-box">
										<view class="grabbed" :style="'width:'+item.sales+';'"></view>
										<text class="stock-sales">{{item.sales}}</text>
									</view>
									<view class="price-box">
										<text class="price"><text>￥</text>{{item.price}}</text>
										<text class="old-price"><text>￥</text>{{item.ot_price}}</text>
									</view>
								</view>
							</navigator>
						</scroll-view>
					</view>
				</view>
			</view>
			<!-- 拼团 -->
			<view v-if="combinationList.length > 0" class="main">
				<view class="combination-count">
					<view class="spike-bd">
						<view class="title line1">拼团活动</view>
						<navigator url="/pages/activity/combination/index" class="more-btn" hover-class="none">更多<text class="iconfont icon-jiantou"
							 hover-class='none'></text></navigator>
					</view>
					<view class="combination_wrapper">
						<view class="spike-wrapper">
							<block class=" acea-row row-between-wrapper combination">
								<view class="combination-item" v-for="(item,index) in combinationList" :key="index" hover-class='none' @click="goCombinDetail(item)">
									<view class="info">
										<view class="price-box combination-price">
											<view class="name line1">{{item.product.store_name}}</view>
											<text class="price"><text>￥</text>{{item.price}}</text>
											<text class="gocom_btn">去拼团<text class="iconfont icon-jiantou"></text></text>
										</view>
									</view>
									<view class="img-box">
										<image :src="item.product.image" mode=""></image>
									</view>
								</view>
								<view v-if="combinationList.length == 1" class="combination-item" @click="goCombinDetail(combinationList[0])">
									<view class="info">
										<view class="price-box combination-price">
											<view class="name line1">{{combinationList[0].product.store_name}}</view>
											<text class="price"><text>￥</text>{{combinationList[0].price}}</text>
											<text class="gocom_btn">去拼团<text class="iconfont icon-jiantou"></text></text>
										</view>
									</view>
									<view class="img-box">
										<image :src="combinationList[0].product.image" mode=""></image>
									</view>
								</view>
								<view v-if="combinationList.length == 1" class="combination-item" @click="goCombinDetail(combinationList[0])">
									<view class="info">
										<view class="price-box combination-price">
											<view class="name line1">{{combinationList[0].product.store_name}}</view>
											<text class="price"><text>￥</text>{{combinationList[0].price}}</text>
											<text class="gocom_btn">去拼团<text class="iconfont icon-jiantou"></text></text>
										</view>
									</view>
									<view class="img-box">
										<image :src="combinationList[0].product.image" mode=""></image>
									</view>
								</view>
								<view v-if="combinationList.length == 2" class="combination-item" @click="goCombinDetail(combinationList[1])">
									<view class="info">
										<view class="price-box combination-price">
											<view class="name line1">{{combinationList[1].product.store_name}}</view>
											<text class="price"><text>￥</text>{{combinationList[1].price}}</text>
											<text class="gocom_btn">去拼团<text class="iconfont icon-jiantou"></text></text>
										</view>
									</view>
									<view class="img-box">
										<image :src="combinationList[1].product.image" mode=""></image>
									</view>
								</view>
							</block>
						</view>
					</view>
				</view>
			</view>
			<!-- #ifdef MP -->
			<!--直播-->
			<view class="main" v-if="liveList.length > 0">
				<view class="live-count">
					<view>
						<!-- 直播 -->
						<block>
							<view class="spike-bd">
								<view class="title line1">直播专场</view>
								<navigator url="/pages/activity/liveBroadcast/index" class="more-btn" hover-class="none">更多<text class="iconfont icon-jiantou"
									 hover-class='none'></text></navigator>
							</view>
							<view class="live-wrapper mores">
								<scroll-view scroll-x="true" style="white-space: nowrap; display: flex">
									<view class="item" v-for="(item, index) in liveList" :key="index">
										<navigator hover-class="none" :url="item.link">
											<view class="live-top" :style="'background:' + (item.live_status == 101 ? playBg : (item.live_status != 101 && item.live_status != 102) ? endBg : notBg) + ';'"
											 :class="item.live_status == 102 ? 'playRadius' : 'notPlayRadius'">
												<block v-if="item.live_status == 101">
													<image src="/static/images/live-01.png" mode=""></image>
													<text>直播中</text>
												</block>
												<block v-if="item.live_status == 103 && item.replay_status === 1">
													<image src="/static/images/live-02.png" mode=""></image>
													<text>回放</text>
												</block>
												<block v-if="(item.live_status != 101 && item.live_status != 102 && item.live_status != 103) ||  (item.live_status == 103 && item.replay_status == 0)">
													<image src="/static/images/live-02.png" mode=""></image>
													<text>已结束</text>
												</block>
												<block v-if="item.live_status == 102">
													<image src="/static/images/live-03.png" mode=""></image>
													<text>预告</text>
												</block>
											</view>
											<view v-if="item.live_status == 101 || item.live_status == 102" class="broadcast-time">{{ item.show_time }}</view>
											<image :src="item.share_img"></image>
											<!-- <view class="live-title">{{ item.live_status }}</view> -->
										</navigator>
									</view>
								</scroll-view>
							</view>
						</block>
					</view>
				</view>
			</view>
			<!-- #endif -->
			<!--预售-->
			<view class="main" v-if="presellList.length > 0">
				<view class="presell-count">
					<view class="spike-bd title-bd">
						<view class="title line1">预售专区</view>
						<navigator url="/pages/activity/presell/index" class="more-btn" hover-class="none">更多<text class="iconfont icon-jiantou"
							 hover-class='none'></text></navigator>
					</view>
					<view class="wapper_count">
						<view class="spike-wrapper">
							<scroll-view scroll-x="true" style="white-space: nowrap; display: flex" show-scrollbar="false">
								<navigator class="spike-item presell-item" v-for="(item,index) in presellList" :key="index" :url="'/pages/activity/presell_details/index?id='+item.product_presell_id"
								 hover-class='none'>
									<view class="img-box presell_imgBox">
										<image :src="item.product.image" mode=""></image>
										<view class="box_bg">火热预定中</view>
									</view>
									<view class="info">
										<view class="price-box presell-price">
											<text class="price"><text>预售价:￥</text>{{item.price}}</text>
											<view class="name line1">{{item.store_name}}</view>
										</view>
									</view>
								</navigator>
							</scroll-view>
						</view>
					</view>
				</view>
			</view>
			<!--助力-->
			<view class="main" v-if="assistList.length > 0">
				<view class="assist-count">
					<view class="spike-bd">
						<view class="title line1">助力活动</view>
						<view v-if="assistUserList.length > 0" class="activity_pic">
							<view v-for="(item,index) in assistUserList" class="picture">
								<span class="avatar" :style='"background-image: url("+item.avatar_img+")"'></span>
								<!-- <span v-else class="avatar" style="background-image: url('/static/images/f.png') center center"></span> -->
							</view>
							<text class="pic_count">{{assistUserCount}}人助力成功</text>
						</view>
						<navigator url="/pages/activity/assist/index" class="more-btn" hover-class="none">更多<text class="iconfont icon-jiantou"
							 hover-class='none'></text></navigator>
					</view>
					<view class="wapper_count">
						<view class="spike-wrapper">
							<scroll-view scroll-x="true" style="white-space: nowrap; display: flex" show-scrollbar="false">
								<view class="spike-item assist-item" v-for="(item,index) in assistList" :key="index" @click="handleAssist(item.product_assist_id)">
									<view class="img-box">
										<image :src="item.product.image" mode=""></image>
										<text class="participants">{{ item.user_count }}人参与</text>
									</view>
									<view class="assist-info">
										<view class="price-box presell-price">
											<view class="name line1">{{item.store_name}}</view>
											<text class="price"><text class="assist_price">助力价</text><text>￥</text>{{item.assistSku[0].assist_price}}</text>
										</view>
										<button class="initiate_btn">发起助力</button>
									</view>
								</view>
							</scroll-view>
						</view>
					</view>
				</view>

			</view>
			<view class="main">
				<!-- 热点菜单 -->
				<view class="hot-img" style="margin-top:20rpx">
					<navigator :url="item.url" class="item" v-for="(item,index) in hot" :key="index" hover-class="none">
						<view class="title area-row">{{item.title}}</view>
						<view class="msg area-row" :style="'color:'+item.color+';'">{{item.s_title}}</view>
						<view class="img">
							<image :src="item.pic" mode=""></image>
						</view>
					</navigator>
				</view>
				<!-- 品牌好店 -->
				<view class="explosion" v-if="brandList.length && hide_mer_status !=1">
					<view class="common-hd">
						<view class="title">品牌好店</view>
					</view>
					<view class="mer-box">
						<view class="mer-item" v-for="(item,index) in brandList" :key='index'>
							<view class="mer-hd" @click="goStore(item.mer_id)">
								<image :src="item.mer_banner"></image>
								<view class="mer-name">
									<image :src="item.mer_avatar"></image>
									<view class="txt line1">{{item.mer_name}}</view>
									<text v-if="item.is_trader" class="font-bg-red ml8">自营</text>
								</view>
							</view>
							<view class="pro-box">
								<navigator :url="`/pages/goods_details/index?id=${itemn.product_id}`" hover-class="none" class="pro-item" v-for="(itemn,indexn) in item.recommend"
								 :key='indexn' v-if="item.recommend.length<=3">
									<image :src="itemn.image" mode=""></image>
									<view class="price">
										<text>￥</text>{{itemn.price}}
									</view>
								</navigator>
							</view>
						</view>
						<view class="more-shop" @click="moreShop">
							<text>
								更多店铺
							</text>
							<text class="iconfont icon-xiangyou"></text>
						</view>
					</view>
				</view>
				<!-- 首页推荐 -->
				<view class="index-product-wrapper">
					<!-- 首发新品 -->
					<recommend :hostProduct="hostProduct" :indexP='true' :isLogin='isLogin'></recommend>
					<view class='loadingicon acea-row row-center-wrapper' v-if='hostProduct.length > 0 '>
						<text class='loading iconfont icon-jiazai' :hidden='hotLoading==false'></text>{{hotTitle}}
					</view>
				</view>
			</view>
		</view>
		<!-- 分类页 -->

		<view class="productList" v-if="navIndex>0" :style="'margin-top:'+prodeuctTop+'px;'">
			<view class="sort acea-row" :class="sortList.length ? '' : 'no_pad'" :style="{marginTop:sortMarTop+'px'}">
				<navigator hover-class='none' :url="'/pages/columnGoods/goods_list/index?id='+item.store_category_id+'&title='+item.cate_name"
				 class="item" v-for="(item,index) in sortList" :key="index">
					<view class="pictrue">
						<image :src="item.pic"></image>
					</view>
					<view class="text">{{item.cate_name}}</view>
				</navigator>
				<view class="item" @click="bindMore()" v-if="sortList.length">
					<view class="pictrues acea-row row-center-wrapper">
						<text class="iconfont icon-gengduo1"></text>
					</view>
					<view class="text" style="margin-top: 22rpx;">更多</view>
				</view>
			</view>
			<block v-if="sortProduct.length>0">
				<view class='list acea-row row-between-wrapper'>
					<navigator @tap="goDetails(item)" class='item' v-for="(item,index) in sortProduct"
					 :key="index">
						<view class='pictrue'>
							<image :src='item.image'></image>
						</view>
						<view class='text'>
							<view class='name line1'><text v-if="item.merchant.is_trader && item.product_type == 0" class="font-bg-red">自营</text>
							<span v-if="item.product_type != 0" :class="'font_bg-red type'+item.product_type">{{item.product_type == 1 ? "秒杀" : item.product_type == 2 ? "预售" : item.product_type == 3 ? "助力" : item.product_type == 4 ? "拼团" : ""}}</span>
							{{item.store_name}}</view>

							<view class="acea-row row-middle">
								<view class='money font-color-red'>￥<text class='num'>{{item.price}}</text></view>
								<text class="coupon font-color-red" v-if="item.issetCoupon">领券</text>
							</view>
						</view>
					</navigator>
					<view class='loadingicon acea-row row-center-wrapper' v-if='sortProduct.length > 0 || sortProductLoading'>
						<text class='loading iconfont icon-jiazai' :hidden='loading==false'></text>{{loadTitle}}
					</view>
				</view>
			</block>
			<block v-if="sortProduct.length == 0">
				<view class="noCommodity">
					<view class='pictrue' style="margin: 0 auto;">
						<image src='/static/images/noShopper.png'></image>
					</view>
					<recommend :hostProduct="hostProduct"></recommend>
				</view>

			</block>
		</view>
		<!-- #ifdef MP -->
		<authorize @onLoadFun="onLoadFun" :isAuto="isAuto" :isShowAuth="isShowAuth" @authColse="authColse" :isGoIndex="false"></authorize>
		<!-- #endif -->
	</view>
</template>

<script>
	var statusBarHeight = uni.getSystemInfoSync().statusBarHeight + 'px';
	let app = getApp();
	import {
		getUserInfo
	} from '@/api/user.js';
	import {
		getIndexData,
		getCoupons
	} from '@/api/api.js';
	// #ifdef MP-WEIXIN
	import {
		getTemlIds,
	} from '@/api/api.js';
	import {
		SUBSCRIBE_MESSAGE,
		TIPS_KEY
	} from '@/config/cache';
	import {
		getLiveList
	} from '@/api/store.js';
	// #endif

	import {
		getShare,
		follow,
		getconfig,
	} from '@/api/public.js';
	import {
		getSeckillIndexTime
	} from '@/api/activity.js';

	import goodList from '@/components/goodList';
	import promotionGood from '@/components/promotionGood';
	import couponWindow from '@/components/couponWindow';
	import {
		goShopDetail
	} from '@/libs/order.js'
	import {
		mapGetters
	} from "vuex";
	import tabNav from '@/components/tabNav.vue'
	import countDown from '@/components/countDown'
	import {
		getCategoryList,
		getProductslist,
		getProductHot,
		storeCategory,
		storeMerchantList,
	} from '@/api/store.js';
	import {
		getPresellList,
		getSeckillList,
		getAssistList,
		initiateAssistApi,
		assistUserData,
		getCombinationList
	} from '@/api/activity.js';
	import {
		openBargainSubscribe
	} from '@/utils/SubscribeMessage.js';
	import {
		setVisit,
		spread
	} from '@/api/user.js'
	import recommend from '@/components/recommend';
	// #ifdef MP
	import authorize from '@/components/Authorize';
	// #endif
	import {
		silenceBindingSpread
	} from '@/utils';
	import history from "@/mixins/history";
	import {
		toLogin
	} from '@/libs/login.js';
	import shareScence from "@/libs/spread";
	export default {
		computed: mapGetters(['isLogin', 'uid']),
		mixins: [history],
		components: {
			tabNav,
			goodList,
			promotionGood,
			couponWindow,
			countDown,
			recommend,
			// #ifdef MP
			authorize
			// #endif
		},
		data() {
			return {
				countDownHour: "00",
				countDownMinute: "00",
				countDownSecond: "00",
				datatime: '',
				ad: '',
				userInfo: '',
				loading: false,
				isAuto: false, //没有授权的不会自动授权
				isShowAuth: false, //是否隐藏授权
				statusBarHeight: statusBarHeight,
				navIndex: 0,
				navTop: [],
				subscribe: false,
				followUrl: "",
				followHid: true,
				followCode: false,
				logoUrl: app.globalData.site_logo,
				// logoUrl: "",
				imgUrls: [],
				hot: [],
				sortList: [],
				itemNew: [],
				menus: [],
				bastInfo: '',
				fastInfo: '',
				firstInfo: '',
				firstList: [],
				salesInfo: '',
				likeInfo: [],
				benefit: [],
				indicatorDots: false,
				circular: true,
				autoplay: true,
				interval: 3000,
				duration: 500,
				window: false,
				iShidden: false,
				navH: "",
				newGoodsBananr: '',
				couponList: [],
				lovely: [],
				spikeList: [], //秒杀
				liveList: [], //直播
				presellList: [], //预售
				assistList: [], //助力
				assistUserList: [], //已助力数据
				assistUserCount: '',
				combinationList: [],
				hotList: [{
					pic: '/static/images/hot_001.png'
				}, {
					pic: '/static/images/hot_002.png'
				}, {
					pic: '/static/images/hot_003.png'
				}],
				spikeList: [],
				bargList: [],
				ProductNavindex: 0,
				marTop: 0,
				datatime: 0,
				childID: 0,
				loadend: false,
				loading: false,
				loadTitle: '加载更多',
				sortProduct: [],
				where: {
					pid: 0,
					page: 1,
					limit: 6,
				},
				is_switch: true,
				hostProduct: [],
				hotPage: 1,
				hotLimit: 8,
				hotScroll: true,
				hotLoading: false,
				hotTitle: '加载更多',
				explosiveMoney: [],
				prodeuctTop: 0,
				pinkInfo: '',
				searchH: 0,
				isFixed: false,
				goodScroll: true, //精品推荐开关
				params: { //精品推荐分页
					page: 1,
					limit: 10,
				},
				tempArr: [], //精品推荐临时数组
				pageInfo: '', // 精品推荐全数据
				site_name: app.globalData.site_name, //首页title
				swiperCur: 0,
				brandList: [],
				d: '',
				h: '',
				m: '',
				s: '',
				sum_h: '',
				endBg: 'linear-gradient(#666666, #999999)',
				notBg: 'rgb(26, 163, 246)',
				playBg: 'linear-gradient(#FF0000, #FF5400)',
				hide_mer_status: 1,
				sortMarTop: 0,
				globalDatas: {},
				mpHeight: 0,
				currSpid: '',
				sortMarTop: 0,
				mer_location: "",
				share_title: ""
			}
		},
		/**
		 * 用户点击右上角分享
		 */
		// #ifdef MP
		onShareAppMessage: function() {
			let that = this;
			wx.showShareMenu({
				withShareTicket: true,
				menus: ['shareAppMessage', 'shareTimeline']
			})
			return {
				title: that.share_title,
				path: '/pages/index/index?spid=' + that.uid
			}
		},
		onShareTimeline: function() {
			let that = this;
			return {
				title: that.share_title,
				query: {
					spid: that.uid,
				},
				imageUrl: ''
			}
		},
		// #endif
		onLoad(options) {
			let that = this;
			if (options.spid) {
				that.currSpid = options.spid
				app.globalData.spid = options.spid;
			}
			// #ifdef MP
			if (options.scene) {
				let value = that.$util.getUrlParams(decodeURIComponent(options.scene));
				if (value.id) options.id = value.id;
				//记录推广人uid
				if (value.spid) {
					that.currSpid = value.spid
					app.globalData.spid = value.spid;
				}
			}
			// #endif
			shareScence(that.currSpid, that.isLogin)
			uni.getLocation({
				type: 'wgs84',
				success: function(res) {
					try {
						uni.setStorageSync('user_latitude', res.latitude);
						uni.setStorageSync('user_longitude', res.longitude);
					} catch {}
				}
			});

			// #ifdef MP
			// 获取小程序头部高度
			this.navH = app.globalData.navHeight;
			let info = uni.createSelectorQuery().select(".mp-header");
			info.boundingClientRect(function(data) {
				that.marTop = data.height
			}).exec()
			// #endif
			// #ifndef MP
			this.navH = 0;
			// #endif
			this.isLogin && silenceBindingSpread();

			// this.setVisit()
			Promise.all([this.getIndexConfig(), this.storeMerchant(), this.get_host_product(), this.getSpeckillCutTime(), this.getSpikeProduct(),
				this.getCombinationProduct(), this.getPresellProduct(), this.getAssistProduct(), this.getAssistUserCount(),
			]);
			// #ifdef MP
			this.getLiveList()
			// #endif
			if (this.isLogin) {
				this.getUserInfo();
				// #ifdef MP
				this.getHistory()
				// #endif
			};
		},
		onShow() {
			this.getConfig()
		},
		onReady() {
			let self = this
			// #ifdef MP
			setTimeout(res => {
				let info = uni.createSelectorQuery().select(".mp-header");
				info.boundingClientRect(function(data) { //data - 各种参数
					self.mpHeight = data.height
				}).exec()
			}, 800)
			// #endif
		},
		watch: {
			globalDatas(nVal, oVal) {
				// #ifdef H5
				this.ShareInfo(nVal)
				// #endif

			}
		},
		methods: {
			// 微信登录回调
			onLoadFun: function(e) {
				this.isShowAuth = false
			},
			setViewport(content) {
				const meta = document.querySelector('meta[name=viewport]');
				if (!meta) return;
				meta.setAttribute('content', content);
			},
			// 菜单详情
			goMenuDetail(item) {
				// let url = this.$util.stringIntercept(item.url, 0, "\?")
				if (item.url == '/pages/goods_cate/goods_cate') {
					let data = this.$util.stringIntercept(item.url, 1, "\?")
					data = this.$util.stringIntercept(data, 1, "\=")
					uni.setStorageSync('storeIndex', data);
					uni.switchTab({
						url: '/pages/goods_cate/goods_cate'
					})
					// try {

					// } catch (e) {}
				} else {
					uni.navigateTo({
						url: item.url
					})
				}
			},
			getConfig() {
				// 获取配置
				getconfig().then(res => {
					let self = this
					this.globalDatas = res.data
					this.logoUrl = res.data.site_logo
					this.site_name = res.data.site_name
					this.hide_mer_status = res.data.hide_mer_status
					this.mer_location = res.data.mer_location
					this.share_title = res.data.share_title
					uni.setNavigationBarTitle({
						title: self.site_name
					})
					uni.$emit('configData', res.data)
				}).catch(err => {})
			},
			// 分类页更多
			bindMore() {
				console.log(this.navTop[this.navIndex])
				try {
					uni.setStorageSync('storeIndex', this.navTop[this.navIndex].pid);
					uni.switchTab({
						url: '/pages/goods_cate/goods_cate'
					})
				} catch (e) {}
			},
			goDetails(item){
				goShopDetail(item, this.uid).then(res => {
				if (this.isLogin) {
						initiateAssistApi(item.activity_id).then(res => {
							let id = res.data.product_assist_set_id;
							uni.hideLoading();
							// #ifndef MP
							uni.navigateTo({
								url: '/pages/activity/assist_detail/index?id=' + id
							});
							// #endif
							// #ifdef MP
							openBargainSubscribe().then(res => {
								uni.hideLoading();
								uni.navigateTo({
									url: '/pages/activity/assist_detail/index?id=' + id
								});
							}).catch((err) => {
								uni.hideLoading();
							});
							// #endif					
						}).catch((err) => {
							uni.showToast({
								title: err,
								icon: 'none'
							})
						});
					} else {
						// #ifdef H5 || APP-PLUS
						toLogin();
						// #endif 
						// #ifdef MP
						this.$emit('isShowAuth', true);
						this.$emit('isAuto', true);
						// #endif
					}
				})		
			},
			// 进店
			goStore: function(id) {
				if (this.hide_mer_status != 1) {
					uni.navigateTo({
						url: `/pages/store/home/index?id=${id}`
					})
				}
			},
			/**
			 * 获取个人用户信息
			 */
			getUserInfo: function() {
				let that = this;
				getUserInfo().then(res => {
					that.userInfo = res.data
				});
			},
			// 品牌好店
			storeMerchant() {
				storeMerchantList({
					page: 1,
					limit: 3,
					is_best: 1
				}).then(res => {
					this.brandList = res.data.list;
				})
			},
			// 获取秒杀截止时间
			getSpeckillCutTime() {
				getSeckillIndexTime().then(res => {
					this.datatime = res.data.seckillEndTime;
				});
			},
			// 获取秒杀商品
			getSpikeProduct() {
				let that = this;
				getSeckillList({
					limit: 10
				}).then(res => {
					that.spikeList = res.data.list;
					that.spikeList.map((item) => {
						item.sales = item.stock === 0 ? '0%' : (item.sales * 100 / item.stock).toFixed(2) + '%'
					})
				}).catch((e) => {});
			},
			// #ifdef MP
			// 直播
			getLiveList() {
				let that = this;
				getLiveList({
					limit: 10
				}).then(res => {
					that.liveList = res.data.list;
					that.liveList.forEach((val) => {
						val.link = ((val.live_status == 103 && val.replay_status) || val.live_status === 101 || val.live_status ===
							102) ? 'plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=' + val.room_id : ''
					});

				}).catch((e) => {});;
			},
			// #endif
			// 拼团
			getCombinationProduct() {
				let that = this;
				getCombinationList({
					limit: 3
				}).then(res => {
					that.combinationList = res.data.list;
				}).catch((e) => {});
			},
			// 预售
			getPresellProduct() {
				let that = this;
				getPresellList({
					limit: 10
				}).then(res => {
					that.presellList = res.data.list;
				}).catch((e) => {});
			},
			// 助力
			getAssistProduct() {
				let that = this;
				getAssistList({
					limit: 10
				}).then(res => {
					that.assistList = res.data.list;
				}).catch((e) => {});
			},
			// 获取已助力成功数据
			getAssistUserCount() {
				let that = this;
				assistUserData().then(res => {
					that.assistUserCount = res.data.count;
					that.assistUserList = res.data.list;
				}).catch((e) => {});
			},
			handleAssist(id) {
				if (this.isLogin) {
					initiateAssistApi(id).then(res => {
						let id = res.data.product_assist_set_id;
						uni.hideLoading();
						// #ifndef MP
						uni.navigateTo({
							url: '/pages/activity/assist_detail/index?id=' + id
						});
						// #endif
						// #ifdef MP
						openBargainSubscribe().then(res => {
							uni.hideLoading();
							uni.navigateTo({
								url: '/pages/activity/assist_detail/index?id=' + id
							});
						}).catch((err) => {
							uni.hideLoading();
						});
						// #endif					
					}).catch((err) => {
						uni.showToast({
							title: err,
							icon: 'none'
						})
					});
				} else {
					// #ifdef H5 || APP-PLUS
					toLogin();
					// #endif 
					// #ifdef MP
					this.isAuto = true;
					this.$set(this, 'isShowAuth', true);
					// #endif
				}
			},
			// swiper
			swiperChange(e) {
				// this.swiperCur = e.detail.current
				let {
					current,
					source
				} = e.detail
				if (source === 'autoplay' || source === 'touch') {
					//根据官方 source 来进行判断swiper的change事件是通过什么来触发的，autoplay是自动轮播。touch是用户手动滑动。其他的就是未知问题。抖动问题主要由于未知问题引起的，所以做了限制，只有在自动轮播和用户主动触发才去改变current值，达到规避了抖动bug
					this.swiperCur = e.detail.current
				}
			},
			// 记录会员访问
			setVisit() {
				setVisit({
					url: '/pages/index/index'
				}).then(res => {
					console.log(res)
				})
			},
			// 导航分类切换
			changeTab(e) {
				let self = this
				if (this.navIndex == e.index) return
				this.navIndex = e.index;
				if (e.index > 0) {
					storeCategory({
						pid: e.pid
					}).then(res => {
						this.sortList = res.data.length > 9 ? res.data.splice(0, 9) : res.data;
						if (this.sortList.length > 0) {
							this.where.pid = e.pid;
							this.where.page = 1;
							this.loadend = false;
							this.loading = false;
							this.sortProduct = [];
							this.get_product_list();
						}
					});
					// #ifdef MP
					setTimeout(res => {

						let info = uni.createSelectorQuery().select(".mp-header");
						info.boundingClientRect(function(data) { //data - 各种参数
							self.sortMarTop = data.height + 10
						}).exec()
					}, 0)
					// #endif
					// #ifdef H5
					self.sortMarTop = 10
					// #endif	
				}
			},
			//分类产品
			get_product_list: function() {
				console.log(123);
				let that = this;
				// if (!that.loadend) return;
				if (that.loading) return;
				that.loading = true;
				that.loadTitle = '';
				getProductslist(that.where).then(res => {
					let list = res.data.list;
					let productList = that.$util.SplitArray(list, that.sortProduct);
					let loadend = list.length < that.where.limit;
					that.loadend = loadend;
					that.loading = false;
					that.loadTitle = loadend ? '已全部加载' : '加载更多';
					that.$set(that, 'sortProduct', productList);
					that.$set(that.where, 'page', that.where.page + 1);
				}).catch(err => {
					that.loading = false;
					that.loadTitle = '加载更多';
				});
			},
			/**
			 * 获取我的推荐
			 */
			get_host_product: function() {
				let that = this;
				let num = that.hotLimit
				if (!that.hotScroll) return;
				if (that.hotLoading) return;
				that.hotLoading = true;
				that.hotTitle = '';
				getProductHot(
					that.hotPage,
					that.hotLimit,
				).then(res => {
					let list = res.data.list;
					let productList = that.$util.SplitArray(list, that.hostProduct);
					let hotScroll = list.length <= num && list.length != 0;
					that.hotScroll = hotScroll;
					that.hotLoading = false;
					that.hotTitle = !hotScroll ? '已全部加载' : '加载更多';
					that.$set(that, 'hostProduct', productList);
					that.$set(that, 'hotPage', that.hotPage + 1);
				});
			},
			// 首页数据
			getIndexConfig: function() {
				let that = this;
				getIndexData().then(res => {
					that.$set(that, "imgUrls", res.data.banner);
					that.$set(that, "menus", res.data.menu);
					that.$set(that, "hot", res.data.hot);
					that.$set(that, "ad", res.data.ad);
					res.data.category.unshift({
						'cate_name': '首页'
					})
					that.$set(that, "navTop", res.data.category);


					that.lovely = res.data.lovely
					that.$set(that, "pageInfo", res.data)
					that.$set(that, "likeInfo", res.data.likeInfo);
					that.$set(that, "benefit", res.data.benefit);
					that.explosiveMoney = res.data.explosive_money
					// #ifdef H5
					that.subscribe = res.data.subscribe;
					// #endif
					// 小程序判断用户是否授权；
					// #ifdef MP
					uni.getSetting({
						success(res) {
							if (!res.authSetting['scope.userInfo']) {
								that.window = that.couponList.length ? true : false;
							} else {
								that.window = false;
								that.iShidden = true;
							}
						}
					});
					// #endif
					// #ifndef MP
					if (that.isLogin) {
						that.window = false;
					} else {
						that.window = that.couponList.length ? true : false;
					}
					// #endif
				})
			},
			// 砍价详情
			bargDetail(item) {
				if (!this.isLogin) {
					// #ifdef H5
					uni.showModal({
						title: '提示',
						content: '您未登录，请登录！',
						success: function(res) {
							if (res.confirm) {
								uni.navigateTo({
									url: '/pages/users/login/index'
								})
							} else if (res.cancel) {}
						}
					})
					// #endif
					// #ifdef MP
					this.$set(this, 'isAuto', true);
					this.$set(this, 'isShowAuth', true);
					// #endif
				} else {
					uni.navigateTo({
						url: `/pages/activity/goods_bargain_details/index?id=${item.id}&bargain=${this.uid}`
					})
				}
			},
			// 授权关闭
			authColse: function(e) {
				this.isShowAuth = e
			},
			// 首发新品详情
			goDetail(item) {
				if (item.activity && item.activity.type === "2" && !this.isLogin) {
					// #ifdef H5
					uni.showModal({
						title: '提示',
						content: '您未登录，请登录！',
						success: function(res) {
							if (res.confirm) {
								uni.navigateTo({
									url: '/pages/users/login/index'
								})
							} else if (res.cancel) {}
						}
					})
					// #endif
					// #ifdef MP
					this.$set(this, 'isAuto', true);
					this.$set(this, 'isShowAuth', true);
					// #endif
					return
				} else {
					goShopDetail(item, this.uid).then(res => {
						uni.navigateTo({
							url: `/pages/goods_details/index?id=${item.id}`
						})
					})
				}
			},
			// 分类详情
			godDetail(item) {
				uni.navigateTo({
					url: `/pages/goods_details/index?id=${item.id}`
				})
			
			},
			//拼团详情
			goCombinDetail(item) {
				uni.navigateTo({
					url: `/pages/activity/combination_details/index?id=${item.product_group_id}`
				})
			
			},
			countTime: function() {
				// 获取当前时间
				var date = new Date();
				var now = date.getTime();
				//设置截止时间
				var endDate = new Date("2020-10-22 23:23:23");
				var end = endDate.getTime();
				//时间差
				var leftTime = end - now;
				//定义变量 d,h,m,s保存倒计时的时间
				if (leftTime >= 0) {
					this.d = Math.floor(leftTime / 1000 / 60 / 60 / 24);
					this.h = Math.floor(leftTime / 1000 / 60 / 60 % 24);
					this.m = Math.floor(leftTime / 1000 / 60 % 60);
					this.s = Math.floor(leftTime / 1000 % 60);
					this.sum_h = this.d * 24 + this.h
				}
				// console.log(this.h)
				// console.log(this.m)
				// console.log(this.s)
				// console.log(this.s);
				//递归每秒调用countTime方法，显示动态时间效果
				setTimeout(this.countTime, 1000);
			},
			//#ifdef H5
			ShareInfo(datas) {
				let data = this.storeInfo;
				let href = location.href;
				if (this.$wechat.isWeixin()) {
					if (this.isLogin) {
						href = href.indexOf("?") === -1 ? href + "?spid=" + this.uid : href + "&spid=" + this.uid;
					} else {
						href = href
					}
					let configAppMessage = {
						desc: datas.share_info,
						title: datas.share_title,
						link: href,
						imgUrl: datas.share_pic
					};

					this.$wechat.wechatEvevt([
						"updateAppMessageShareData",
						"updateTimelineShareData",
						"onMenuShareAppMessage",
						"onMenuShareTimeline"
					], configAppMessage).then(res => {
						console.log(res, '=============================>>WXAPI');
					}).catch(err => {
						console.log(err);
					})

				}
			},
			//#endif
			moreShop() {
				uni.navigateTo({
					url: `/pages/store/shopStreet/index`
				})
			},
		},
		mounted() {
			let self = this
			// #ifdef H5
			// 获取H5 搜索框高度
			let appSearchH = uni.createSelectorQuery().select(".serch-wrapper");
			appSearchH.boundingClientRect(function(data) {
				self.searchH = data.height
			}).exec()
			// #endif
		},
		// 滚动到底部
		onReachBottom() {
			console.log('到底了')
			if (this.navIndex == 0) {
				// 首页加载更多
				this.get_host_product();
			} else {
				// 分类栏目加载更多
				if (this.sortProduct.length > 0) {
					this.get_product_list();
				} else {
					this.get_host_product();
				}
			}
		},
		// 滚动监听
		onPageScroll(e) {
			// #ifdef H5
			let self = this
			if (e.scrollTop >= self.searchH) {
				self.isFixed = true
			} else {
				self.isFixed = false
			}
			// #endif
		}
	}
</script>
<style>
	page {
		display: flex;
		flex-direction: column;
		height: 100%;
		/* #ifdef H5 */
		background-color: #fff;
		/* #endif */

	}
</style>
<style lang="scss">
	.area-row {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		display: block;
		width: 100%;
		text-align: center;
	}

	.seckill-count,
	.assist-count {
		background-color: #fff;
		margin-bottom: 20rpx;
		border-radius: 16rpx;
		padding: 20rpx 0 26rpx 20rpx;
		box-shadow: 4rpx 2rpx 12rpx 2rpx rgba(0, 0, 0, 0.03);
	}

	.assist-count {
		padding: 20rpx 0 26rpx 0;
	}

	.wapper_count {
		padding: 0 0 26rpx 20rpx;
	}

	.presell-count {
		background-color: #fff;
		margin-bottom: 20rpx;
		border-radius: 16rpx;
		box-shadow: 4rpx 2rpx 12rpx 2rpx rgba(0, 0, 0, 0.03);
	}

	.spike-bd {
		margin-bottom: 20rpx;
		border-radius: 16rpx;
		padding-left: 20rpx;
		display: flex;
		position: relative;

		&.title-bd {
			margin-bottom: 0;
			padding: 30rpx 0 20rpx 20rpx;
			border-radius: 16rpx 16rpx 0 0;
			background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAsYAAABmCAMAAAD/NadAAAAAilBMVEX5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv5fjv9hz39hTj9xEv9vUj9tkT9vUj8nDb8ljL8qzv8ozf8sED8s0H+yU/9uET9pz78ojr8qTv8nTP8qz39rkP8iDn8kS/9hDb8hjj7gjn9rUD9u0j8nDT8lzL9uEn8kzL8jjRQ3NiJAAAALnRSTlMCKjISBg0KFxstICYkHV9dgYaGgqKigoWGgoCBoqKGhoWiRqNYUTuVbZCYVIFzOhZmRAAAEHBJREFUeNrsmOt60zAMhpP+y1rK2kLHBnQQemJl93972K7kt5ooKX02Gpi/NLGskyXnw09Y9dXi0wE+Z7wzeH+AbxkP415h1a4HBa8F1caQOP6g8QGTu3n8Y9wfrNpBwWtCNZlMNobIkccQues4hsiP436gHMOvENUkYbP5FZGPnsb2PH7fm2+KZVuO4VcJofFkOhUqd30e++O4J98Uy3IMv15kGk+mEZvNMR53fVWML4i35RR+5RAaQ+Tph81m8+fH8ffxiSiHcAF4ThrDYyFyQOYyLP4tjx/joSi/KMYhCUFK04BkS0OEitFIhDiO5ZnuCJRZXxhc4Gk8hcSCxSJwGRpb2P/kPbwVRMICISl6KyB74IkX02X7vzO4eYYwlD3CixQDjTmPIfKXRUA4mDvP48e3fwvL1n4Hn70vf56kZ3xI+E/L/rOKobE5j5XIiw+LjO/fvz98PkJjDuMXxHJ1/gncnOH2kkxo+pKoGfT330Hj53aGyn8bm/N4Ec7jLwvFTUBk8wNEftHDGPq2633JTTMQIUgyb5hHW9Ts9bRJYKNqDQyD6CQ2wLhFRXwSYFOkS7VUo7cNzPVLNFG5oVwFMXSjtRLNtkgVkoHNEEmLwSqqJOqNB24Ipj1tQR1UIcGaWBvK5oZNlyklUMBeLxMSm41GY2icAY+/BEBjxf39faRzwIsdxss9e9eQAqT+4JcK1tH5sF/h0iekMe8ZBmYSZ5kKcEwDklipASMCwZqMNamCeuUGxJgVZXDrCa8ABTJFAQGNP5JM6cMtKRkDbMIBMa4DkquMZN+FiX9C4wk8hsgwGR6DQOhl265Wy+UzUHfVCnkbA1pnm2HjgAkMoE8GgJbc1osZmfk5NrAsviyCEYk1mJHBAh6Yy7ZLoN8gga+GIvzOEIAPgUgE4EnJJAGuQJMGO04uB77QGCIDWOxofG/wY8zxMFiv1+0eq4ilIlNVsEoQ17Wcug500w1DgKPMhWXd2bF7inf4I5zYFESy9DoVRJ8OdoIaOjqAnV59vCMUWM9ugV1ht6DxDBqf8F1haDxoCgouA38az6b+8xgeRyrP5zcZ0LhtCgouBWgMjy2gsX5ZBBq7A3ncFBRcDp7Gs1kHj+15nJj82NRNE+66DmMUgpRUqk4KuURTixBH8SKGFAHqrYFiEWXMQA7111yaAWUK0GjWJNourOWoMzVj1vKoLmvjpVOEZJR0ZNOMtKE7WuuAo1pkSrss27hVeT9pRK6dhWBcNS3eNQ8KTnMapQvTmmmHzdMENM+LklWoCw+hcSePvygyjeHxj3Wdl00SAjMkfJ0XYG9RodcbwAoHnBs0DscLOe6Sd9j3Z10bBGcEZt7VCXNBt9gQ4CzsrhPgF+0h+nYYUTsDYB2XzEso/LS6vr7OJJ5EGs8MjW8NkeeBx3NzGrd1QcHFEWkMkROmER+nCbcRH+ZzpbHgRrGqCwoujypwOFzX8Dgg0fhjIHDkcTyP54HI4XpK5PtxXVDQA+xP48Tl2QE+JkxvBfMD3KQrMbmwuKAfqK4zJgdEDodxwG3GAYtlCGNhcUFPEGgMnvL4dhquPdxpXFhc0B8EGt/9ksbyXcF5bHFTWFzQH1R3kcWAj2NPY/NlUf5GUdAfRBrfOR53E7mt6+Ew3OEXxzDoKNIQc5CSdxpEL+F7ELR3I3FCnrOI3qKsRcs6sj7LEakLpDmWOIabUO1F1sU/3KKlXJrUmkxBMqXehByYbnEnS5LFJlCtDlJYdrGt46ej+KCVGVm0Da0WewTvwxRuZ1pLBMFao0jsikkqtwSzA5qLF2heQnV3Do+3g2FBQX8QaQyLT+TxuB4WFPQI1Z3A8fg4kdthwaUwGhY4RBoDeAwsj+e3f/UoPvGt/Wurjl4sDQYmOvao8mdfBxrbT2RY/ORE3q7NcqOhXAHD9JMa4uiLSb45JCUYyS1mcVGIGiVgsbi4eo1InFOhkxApjpySgiWxulq40489iCJx2iFWagqjzG0q8ceR8miatnjgiH9IgiWLvCDK4BWSyUhiIIhekfVOWh2tOocRlyQCaJxd1HIpPGv0B40tkf1xnGi8bUcR9J0AiYExoLAiEwQvocpvGPYbOI03nwXf2GlhJ7rZAVmb9FsF0OtT+YXFjRhdrZic6GOcTDJvcqrzt9BTRmjsPytgsh7IkcQFBX2EpfHv/vI2LiQu6Cuq3RYOxwvMwMftrhkVFFwIV500Ho0Gh0w+hH5YbHeDq5Tr6irdSUq/vIDIaVBb8hXpTVQlxzhmhwDNgTal0EwSlM1ikbm4EifOqLKcLBSEXcqmvHgToc3hKz/y7x8k1DroVX6kFRWLSyeUHyUSi91uGZkkj/EX8BZEz5AjWDYNakCZeyPbYTixVBIFkmhSOtW00jMzdht/erc7lllVJZe6VSpbIkcKt/WVgj5QIfAE2JA7oB1a5zeIsNEWYOSjwOpaYRFbzPFgHthJgqNbxO8jkmnK2xS8EvCGvA6Yjrpg9ApKOwNdbEDwexUeRx1yRxW6Qbvbbbfb64Qg7HbtYHRVUNB/VFcFBf88Co0L/gP8ZLfOlpwGYiiAuirApKia//9dEkXi0AinsXmACX3t2FquVjfL7Ri/3+73+zOkvB62hysQvoe/8C4mxEwThrSVOjghk7/T0oActkwmOKP0mRQlcDMyiPoMWYkcfQjRyv2SCVEpNaQKrsbSCdUEupL2XdXaTFlNSixxEpkmLcgayaBQhFnvI5iumjJp5UKrJowWiZJW/OxSAF/+tJWc7X0fX4lzAq3rTGxYmNMGeObEeSwZ7JAfkCaNxLeYQ51zK4Z59HkexkmaGelgX1wUQOzY3hcWPjy266/tYaakoZN5iNcdWlduzGsobKG3DHTlqBFCh1aLgg80ORlBNTkbNypGVX6DIcSdEkhlrabQxPCJtFMuqgZEdnD0D2NO6yulplQYRT7QTjxYCUCzcHVD3O5y4lFcV+QBA7+yxbsTZWMkYBKYedTTZMoUbyo5ITDsZgi7BHUTAY+2876BhVfeeIUw20CkEiv+OfiNY2+mJdt2FbAvugXW9jgxTYPixWNVjhQnOXqnq7ddFxY+PNYxXngBrGP8b+PtVMx/h434FleJVKt5I7xRQHA8PeLik5lI+oVHolaFpA4ikhb2G9Ftl5H7iBwqtGYoEjRin8crwNF6cEHoZvDr/D45uoturL0hERMtJTNKU/NB16hjPPaIsmsmPGUR55T51akHY+bu9iIfLHCilXkB+qnMvx9z6qv82ZAHet2hbdO0jC98iq9v6xSfOcXtdeY6oO7Zt9LjfcdbsvxzUfcwIi0vSfyzhZvspGTCfAhtI5Db7MVQUx1R2jGYUGztZZwaMgh5YOCINXWFZCuKW4VmbE+4zGNrsqPcXcqFVXlt+gTl5U4HX3pUMRxjtr7/3w56onqtaCQrCIekYdZ5+9u4cL3cHvdfIlTalfKocCk3TuSoMNygXpMhQWQdmfSWB0kOHAGX+qA/R+EYN9gIF1Rhgkw8ykI9cDxy4vs1Rtmbj6ACqlf6TSMsh/OJcqtluEadMvhdrWQooTOb4itjLvJa7CyZTaZd18qB4kOEfeUbjWHjAeChzujeM87cTyd6MXf2nIaCISbvWXdUmMT1ehNoZF7hPC5nqPY7H6oTZJh/RQ8O2GwJ4dBA7unUNICza9Q8aKib9+kUoCM2ao/2Bh3tk2CS5UD7vtPx02vLTZjvkWhRc8z6ZHFvhw4OZU5TpMRS5qXOj8o8B/p5CubZP+WdMuecX6IknXM+6bwgAvLAwmTshj1sb5d01htZ+qIEK66HWJEXqxEh7FLPjIoE8XsIiZSKXQYPDu0oGFcwtKcZi5Sjqleax2DjNJzitUpLA3LYcsa2VH0Gpc2Fp6cMCVmJvTMStLhkQlRKDakqb/aUTqgm0JW0b9VwZLMYNN/RLBZrzbU/jWyXRNCIADv++ljPyd7U6g4oJAm8APDnjEGk8c5S5gJ7256IQKGK2YdqdMCQDWW6X6q5pi356kDrDlBpcmamGVi3yJYZm7x38dN2Qjia1fJdT7v57eYo0/614JoN7Kg0bze0Abs6n6pTOr2GKe5k8B2HHNOWOofyxIGAM9n3DkfebefAk6G5aZ4wz2VdVMK5v45lnFN8MqBPTMy87AfbmQ81/0C+b2kn4CjPgPPnfx2f7rQSbMci4/fP4e3sH8Q/pMCJM3gu01+bYV7pb3awXRYWPjzWMV54AaxjvPACuB/jz59vj/jFMy1x3y7ecCQdkhYSZj7ZhbEDk25CQc/26J7xRlJLFs1jdbAi6CsERlXZ2nCaopKtGUMGAJv0ZbpTg3L21ZHiV/rAkkvCqj7GkYj23ldg6D6CtZRQbUXZvv/t7grku5TQI093JsHrLqFg8YsIORQOUJemmY4YhzYqZJYkpahMp14kwCA3rkE5HtUURMjyydC8CZDTqVnY/3q1Y3OyNaTPuoURmTWNxV1PSojKqNMOQU+N344T//Z5YeHDYx3jhRfAOsYLL4B1jBdeAOsYL7wAdo7xly/5+nJ/lpGz9JBS8crguO7IJPSBJZeEVX2MIxGTgaagFlKByJz+EqqtG7SkxyD0XWRpzNAaLWtgIshra5yslLJEIWmFkERacgTKg1rr0KNilBxYCrsGuhQ01JEFTgkPR1vWFpsIhC3kMDF6Q64+hHznUuMGqA+c0VWkjMxDafUwBFDyRFUL6mSk0Wg8GaoBxXB9PJy01/Q8YgXre9T7G6TmzT4xtBuZlTMwg47z6MrWNplkH9CIArDGz9+7tG3fgWhM+ZQfhUgj7/ZlYeHDYx3jhRfAOsYLL4Djx/jTDyIFmPHZ58nP41NcJ0owEk83er577zmPYuhGIxCbg2GuE+dftnMpf7hXTMf4U106cg3CjpcVo18YYp6kwmNoXT1tB6tnZBTTgx2TlsTV3Hss6RQZSralHKnO1SnEUcPmRukX1zNKk3tTdkXjFUOIZ+tW6u1pj8/7n8w2jZmlYpgbDTVt4NicR9KdKup1vINjlFE78TmJf3R50A4XGxlbmsqcd1gfdOb7L5BaxpXVHoQEI2OTHOnLEsQMyhhKPStdmdMaKfhCTBq6cSUoWzJ1Nc6fuvj2JWSsgLGIqcv0PZm5FSpahgrjSzH70rKsVsM8brca0ub9gV0MljBWRVvRppY15Avbrm3YFIPzVnYkPaRXrTu2TxB2h4waEiADEwdZnr2U7NydMmE0lX0aSLcDZuETOM7QSpIONC/FDqnXnGUkk8DSwN9E2urknTzcE643DuB6bJ8WFj481jFe+NY+GeRaCMMw0Pc/9ZeQ/Ucoi7dHMxK0TVzTBPgAfsbyAfyM5QOE8TW76bAkjebwU47zxoTHdAl5JE+IRHKNyeXk0njqtwHJnffC6qjex+ZUlIXwNzkLVlTGQ0aa4rAMiG6AyGPbSXr6zlBQ2MuSyoEtxGk9JrSOGarOThexoiNZC56rKQyWWixl72lDA5Vxfjy32P5ebKR5gR3uX056JSPZuXirlbELESXts0fTOF0l3Cjus2LeFJ0LtzqcdlLHLX236tGt1WzE+FaLdDkezNmoETk93aolVkO8bvwOlNsMi9lQUh2o+IkSw50Gi4iIiIiIiIiIiIiIiIiIiMjhD4tMxFN8soNOAAAAAElFTkSuQmCC');
			background-size: 100%;

			.more-btn {
				top: 28rpx;
			}
		}

		.title {
			font-weight: bold;
			color: #282828;
			font-size: 32rpx;
		}

		.spike-distance {
			margin-left: 15rpx;
			position: relative;
			top: 1.4rpx;
			display: flex;
			border: 1px solid #E93323;
			border-radius: 4rpx;
			height: 40rpx;

			.bg-red {
				font-size: 20rpx;
				color: #fff;
				background-color: #E93323;
				padding: 0 10rpx;
				line-height: 38rpx;
				height: 38rpx;
			}

			.time {
				font-size: 22rpx;
				padding: 0 12rpx;
				color: #E93323;
				height: 38rpx;
				line-height: 38rpx;

				/deep/.red {
					margin: 0;
				}
			}

			.red-color {
				color: #E93323;
			}

		}

		.more-btn {
			position: absolute;
			right: 20rpx;
			top: 0;
			color: #999;
			font-size: 28rpx;

			.iconfont {
				font-size: 26rpx;
			}
		}

	}

	.spike-wrapper {
		width: 100%;
		margin-top: 27rpx;

		.spike-item {
			display: inline-block;
			width: 222rpx;
			margin-right: 20rpx;

			&.presell-item {
				width: 210rpx;

				.img-box {
					height: 210rpx;

					image {
						height: 210rpx;
					}
				}

				.name {
					margin-top: 8rpx;
					color: #282828;
				}
			}

			&.assist-item {
				box-shadow: 0px 2px 20px 0px rgba(0, 0, 0, 0.08);
			}

			.img-box {
				position: relative;
				height: 222rpx;

				.participants {
					padding: 4rpx 12rpx;
					border-radius: 16rpx;
					background: rgba(0, 0, 0, .35);
					color: #fff;
					text-align: center;
					position: absolute;
					top: 10rpx;
					left: 10rpx;
					font-size: 20rpx;
				}

				image {
					width: 100%;
					height: 222rpx;
					border-radius: 16rpx;
				}

				.box_bg {
					position: absolute;
					bottom: 0;
					left: 0;
					text-align: center;
					width: 149rpx;
					height: 42rpx;
					line-height: 42rpx;
					background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJUAAAAqCAMAAACN4OndAAAAmVBMVEUAAAD/dy37mij/eiz+hCv+fSz8kyn+gCz9hyv9jSr9iir8kCn8lin7lyj7mij7mij7mij7mij7mij7mij7mij7mij7mSj7mij7mij7mij7mSj7mij7mij7mij+gSz7mij7mij7mij7mij7mij/dy37mij7mCj/eyz+fiz+gSv8kCn9jCr9hiv9iSr8lCn8kin+hCv8lin9jiqx53KQAAAAJHRSTlMA8fHx8fHx8fHx8fHx8cdMjnpvNBgN59vYrp9eKfXt4tGUP76oKK8EAAABeklEQVRYw82Z126DQBBFx6S3xRQ3wDXZkJ7Y//9xgVm2GQXJIZHveWEfj0YczUpLA5cTzZniomaxOG24ZK6ZK+aGOVfc1twxwW9YhqR5aFE2PCmema+KN+adeWV2uxfms+ajZrt9NMhDET9blT21enitW1bd07JebS3FX2glXVZllxbzP1oTUqQja+WLabq0fK/+WkNSTOPGqj2tI/zzG2IyOdNWAClOiVnXp8YBIMXxJk2LUFSnubaCSDEYN19tBZSilCttBZRiFaO2AkpRykJb4aRYj0pb4aQohd04OCmKkbWCSXE1ImuFkmKQkmOFkmJIrhVIijPyrEBSDH0rkBSjyiiMjBVKisNIyMBYIaU4M1ZIKdqNg5RibqyQUkyMFVCKEzJWQClm1gooxdBa4aS4JGuFk2LkWMGkGLj3K5gUY3c7o6Q4IdcKJcXEswJJMSbPCiPFiHwrhBTnOe1ZAaR4X9C+1dFTFDk5DHrQfjVQHPhqMBZZnJDLN9Y/g30cqDDDAAAAAElFTkSuQmCC');
					background-repeat: no-repeat;
					background-size: cover;
					color: #fff;
					font-size: 22rpx;
				}

				.msg {
					position: absolute;
					left: 10rpx;
					bottom: 16rpx;
					width: 86rpx;
					height: 30rpx;
					background: rgba(255, 255, 255, 1);
					border: 1px solid rgba(255, 109, 96, 1);
					border-radius: 6rpx;
					font-size: 20rpx;
					color: $theme-color;
				}
			}


			.info {
				margin-top: 10rpx;

				.name {
					font-size: 26rpx;
				}

				.stock-box {
					width: 100%;
					height: 20rpx;
					background-color: #FFDCD9;
					border-radius: 20rpx;
					margin-top: 13rpx;
					position: relative;
					color: #fff;
					font-size: 18rpx;
					line-height: 20rpx;
					text-align: center;
					overflow: hidden;

					.grabbed {
						height: 20rpx;
						background: linear-gradient(#FF0000, #FF5400);
						position: absolute;
						top: 0;
						left: 0;
						border-radius: 20rpx;
					}

					.stock-sales {
						position: absolute;
						left: 50%;
						margin-left: -40rpx;
					}
				}

				.price-box {
					display: flex;
					align-items: center;
					justify-content: start;
					margin-top: 4rpx;

					&.presell-price {
						display: block;

						.price {}

						.old-price {
							display: block;
							margin: 6rpx 0 0 0;
						}
					}

					.tips {
						display: flex;
						align-items: center;
						justify-content: center;
						width: 28rpx;
						height: 28rpx;
						background-color: $theme-color;
						color: #fff;
						font-size: 20rpx;
						border-radius: 2px;
					}

					.price {
						display: flex;
						color: $theme-color;
						font-size: 28rpx;
						font-weight: bold;

						text {
							font-size: 18rpx;
						}
					}

					.old-price {
						display: flex;
						margin-left: 10rpx;
						color: #AAAAAA;
						text-decoration: line-through;
						font-size: 20rpx;

						text {
							font-size: 18rpx;
						}
					}
				}
			}

			.assist-info {
				.price {
					display: flex;
					color: $theme-color;
					font-size: 28rpx;
					font-weight: bold;
					margin-top: 2rpx;

					text {
						font-size: 18rpx;
					}

					.assist_price {
						font-size: 20rpx;
						display: inline-block;
						width: 82rpx;
						height: 32rpx;
						text-align: center;
						line-height: 30rpx;
						background: #ffeae5;
						border-radius: 4rpx;
					}
				}

				.price-box {
					padding: 15rpx 15rpx 8rpx;

					.name {
						font-size: 24rpx;
						color: #333;
						line-height: 30rpx;
					}
				}

				.initiate_btn {
					width: 100%;
					height: 48rpx;
					line-height: 48rpx;
					;
					background: linear-gradient(90deg, #FF0000 0%, #FF5400 100%);
					text-align: center;
					color: #fff;
					font-size: 24rpx;
					border-radius: 0 0 16rpx 16rpx;
				}

			}
		}
	}

	.combination-count {
		background-color: #fff;
		margin-bottom: 11px;
		border-radius: 16rpx;
		box-shadow: 2px 1px 6px 1px rgba(0, 0, 0, 0.03);
		padding: 25rpx 20rpx;
		position: relative;

		.spike-wrapper {
			overflow: hidden;
			width: 670rpx;
		}
	}

	/deep/.spike-box .styleAll {
		display: inline-block;
		width: 44rpx;
		height: 40rpx;
		line-height: 40rpx;
		padding: 0;
		text-align: center;
		border-radius: 8rpx;
	}

	.page-index {
		display: flex;
		flex-direction: column;
		min-height: 100%;
		background: linear-gradient(180deg, #fff 0%, #f5f5f5 100%);

		.ad {
			width: 710rpx;
			height: 156rpx;
			margin: 10rpx auto 20rpx auto;

			image {
				width: 100%;
				height: 100%;
			}
		}

		// &.bgf{
		// 	background: #fff;
		// }
		.header {
			width: 100%;

			// height: 320rpx;
			.btn {
				position: relative;

				.iconfont {
					font-size: 45rpx;
				}
			}

			.iconnum {
				min-width: 6px;
				color: #fff;
				border-radius: 15rpx;
				position: absolute;
				right: -10rpx;
				top: -10rpx;
				font-size: 10px;
				padding: 0 4px;
			}

			.serch-wrapper {
				align-items: center;
				padding: 20rpx 30rpx 0 30rpx;

				.logo {
					width: 127rpx;
					height: 46rpx;
				}

				image {
					width: 118rpx;
					height: 42rpx;
				}

				.input,.uninput {
					display: flex;
					align-items: center;
					max-width: 490rpx;
					min-width: 460rpx;
					height: 64rpx;
					padding: 0 0 0 30rpx;
					background: rgba(237, 237, 237, 1);
					border: 1px solid rgba(241, 241, 241, 1);
					border-radius: 32rpx;
					color: #BBBBBB;
					font-size: 28rpx;
					.iconfont {
						margin-right: 20rpx;
					}
				}
				.uninput{
					min-width: 610rpx;
					max-width: 620rpx;
				}
			}

			.tabNav {
				padding-top: 24rpx;
			}
		}

		/*直播*/
		.live-count {
			background-color: #fff;
			margin-bottom: 20rpx;
			border-radius: 16rpx;
			padding: 20rpx 0 26rpx 20rpx;
			box-shadow: 4rpx 2rpx 12rpx 2rpx rgba(0, 0, 0, 0.03);
		}

		.live-wrapper {
			position: relative;
			width: 100%;
			overflow: hidden;
			border-radius: 16rpx;

			image {
				width: 100%;
				height: 400rpx;
			}

			.live-top {
				z-index: 20;
				position: absolute;
				left: 0;
				top: 0;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #fff;
				width: 120rpx;
				height: 32rpx;

				&.playRadius {
					border-radius: 0;
				}

				&.notPlayRadius {
					border-radius: 0rpx 0px 18rpx 0px;
				}

				image {
					width: 30rpx;
					height: 30rpx;
					margin-right: 6rpx;
					/* #ifdef H5 */
					display: block;
					/* #endif */
				}
			}

			.broadcast-time {
				z-index: 20;
				position: absolute;
				left: 110rpx;
				top: 0;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #fff;
				width: 160rpx;
				height: 36rpx;
				background: rgba(0, 0, 0, .4);
				font-size: 22rpx;
				border-radius: 0 0 18rpx 0;
			}

			.live-title {
				position: absolute;
				left: 0;
				bottom: 6rpx;
				width: 100%;
				height: 70rpx;
				line-height: 70rpx;
				text-align: center;
				font-size: 30rpx;
				color: #fff;
				background: rgba(0, 0, 0, 0.35);
			}

			&.mores {
				width: 100%;

				.item {
					position: relative;
					width: 280rpx;
					height: 224rpx;
					display: inline-block;
					border-radius: 16rpx;
					overflow: hidden;
					margin-right: 20rpx;

					image {
						width: 320rpx;
						height: 180rpx;
						border-radius: 16rpx;
					}

					.live-title {
						height: 40rpx;
						line-height: 40rpx;
						text-align: center;
						font-size: 22rpx;
					}

					.live-top {
						width: 110rpx;
						height: 32rpx;
						font-size: 22rpx;

						image {
							width: 20rpx;
							height: 20rpx;
						}
					}
				}
			}
		}

		/* #ifdef MP */
		.mp-header {
			z-index: 999;
			position: fixed;
			left: 0;
			top: 0;
			width: 100%;
			/* #ifdef H5 */
			padding-bottom: 20rpx;
			/* #endif */
			// background: linear-gradient(90deg, $bg-star 50%, $bg-end 100%);
			background-color: #fff;

			.serch-wrapper {
				height: 100%;
				align-items: center;
				padding: 0 50rpx 0 53rpx;

				image {
					width: 118rpx;
					height: 42rpx;
					margin-right: 30rpx;
				}
				.input,.uninput {
					display: flex;
					align-items: center;
					width: 305rpx;
					height: 58rpx;
					padding: 0 0 0 30rpx;
					background: rgba(247, 247, 247, 1);
					border: 1px solid rgba(241, 241, 241, 1);
					border-radius: 29rpx;
					color: #BBBBBB;
					font-size: 28rpx;
					
					.iconfont {
						margin-right: 20rpx;
					}
					
				}
				.uninput{
					min-width: 460rpx;
					max-width: 480rpx;
				}
				
			}
		}

		/* #endif */

		.page_content {

			/* #ifdef MP */
			margin-top: 270rpx;

			/* #endif */
			.swiper {
				position: relative;
				width: 100%;
				/* #ifdef MP */
				height: auto;
				/* #endif */
				/* #ifdef H5 */
				height: 320rpx;
				/* #endif */

				margin: 0 auto;
				border-radius: 10rpx;
				overflow-x: hidden;
				/* #ifdef MP */
				z-index: 10;

				/* #endif */
				swiper,
				.swiper-item,
				image {
					width: 100%;
					height: 280rpx;
					border-radius: 10rpx;

				}

				.slide-navigator {}

				image {
					transform: scale(.93);
					transition: all .6s ease;
				}

				swiper-item.active {
					image {
						transform: scale(1);
					}
				}
			}

			.nav {
				padding: 0 0rpx 30rpx;
				flex-wrap: wrap;
				/* #ifdef MP */
				margin-top: 0;
				/* #endif */
				/* #ifdef H5 */
				margin-top: 0;

				/* #endif */
				.item {
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: center;
					width: 20%;
					margin-top: 30rpx;

					image {
						width: 82rpx;
						height: 82rpx;
					}
				}
			}

			.live-wrapper {
				position: relative;
				width: 100%;
				overflow: hidden;
				border-radius: 16rpx;

				image {
					width: 100%;
					height: 400rpx;
				}

				.live-top {
					z-index: 20;
					position: absolute;
					left: 0;
					top: 0;
					display: flex;
					align-items: center;
					justify-content: center;
					color: #fff;
					width: 110rpx;
					height: 36rpx;

					&.playRadius {
						border-radius: 0;
					}

					&.notPlayRadius {
						border-radius: 0rpx 0px 18rpx 0px;
					}

					image {
						width: 30rpx;
						height: 30rpx;
						margin-right: 10rpx;
						/* #ifdef H5 */
						display: block;
						/* #endif */
					}
				}

				.live-title {
					position: absolute;
					left: 0;
					bottom: 6rpx;
					width: 100%;
					height: 36rpx;
					line-height: 36rpx;
					text-align: center;
					font-size: 22rpx;
					color: #fff;
					background: rgba(0, 0, 0, .35);
				}

				&.mores {
					width: 100%;

					.item {
						position: relative;
						width: 280rpx;
						display: inline-block;
						border-radius: 16rpx;
						overflow: hidden;
						margin-right: 20rpx;

						image {
							width: 280rpx;
							height: 224rpx;
							border-radius: 16rpx;
						}

						.live-title {
							height: 36rpx;
							line-height: 36rpx;
							text-align: center;
							font-size: 22rpx;
						}

						.live-top {
							width: 110rpx;
							height: 36rpx;
							font-size: 22rpx;

							image {
								width: 20rpx;
								height: 20rpx;
							}
						}
					}
				}
			}

			.hot-img {
				display: flex;
				align-items: center;
				justify-content: space-between;

				.item {
					display: flex;
					flex-direction: column;
					align-items: center;
					width: 170rpx;
					background-color: #FEFEFF;
					padding: 20rpx 0 4rpx;
					border-radius: 8rpx;
					box-shadow: 2px 1px 6px 1px rgba(0, 0, 0, 0.03);

					.title {
						font-weight: bold;
						color: #282828;
					}

					.msg {
						margin-top: 5rpx;
						font-size: 20rpx;
					}

					.img {
						margin-top: 10rpx;
					}

					image {
						width: 130rpx;
						height: 130rpx;
					}

					&:first-child .msg {
						color: #8FBBE8;
					}

					&:nth-child(2) .msg {
						color: #D797B7;
					}

					&:nth-child(3) .msg {
						color: #C49BD1;
					}

					&:nth-child(4) .msg {
						color: #A3BF95;
					}
				}
			}

			.common-hd {
				display: flex;
				align-items: center;
				justify-content: center;
				height: 118rpx;

				.title {
					padding: 0 80rpx;
					font-size: 34rpx;
					color: $theme-color;
					font-weight: bold;
					background-image: url("~@/static/images/index-title.png");
					background-repeat: no-repeat;
					background-size: 100% auto;
					background-position: left center;
				}
			}

			.explosion {
				.mer-box {
					.mer-item {
						margin-bottom: 20rpx;
						background-color: #fff;
						border-radius: 16rpx;

						.mer-hd {
							position: relative;
							width: 100%;
							height: 200rpx;
							border-radius: 16rpx 16rpx 0 0;
							overflow: hidden;

							image {
								width: 100%;
								height: 100%;
							}

							.mer-name {
								position: absolute;
								left: 20rpx;
								top: 20rpx;
								display: flex;
								align-items: center;
								width: 300rpx;
								height: 50rpx;
								padding: 0 10rpx;
								border-radius: 26rpx;
								background: #fff;
								font-weight: bold;

								image {
									width: 38rpx;
									height: 38rpx;
									margin-right: 10rpx;
									border-radius: 50%;
								}

								.txt {
									flex: 1;
								}
							}
						}

						.pro-box {
							display: flex;
							align-items: center;
							padding: 20rpx 20rpx 30rpx;

							.pro-item {
								width: 218rpx;
								margin-right: 14rpx;

								image {
									width: 100%;
									height: 214rpx;
								}

								.price {
									margin-top: 5rpx;
									font-size: 28rpx;
									color: $theme-color;
									font-weight: bold;

									text {
										font-size: 28rpx;
									}
								}

								&:last-child {
									margin-right: 0;
								}
							}


						}


					}

					.more-shop {
						display: flex;
						align-items: center;
						justify-content: center;
						background-color: #FFFFFF;
						padding: 27rpx 0;
						color: #999999;
						font-size: 26rpx;

						.icon-xiangyou {
							font-size: 22rpx;
						}
					}
				}
			}

			.spike-box {
				margin-top: 20rpx;
				padding: 23rpx 20rpx;
				border-radius: 24rpx;
				background-color: #fff;
				overflow: hidden;
				box-shadow: 0px 0px 16px 3px rgba(0, 0, 0, 0.04);

				.hd {
					display: flex;
					align-items: center;
					justify-content: space-between;

					.left {
						display: flex;
						align-items: center;
						width: 500rpx;

						.icon {
							width: 38rpx;
							height: 38rpx;
							margin-right: 8rpx;
						}

						.title {
							width: 134rpx;
							height: 33rpx;
						}
					}

					.more {
						font-size: 26rpx;
						color: #999;

						.iconfont {
							margin-left: 6rpx;
							font-size: 25rpx;
						}
					}
				}

				.spike-wrapper {
					width: 100%;
					margin-top: 27rpx;

					.spike-item {
						display: inline-block;
						width: 222rpx;
						margin-right: 20rpx;

						.img-box {
							position: relative;
							height: 222rpx;

							image {
								width: 100%;
								height: 222rpx;
								border-radius: 16rpx;
							}

							.msg {
								position: absolute;
								left: 10rpx;
								bottom: 16rpx;
								width: 86rpx;
								height: 30rpx;
								background: rgba(255, 255, 255, 1);
								border: 1px solid rgba(255, 109, 96, 1);
								border-radius: 6rpx;
								font-size: 20rpx;
								color: $theme-color;
							}
						}


						.info {
							margin-top: 8rpx;
							padding: 0 10rpx;

							.name {
								font-size: 28rpx;
							}

							.price-box {
								display: flex;
								align-items: center;
								justify-content: center;

								.tips {
									display: flex;
									align-items: center;
									justify-content: center;
									width: 28rpx;
									height: 28rpx;
									background-color: $theme-color;
									color: #fff;
									font-size: 20rpx;
									border-radius: 2px;
								}

								.price {
									display: flex;
									margin-left: 10rpx;
									color: $theme-color;
									font-size: 28rpx;
									font-weight: bold;

									text {
										font-size: 18rpx;
									}
								}
							}
						}
					}
				}
			}

			.barg {
				width: 100%;
				height: 478rpx;
				margin-top: 20rpx;
				padding-left: 20rpx;
				background-size: 100% 100%;

				.title {
					display: flex;
					align-items: center;
					justify-content: center;
					padding-top: 42rpx;

					image {
						width: 463rpx;
						height: 39rpx;
					}
				}

				.barg-swiper {
					margin-top: 43rpx;
					padding-right: 20rpx;

					.wrapper {
						display: flex;
					}

					.list-box {
						flex-shrink: 0;
						width: 210rpx;
						background-color: #fff;
						border-radius: 16rpx;
						overflow: hidden;
						padding-bottom: 18rpx;
						margin-right: 20rpx;

						image {
							width: 100%;
							height: 210rpx;
						}

						.info-txt {
							width: 100%;
							display: flex;
							flex-direction: column;
							align-items: center;
							justify-content: center;
							padding-top: 15rpx;

							.price {
								font-weight: 700;
								color: $theme-color;
							}

							.txt {
								display: flex;
								align-items: center;
								justify-content: center;
								width: 136rpx;
								height: 33rpx;
								margin-top: 10rpx;
								background: linear-gradient(90deg, $bg-star 0%, $bg-end 100%);
								border-radius: 17px;
								font-size: 22rpx;
								color: #fff;

							}
						}
					}

					.more-box {
						flex-shrink: 0;
						display: flex;
						flex-direction: column;
						align-items: center;
						justify-content: center;
						width: 80rpx;
						background-color: #fff;
						border-radius: 16rpx;

						image {
							width: 24rpx;
							height: 24rpx;
							margin-top: 10rpx;
						}

						.txt {
							display: block;
							writing-mode: vertical-lr;
							font-size: 26rpx;
							line-height: 1.2;
						}
					}
				}
			}

			.group-wrapper {
				padding: 26rpx 20rpx;
				margin-top: 20rpx;
				background: #fff;
				border-radius: 24rpx;

				.hd {
					display: flex;
					align-items: center;
					justify-content: space-between;

					.left {
						display: flex;
						align-items: center;

						.icon {
							width: 38rpx;
							height: 38rpx;
							margin-right: 8rpx;
						}

						.title {
							width: 134rpx;
							height: 33rpx;
						}

						.person {
							display: flex;
							align-items: center;
							margin-left: 40rpx;

							.avatar-box {
								display: flex;
								align-items: center;

								image {
									width: 30rpx;
									height: 30rpx;
									border-radius: 50%;
									margin-right: -10rpx;
								}
							}

							.num {
								margin-left: 18rpx;
								font-size: 26rpx;
								color: #999999;
							}
						}
					}

					.more {
						font-size: 26rpx;
						color: #999;

						.iconfont {
							margin-left: 6rpx;
							font-size: 25rpx;
						}
					}
				}

				.group-scroll {
					width: 100%;
					margin-top: 25rpx;

					.group-item {
						display: inline-block;
						width: 222rpx;
						margin-right: 20rpx;
						box-shadow: 0px 2px 6px 2px rgba(0, 0, 0, 0.03);
						border-radius: 16rpx;

						image {
							width: 100%;
							height: 222rpx;
							border-radius: 16rpx 16rpx 0 0;
						}

						.info {
							padding: 8rpx 13rpx;

							.name {
								font-size: 24rpx;
							}

							.price-box {
								display: flex;
								align-items: center;
								margin-top: 10rpx;

								.tips {
									display: flex;
									align-items: center;
									justify-content: center;
									width: 76rpx;
									height: 30rpx;
									margin-right: 6rpx;
									background: linear-gradient(90deg, rgba(255, 0, 0, .1) 0%, rgba(255, 84, 0, .1) 100%);
									border-radius: 2px;
									font-size: 20rpx;
									color: $theme-color;
								}

								.price {
									font-size: 26rpx;
									color: $theme-color;
									font-weight: 700;

									text {
										font-size: 20rpx;
									}
								}
							}

						}

						.bom-btn {
							display: flex;
							align-items: center;
							justify-content: center;
							width: 100%;
							height: 48rpx;
							background: linear-gradient(90deg, $bg-star 0%, $bg-end 100%);
							border-radius: 0px 0px 16rpx 16rpx;
							color: #fff;

						}
					}
				}
			}

			.boutique {
				margin-top: 20rpx;

				swiper,
				swiper-item,
				.slide-image {
					width: 100%;
					height: 240rpx;
					border-radius: 12rpx;
				}
			}

			.index-product-wrapper {
				.nav-bd {
					display: flex;
					align-items: center;

					.item {
						display: flex;
						flex-direction: column;
						align-items: center;
						justify-content: center;
						width: 25%;

						.txt {
							font-size: 32rpx;
							color: #282828;
						}

						.label {
							display: flex;
							align-items: center;
							justify-content: center;
							width: 124rpx;
							height: 32rpx;
							margin-top: 5rpx;
							font-size: 24rpx;
							color: #999;
						}

						&.active {
							color: $theme-color;

							.label {
								background: linear-gradient(90deg, $bg-star 0%, $bg-end 100%);
								border-radius: 16rpx;
								color: #fff;
							}
						}
					}
				}

				.list-box {
					display: flex;
					flex-wrap: wrap;
					justify-content: space-between;

					.item {
						width: 345rpx;
						margin-bottom: 20rpx;
						background-color: #fff;
						border-radius: 10px;
						overflow: hidden;

						image {
							width: 100%;
							height: 345rpx;
						}

						.text-info {
							padding: 10rpx 20rpx 15rpx;

							.title {
								color: #222222;
							}

							.old-price {
								margin-top: 8rpx;
								font-size: 26rpx;
								color: #AAAAAA;
								text-decoration: line-through;

								text {
									margin-right: 2px;
									font-size: 20rpx;
								}
							}

							.price {
								display: flex;
								align-items: flex-end;
								color: $theme-color;
								font-size: 34rpx;
								font-weight: 800;

								text {
									padding-bottom: 4rpx;
									font-size: 24rpx;
									font-weight: normal;
								}

								.txt {
									display: flex;
									align-items: center;
									justify-content: center;
									width: 28rpx;
									height: 28rpx;
									margin-left: 15rpx;
									margin-bottom: 10rpx;
									border: 1px solid $theme-color;
									border-radius: 4rpx;
									font-size: 22rpx;
									font-weight: normal;
								}
							}
						}
					}

					&.on {
						display: flex;
					}
				}
			}
		}
	}

	.activity_pic {
		margin-left: 20rpx;
		padding-left: 20rpx;
		position: relative;

		&::before {
			content: "";
			display: inline-block;
			width: 2rpx;
			height: 40rpx;
			background: #DCDCDC;
			position: absolute;
			top: 0;
			left: 0;
		}

		.picture {
			display: inline-block;
		}

		.avatar {
			width: 42rpx;
			height: 42rpx;
			line-height: 20rem;
			display: inline-block;
			background: #2ddcd3 no-repeat center/cover;
			position: relative;
			text-align: center;
			color: #fff;
			font-weight: 600;
			vertical-align: bottom;
			font-size: .875rem;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			border-radius: 50%;
			background-repeat: no-repeat;
			background-size: cover;
			background-position: 0 0;
			margin-right: -10rpx;
			box-shadow: 0 0 0 1px #fff;
		}

		.pic_count {
			margin-left: 30rpx;
			color: #999999;
			font-size: 26rpx;
			position: relative;
			top: -4rpx;
		}
	}

	.productList {
		background-color: #F1F1F1;

		.sort {
			width: 710rpx;
			max-height: 380rpx;
			background: rgba(255, 255, 255, 1);
			border-radius: 16rpx;
			padding: 0 0rpx 30rpx;
			flex-wrap: wrap;
			margin: 25rpx auto 30rpx auto;
			padding-top: 8rpx;

			&.no_pad {
				padding: 0;
			}

			/* #ifdef MP */
			/* #endif */
			.item {
				.pictrues {
					width: 90rpx;
					height: 90rpx;
					background: rgba(248, 248, 248, 1);
					border-radius: 50%;
					margin: 0 auto;
				}

				width: 20%;
				margin-top: 30rpx;
				text-align: center;

				image {
					width: 90rpx;
					height: 90rpx;
				}

				.text {
					color: #272727;
					font-size: 24rpx;
					margin-top: 10rpx;
					overflow: hidden;
					white-space: nowrap;
					text-overflow: ellipsis;
				}
			}
		}
	}

	.productList .list {
		padding: 0 20rpx;
	}

	.productList .list.on {
		background-color: #fff;
		border-top: 1px solid #f6f6f6;
	}

	.productList .list .item {
		width: 345rpx;
		margin-top: 20rpx;
		background-color: #fff;
		border-radius: 10rpx;
	}

	.productList .list .item.on {
		width: 100%;
		display: flex;
		border-bottom: 1rpx solid #f6f6f6;
		padding: 30rpx 0;
		margin: 0;
	}

	.productList .list .item .pictrue {
		position: relative;
		width: 100%;
		height: 345rpx;
	}

	.productList .list .item .pictrue.on {
		width: 180rpx;
		height: 180rpx;
	}

	.productList .list .item .pictrue image {
		width: 100%;
		height: 100%;
		border-radius: 10rpx 10rpx 0 0;
	}

	.productList .list .item .pictrue image.on {
		border-radius: 6rpx;
	}

	.productList .list .item .text {
		padding: 14rpx 17rpx 26rpx 17rpx;
		font-size: 28rpx;
		color: #212121;
	}

	.productList .list .item .text.on {
		width: 508rpx;
		padding: 0 0 0 22rpx;
	}

	.productList .list .item .text .money {
		font-size: 26rpx;
		font-weight: bold;
		margin-top: 8rpx;
	}

	.productList .list .item .text .coupon {
		background: rgba(255, 248, 247, 1);
		border: 1px solid rgba(233, 51, 35, 1);
		border-radius: 4rpx;
		font-size: 20rpx;
		margin-left: 18rpx;
		padding: 1rpx 4rpx;
	}

	.productList .list .item .text .money.on {
		margin-top: 50rpx;
	}

	.productList .list .item .text .money .num {
		font-size: 34rpx;
	}

	.productList .list .item .text .vip {
		font-size: 22rpx;
		color: #aaa;
		margin-top: 7rpx;
	}

	.productList .list .item .text .vip.on {
		margin-top: 12rpx;
	}

	.productList .list .item .text .vip .vip-money {
		font-size: 24rpx;
		color: #282828;
		font-weight: bold;
	}

	.productList .list .item .text .vip .vip-money image {
		width: 46rpx;
		height: 21rpx;
		margin-left: 4rpx;
	}

	.pictrue {
		position: relative;
	}

	.fixed {
		z-index: 100;
		position: fixed;
		left: 0;
		top: 0;
		background-color: #fff;
		box-shadow: 0 10rpx 20rpx -5rpx rgba(0, 0, 0, 0.06);
		// background: linear-gradient(90deg, red 50%, #ff5400 100%);
	}

	.mores-txt {
		width: 100%;
		align-items: center;
		justify-content: center;
		height: 70rpx;
		color: #999;
		font-size: 24rpx;

		.iconfont {
			margin-top: 2rpx;
			font-size: 20rpx;
		}
	}

	.menu-txt {
		font-size: 24rpx;
		color: #454545;
	}

	.mp-bg {
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 330rpx;
		// background: linear-gradient(90deg, #fff 50%, #fff 100%);
		// border-radius: 0 0 30rpx 30rpx;
	}

	.main {
		padding: 0 20rpx;
	}

	.combination-item {
		width: 328rpx;
		height: 180rpx;
		display: inline-block;
		background-size: 100%;
		position: relative;
		background-size: cover;
		border-radius: 16rpx;

		.img-box {
			width: 122rpx;
			height: 122rpx;
			position: absolute;

			image {
				width: 122rpx;
				height: 122rpx;
			}
		}

		.name {
			font-size: 30rpx;
			color: #333333;
			font-weight: bold;
			line-height: 32rpx;
		}

		.price {
			display: block;
			font-size: 30rpx;
			font-weight: bold;
			margin-top: 8rpx;
			color: #E93323;

			text {
				font-size: 20rpx;
			}
		}

		.gocom_btn {
			display: block;
			margin-top: 6rpx;
			color: #fff;
			font-size: 22rpx;
			font-weight: bold;
			width: 100rpx;
			line-height: 30rpx;
			text-align: center;
			border-radius: 16rpx;

			text {
				font-weight: normal;
				font-size: 16rpx;
			}
		}

		&:nth-child(1) {
			height: 378rpx;
			padding: 20rpx 20rpx 28rpx;
			float: left;
			background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAApAAAAL0CAMAAACMDvcuAAAAwFBMVEUAAAD/3dr/4t//2tb+087/6eX/6eb90s7/3tr/3tn+2tX+zMf/5OD/6uX/6eX+087/6eX/6eX/6eX+2tb/6OP+zcn+2NT/5+P/6eX+zMf+19P/49//5eH/5OD/5uH+1tL+y8b/4t7/3Nj/z8r/29f+0Mv/6OX/4N3/5+T+4N3/0Mz/5eL/5N/+5uP/3Nn+4Nv+5+L/29j/3tn/3tr/4t3+19L/zsn/39r/zcn/zcf/0cz/2db/39z/08//29b/0s2G7EjjAAAAE3RSTlMAGAZ7sK+Xl1g36uqH49PT7evs8/MOQAABHsNJREFUeNrsmdtu4zAMRJ0WCRogKVqAD/mCg77k/39vsWiQqTwWlxFcbx+q3mzdSJFDctRMbTs+71/frpff9ts2aNe31/3zceq23em8ghRWm77BRqysDpXtGN2R7zy82sYeOZ92y3A8XFeX50u4/IhGr4OtnbeBvBTa/EeduO15PSxA8uX9ey2IprC1xyn0V6FIbRg2QTG5vfNV1FVk1aTs7+8vU9ueDjatY25+Rrh/abRAB0ZlK4vXXcB4uSW3NqwMVFIbMiDAe2Fwj8NTg8d9mjP0MJ4cWYXG1QObeg58PMvQeQse9amrOaLk6BYxsqhMat1p/ktt/2R4xPbwSGZER7Iu73VhxJIBGYDSKGli2JGMic5xpyeGUkbk8W3I+VeLAiR9ZheRB9sA/JB6oWb1GKZ03u0C6mgsWGZlxoGrj14NVWhcCwotVtDaYQ16JrMolQSPDs2iQLXD/T4D97oqMRRYAf7XDeU7QJXlUMy4FKs/dTSBpCdpCUYEaacByPStS0k81XpV7aafBXiEfd1uNrv3BGcjjXJHKNAEPnoAsQyiVd9zqZIspIblJVedxwxBwVvWRZ3AhToqnvVDcklMTgXuOIzx57fdZ8EOK4gMxCw2FmaYXsWPgYpO7ZoQXnRUmiLZCD1GEzKeLejaDY1QAQNOEnUIBu8Vkcwi6qwpFeaaOib8oCFv3Iv27qPdA1ttZ3JiFLU7DOT4YpGbBG5Fw1fOb9DMLp2hV5mLUIgs+BPmQ2J3qHBUOjjUY7IZyU22F4bGhKOjZgkP8vLH3xR58kUuHpL8jMufLWHR/m6KyImmlwA9ty1o2Z1mYK6k6PHwQ8ZnbzxEEWJJFbzauxYa9PTZvoU628iWe/KU6+laKqEe/LjBPKCiXnpP0zSd53EBFu3ZDbUFa9SIBc3qWD5546Nwd9JWCsMQgmTK3MJZRcBsHmhqYCW5fl2oDxcZaBfFJP8Fp6lqkV6aYHlAa3C/twaN4udj52k6YkMwr+148Z+7UmusdRRBEYvTg7hZutEFLqAlVaeS/fWixj360YjtRcKALZmm+tC5VkSX3Ebp0wcPKRWUr9/aD5hvBML92L/9YRa7IShbpBynZ5SDFHD6ga/lFPo3YWg87F6MbtZFOGidMusKEn/KcEZsJNuoFTqcupYuN+EVAilqlMP30CDcBeGXqJD/Ef9Ik5nzHJ0ShxK3L4EyuyP6HTZGPwigMyLe9YdxM9gJI4hh6EoVVw7Ih36Bb/z/71XtyHpyrVkBtEXLZCaTOImTpb+ejzy5Enm/bWdNO1BWGFEVnG4A26rwPjFr5GrXLt5ZsYX75aQNJAKWyBKLDOrzzUq3V5bJNWz2UjaPVKyCY+tsYv1mp/WIBv3KRoLtDXEwQD5hyAmawcjH8/kvgzpBy7odeK618AWq6zxxORtiKnatBQtImaveIOsbz/WKxHrcqyw8gVW+7rXetuJ9fGwSG9Mmz7FXIr1L7hBSb+0JNvzpHZD5PmsittI3SbdRngikOsOqneZen8+XiU7rZhpuO8lb60XfkzwdA+j1pLulZRXi4oxaMxdIeNxSHJIs5gou7a7U1XaDUAnoXb4RudqustrZGvpRlFQVH0mEUv+xvzwUmqyWZIY82XemfhEpkjrs0wurgtfX8+31K+7B4uUPNEGaW75G9RSPZmdN6vQ6avcglW2uW9id+rYK5b66UEjUYz8tE8xqniIsEcyWEYrpBLhEevXk1A1jF07d1uH52G1Lle2hYWV4UCXqjeTOv/Ohju/W7/vJE53dtknQOVv2Nc+IXakU5ECAXWIyeZs1xW6IU2flDMWgXljB5xsd9WEuy3AmSeIpX8J4uLg8E6k+R+BjyfYPpu7IX+eaylebOUK7I7nc2z1IV3WAbEvFfCW5N3VDYQvog6BHdSwNrwMMfdtT8W1XaPBtZyfpbZxsaJeV0GvP+eQTOFPDnE0A7PXVXv9DiCgHuXwsG45MJDRdUGdzshe1F/E1J8oBWVmMopOXdRuk8CRXqsPamHprGKnRKx79HKLSwZiHGxygtDX3MxzGeyNuMhGJ0puSVR2oorjD0LphsbVMPWJDElAQ53d5FQWSGgSOap4rEt18iEp6eYHVCiL3P4cyn1QBYaB7g88P2t3eNzPTexnCwTF0LG64jnG5Y2OSNrUfI7oX2RS0D5/jiOiGcenqIeOyDqaEj2dnpvPFu8xYIO5IQroNPwC0t1q0RA9Xms5aIjA0eLr/IoKJErnmSRKH9PIkU9ZWsJLO97ZZe4Ss4EQAF19hOGl6vW253GPp6atmdh3NQCepQDwlNTdisYyQNObqisMf+zGY0ZDvMHzhmSEA3YPYaGdXM769HwfCMvT3UzoeMUfYV6Kl1MIjs4BevrO1m1ma7JgjCFHZORejZejQjTqUk2s95Kf5OgkdM3PHuKTIMGfJtIMVo1bHRAR6PNl/TTcjufxncNUOUmJdDadm3ZGOKryqfZIYNVRBfZIpq3AagSsIW7FUNTQT2FJgyrtsOisdKHTDoviJR2BMHFwQT1hKNdgsQehn1VbWUfh9e/1Cv22sbgec8TyiitIo4AzqLKlmEjEFkx1LFEwb63MTYfdiLdnTjsFMeZ9ZIqeQVdXRbew6k0A1sBfUMXjWPsupDiSSIJvYKTlYsQ4ac1glRbGz921Nu2rbVM2oGFk4LxZxrZjmcrs2ijpijNuK1ZMtGOsEWaQ6nmAgA8ODQVXG4Babwl1AtrIsNhYHsgv+arMoQScaNWNFqhxsXOS1UFUlp2QLLBB0xnFV+01GrnxuQF9NDYdJ4jVPj8QtMoaVH0oRzL0afyYkm8/GJvBLI5kjic2eIkGH2HBx22CEMm8ca0AQkwd/vUAAA6JFjIEJ7t3zczm1mAaQfBPXiZo2xlXC3Qbz4n47QNvmw7dp4XJ1zAhax8hO8TOEj1IbkHBbmZmjfz/RUVa/PWTma7TBNvLMJ0jD2rvogEkNYyK7CLdtyZoR/Vg2B4c7FzgpU7aaNIGSrl15zODaAvL1LTUUTZIAHdsFHdRW6rrUqVCVww+NPj7JfqnFWRp/oFqzdEXMHS7gihEFwuqehxoIEtUSlISwkLMHFlOBZf+DBVo9fWLoBU4J3ZFyRJCNEYFVUfHMJqs58BFj6KNEuJkKqdMB7N1pePo3KcMzsjasgs4EDwLwJVAy5g5KwaiOxvh6vQTjHn9GrCcLdnMCsFxZThXbFbtBpSWJeKMLT3BliF/+PbaE8gj0RhgDG6Da1fx28nNu6bLjcbpAig1dyIKHaKKmtglR2Ufeiq2CnG5JTISJ+D7iStmXjYVxMZz5D9lmliTJEsLAOoTOwP2POB9Kl09Yv9W6KhcCBAgx7X88I/dxAK+SscsQRI9pIrEYfek/IU3sDytBynh/QPfsUQ2/3aViWVLL3PvKJwV8Z1NOapwyPD3efucFB1fmKeBqJijYrDdw4avf2DSIAFqLCdN/yTrvRPhVBH2lCprH04ggHnDITX7xZz+0P7/M7/wMcdmnX4ZjPUHatYvGHHpnHRk6n8sSLFspBFQ37i0727GIPibU0sMiBS2lPz2HT6iMzxzzVJl4tQsV373ayzGMuvi+mJc23J5ZdoiZtFlCk7epWjSlPPX5U4pF5xNb4+R84jH515Ng444btUECDDGIW+Bb4uXVan6r09iuQeZOrqxGqVFW7+nNA4mrhFMNhpyPEPSwnwzJ/U4MjavskxFzRr4lRBqpe+Vxr3JgiY6Cilc96LGdbKhMuL6G6a56ziUTSI5VSAjFioZrlVMSkesKEteSgL5qzk10Yy6heQyfsYQIgMgSaKsyHEGpYwZkt/ucltBxEkg2j6Op9ZQ/FDZ4BA35XnXxtNBYSXx9QL6nj8ZYl6a+WbWe+nih7smkOI8NQPeuqNhCo1q31vnixRmsZ+KZQqPsMy9TPqntTIsM2ZBB+gjFq9aZPr7Udgup+czk7aOFEO8Q4ZUR/rmbQ5JGrfGFjoCCwOCw+XN7XnG7iQIYYDdZOpalWAitBMqn4eyyIfUnqOW43Y+UMSFwXABx5MoP0RIhok9i9uxauTMmedvY0yk0Q6lcLZbQX7YaIcmfu9Y6OCcNABeCTW3z/yqUzl/YZU5EAFvyIomyOoMbVTESDBsffk7ePvZoq2TZMcEoE+waigEZvp8Soov55DlZCBUXIvhH9ZaZ1+tXWN7OJNlOMMrCa86uZeuABJMlH1H6wKHOTnhYvzyDme3Almur6dMheg2T8TSQqxcJSJQ3U1IkSNGikEaSbuqgIB0ezm17swU0QUPAzk5iyhBPzOORgt3+aanA63Eb0RNZJd7sZfid5p5yF1o6YgPsDHyj9xmGo84qGAhH/41gul2sTBGzDRfUElNpNuVuglbDJvlbA/8xGOZVhDgeEwTHZyRNzYudy/S7l1WQS66bxWjxuOPEdo4hRDVScc+V6cs+R5ZuK71Sqrimftek5o1u4pRurjDTW7CJWDve8WrD/PnrVkPo68kgWdw98zMGvQ0XYrOUsGarHEitL3+3bTz6HhmddIwHFI7sLpT8HBtUToRsLAukqRDne7FcHZLI9EPQUqTwuuoRqdu4gRSE/IjmmfOd+A5/WyYGdOBEEcDQRslMu1yQY7A1c68bggAR+5EELz7IFM4l+BXh6JHsIcD6MGN7EtVFKbZtauskn329SZDL5BE35epi7WYkFSPC5B0NAYTFmA6PEZnH4l15OzawmBIyORTqHN/7ihg0ouRsfOBZbbDXIRSktPZ+pZ1SWRkftohtG/mNyBxz0HCldnf007Jo5xAbX0KSFIV8a5ft7XQyIapr84V8SJcgJUlaTteETV3d4kOZKlpQE2wFDVG3BfoM/RRssx5Y3T1vy7sm5I6JUY4OqkJWf81x9Qa+Bgd4vw2QMjQfkN0XW6Jiq1XB2ZogM6CrLEosEoZ5pmGgclR1wYYcRdCokBQcXLt9RWJWE40DJeInR+99Oq0LzVgUvYBPcBfYEzeSPkBOAXeudmGnXrM85xjGoAg6AAmyCHhsd24A5lZx8oqFzLLx9dgdbKFAZ3fLN7ze4mkRl+pO5Fc9weVK2ZZpi8ulZ8cdiSbBNyGu4x3yWRhPcRhZsoAMrG6KdC88w7H9WVwiQyustb9mZLFvoFpF7e1UsoctKphhvHq4K9SzRFLmpRxqvO7nnEVlqQPT1jyBci5VOKoM0LVOkjSTaP85s+Zli1IPlwrqO9YpmbdhGT77WKU4tPttTIjfsaemz0BUMubjeBqd7c5bghumQmB9HD13agz66Bmvz1pq65a2xv19ZBvoS/dBui+JYr1tbGprjgYM7lRp8ythKIptoPN3n8Uz9F574FDWvoiipErPiUdCLwrpw2LIInXkPgudy7UYz2oDHJtz/sPRARhawAJp2RRSPavOCV4k/hJmbqGZuMypp6F6w6iYqJfdzp5FqcGUcqpazNm60HGkj9tLnI3crUOC2BrnTtm85svP683l/0lsiQ2EsgEThLLqYu989x1xs7tKmjN/5/aYn8wA9sufjgkNQRkhXF0EqKwQCSNNT7IPyz8XAVmPlKMJVTLVl8bxxV6CUKhfoTKxWIUB5RrCjU7Xs+x79N3RX4N3jkOhyC2KccOi6LE41jxwFyh8wmRj2rcngti3+UpMMj139uEDRk7oL6/xz6Cr3AQPFn+VZUrPFlKQJLcuDdQnfAEliONqzjUuVchfBXDeXtGxpf8yfnn1S/IRcY4dCRjxwFvEQR0UORVqyWPv/e0K7g8MJHq7ucTBbNmPBnI7gVpgVizf3wUootWD/fYk3/zEEmN8MQndxSKEMbWI3N/uDaXNY7qFHa1qrPAa6fS9nJz8wkCnmggPu0Hk88vQ32tCsixZ1+zDracoDYfX42LI6Zw6jOnmA3otVlLJRSigZ0G0O0iTXJ2WX9wbJnjYLYZsj5CHsYB3hioZApKjZLNYGRaorUOoywmd+b9m0Ex3TOvbqQd7t6901CuWSO6GaTwLhiJaS9/Lg3zwnTRWs2oR8u6CcXZhPoKTu35rSMK37qdzAQuTdMR+HAKd1SOhjGtW62o/cJjpP9btBp2prGc5SaBjPXaGnscd47oj5tgGI3oEqE0rO0o74ddt2rJpRDqR1u3ocrFHWpJozMN8Jj88ewjMpBNKQQD/8rTlUn0wuxHITcDOxU7Fb/y5nlTucTtbg3GCo7U8L+HEwIrWNYUiMePf3wVw3wjLGDmPKgXzIjUpPSkVTLiML5mV1K7bHi+G5aH8wBQPUT1qQ2aeOzOAObspP6EtWOybYnUHelqPbdrSky+wG9pGJGmTYD/f/m7FA2/2GOpszPvPigI8MGYpoZPytthLW8SjOPEJiTXejz7Fw6j+NxHTsPXiZDKj0xmzUg0zdLmzsSa4eSOAvDbYNNWX6+FWgFSf8fcmDbJwyoEDiLUOHcYRf4kNEIl5HTrwzConFYhanCDatOAnrgx7SZJRemwLjtvWI8cFL3edEbVqY4NketBgHEbKUMgMEC0gGbVq2neAMTUnX1KF4nhZBlj1Nn1edlXW3cgaWB558/4qzVFB0NXJkGUJbKwchajwo3t/OPHKKDWhGoVFie5F0x+NINSHkJWtlz4A677ewtckKppLjGfehLA916iDtkLNoL6gUzrlttJm4RSG15wSbk37CEWG6sP1Lk7D9m5xNMUPdrMcbQYZ6DQ2nCSHn1e2mBYPAvXbUQ82louTAw5CyYtzITOOk3OhuQpz/QAQ4/YkxXjvtR20X0C2uKZV0m65F9/UUmTiydaMmRhAMmHuqHoCDczxB877F313xd1HRfzEpZ9nzdZoQSWEEQwoDiNOEYzgzxglXDbvE5XbuRPowt6rlFGXW4qgEQTgVPQ2qB97GnezAypRWomryX+mPokvg6dqkes6Ykvcf1vQizNcixKwZsaHiqXmNo2zdlxuzMxu4wAEdVvCuCHkgCCZjlMQogFQidefL3HJ0R/Fgb4O2nf/yYRlxaWxAZ5w4oqOzQHgnwetY3B3DIzrGIUt5k1Y8Ng+3hn/6h0X/8iohB0wLtdIJjwl2R21RReYYbmcc+Cm3y0QTEFmPhSeAZwIpohD5tgQu8hjXubx6/G86FeHxk3+NoG9mAN91oCWvo7Dt4jWznV2AMFdDCkQGu0G5WsknhsReCoSxtExHH3GYjx+oBo8NXYWs+7mKlJlIxj9CPEloBuMTdzl/8TJJS4ybS46zyROCOYwdgnfrVgZikATDf+p2JKcFtx9VUYwo5OAOaExXdmpEEwxMjXZ4OU0h4ESomQ/a6Q8UJHBu8bOa8kPBmrLAKG2iEQak+0E5WpMgrTfrNELP+YdiY77BobKmD4UpglNpO8KUjJZF8beUJy+taQjp6TuNH2LYCIEYF19WHgB5ISlOpqYMmlQ6nkt5cv16xEpp1+cLrlZI6ZJAKgxBtoAWhYf2MZiqc6+bDQk8rXYzSMMVy1mwSmu6PL9af1KBQFpHE5VLxEn+XV91jo3MvgjI930J4HooJzUiHp83V3aiQR/aAlIspYdGDWQUXuomUDO7Mw/ss3tyI0YBoIMYmOY/EO8j6meLpxUZXtNkUsQGLypJfOJsO2EkttltGb6J1pfssd8hUDEbyAf/2s1jsoAql62LI4G5BjlqQuhQeUNiZg4jPT1mqhjgkqsNYKB0nuVPYss59Dw1iszslMFvgoSbOx8Vajs2FqO3UVVfcJL4p3+WXqmOQcsKjFp/ocS6OEqBGBO1PDo042kwAtsM/hcyzHQSd0YdIfzYFwOBcP3jpT16z73EiRe1Yn+zVqbuh4gSFlhSnZyE/hFn0svipsvYglPBWIPq7mw8b2wLglMomJYppQBau6KDmFzLX3KCf4lOAvRbjz9ilJELf7G+FxNIizm2Kwz7ZvUw6FWDF3YiLHsh9AXfM9R/hNUiH2Jqy070CojF1zF4aHg3z8gDxN4ZmL/2mB7/Nbx6Nx4TbN83pULe2DbH4MLoDNWXpb1BPQJoHlZXALH2VAvDHllu+JbcJXzWwAMbwnYY1QVS6SL/7wroc4ZIKvpcPfTLxrumyupIdHWoj1yFLpSAmgrVYYWiXkY0+FW38T/VAs208tbePcqYLjABB3aYvpp4LV8JBJV1zNru3Dp4Z1x1VUG+3pgCb6oAC6Y3LBFKonUgueS0IdZCX8EZo8+oVtCMEHbz1u3ADDoBPiD61vVg4FirIx4KW+Eog4RSYVjJP3aFEJLH9N15DvvRO2V7HbarJLAsnQ2VRZkR7FfNrEezS8EbZgiq1sUplh9xYn1gsNcfY3qBH3nBCI3q1DFjNpSNa7D5Vi4BeZ5XVXuaq/wD/dyHnRBE3CPSJUcxmCy2QpgdgZyvMFIGTg5QzuKZkFmpdW44WLMZKhwFcqDItC1tJpDqGtgbRmuY+OAk7wvTOVoTkE67RIuqy752kE81uQPKeJ1URFN1YVznjs2/AUZeAi2z2YeGE75Asw96UndPDztQ8w9W7gZlJrnUbfAlICT13OMck5cgraLABQ32Ux2AJupPBCBq6kk+cHVgWhQCNW7wB6O9J0EjZ7WlMrXRy6W6aEKYrNGUgKUDQ7NRevQhMAVhu/h3VaQYK82pxsQ0mb85sbjDIcsBoDrItLAVirqNiuEcAxV/Rg9lxV8z/aoCvhj3uY67VsZIjjqTtSMmJNX2NlNKmo7+P8H8DEcfExSLLoz9B31jO0HA2dWii/hPHQJf9A2nnKfRR+Kj5JIvr+pL5ycr9KD8aynsTo59wguz5WKko0QTyFxRYE+2+QJWtKhZVzDlGkxHOhwrD7DL8NYkUNncXKKGWvhwTtdK8wttA1hk4cNcT3KiYdpy8lHdeb0UGAKH0uIaIqn6YynOqpug4RjaIIHcllirkjNgHGUMHODGGkrzBjnxTaMl41QyE1gSjtMEn4eC4xOJgYVQImiTJ9lr2Yl1io1gr5l1+aAJ+Zj/6W8q1opAMni5qnVAZtdk2N3waih/moIVCY5FTvAOIaR9vI2O66y63JucNNad9jbAjfjugLA7Z7aMBTYWCMyexUUinpUIrx7wchP0VpeYc8QPLIWIG1k6mSWZXge1nsXgFCSCP+E9FEXTfR8HxV5wG0WwZKLQIqPwnbP6vTWEvwMvpHT0W0iQ63TYGI5n6BB7jFDZFReIr4PQ68JJZGiANwBok1bmRTIyxUWEa3BHRgCmTYdOa9frmuHX4HqC3i01C7ai3kAetVNlpi6mYfqrEAK4gBW3iXA1Lh9RQTa9eA02ToWoWOyj6RLoAcizpNSInqjBEcX4yAy5x3HxEy34SQ3tJHFDLuEq3duIj2aCGhQqtp7E2Z3hja/FREUCofpxJ01Mt4YVyi08/BFGlRIo+wp9tQQAoujx8wFZDeYjecZ5F41VfWw2w545czqZ1Pg03A9tmTvGC/gY5ebS14elx4hsaKUYDiWabiCbF1gMnbkIAjMS8lRWb0gWoHKCNpfZDAJRkuePqi89ncVXjg5iEXTbV6rReMdjo6Nh3xGdIj+FOAAgpnsFX3b1UPPH1ESfz4uBY4a/+tYgkBvDeEg+Cl7FyrDM1tjSX7kPneuIFdmPl9DEqDjK+TK7s4Yna3kp8vsf+iU8EF4Ez2LkNV01ohP7+6bFZpjx0BzWLEYDYD52wkHAu4VlnCT/bpeMmsdbG4EqfUF2+A9IIgpeMIIMBoO7jYI4jJnyI8H7IN6Y5ABpWL6yPdgTuQ+psBh1npk/XBOwqCdMbxVyKwaRDU6DtxNS5a9DlNlaPpRgLDegMu9YLZPV9ls+cgU7bZUxTM4z1NqCNlJQq5QwjpejAz9GCoiA6b7F04AkCvT/LFvdqkNBDEMntPo/kcspWi/CBExEMhTTdtsJln/jWyPnTSKKVhnCEUasMdlkBnnFcx/rDlGZYMHq1dkuM6hv29io53SYvZ82AhI5k7hIZz51oYyKRLMAgOYBYQK+7QOep5xYbOwGv0T9ACCNoBtsOtsVgE80RLTTMbrRLr844eQnVw5HSrNdi+Iks78NcWIIl5z4RwvA6wy0E5iQIckqk7+/wAFTA8D/gA3PvLDJHos5LqDlO3DSefhiQsJZDmPQDlKyTML10CDssDeicCjRfGcSQ/aZIw44ogBuoYac4Fa5p3hQ6ZKjlIZGFYVVgDUusAp8Vt9DkKqkgMuL0Z0hOXkdX+5u8eKMUoPIAICtENydhXijB7cyjrIt5gYLXaCCIZlsc9RB+/gJhyeHkTd+DYW2R30tR0UQhaAcJP1QAiMWwahisLtNrJvcfWThhsQCAIqCmD8/VqoKJApKKXz9Qe8y1VUWpmTBzgxVqKi+cLT0cRmTHlerymMEMb0gQnG9Ll6ohI59LKwhshRJ52jEEily7WcuJARCVOl25UNhmfTsv28i8LMPKGidijIgBBQhSYjBopxL1hzU3l4vZDdXBvUL3ukQ5s7iHa3LOYzJBonSM4kVQTrfNqa920RU02dtQPYh5Vq1Liv8lQlliaFXycE+ECetN+gaHuaCIkrr+WwVv5JokwPgdCueOk3NVybNT0uN5FzMjhayBPt7b4MXBA9YyyPo1qmaoe+hSnC7ZSsDI4NJV7rBKuxZXk29+xRxZKTweIqHhtJ6MNWcFl87JdVVTQcoZ1nq0+z+ffO1czskhYTiEaiNRfprTXok2rMRkFrqvYmkRXKznIChMSdibusaggYCXCTBj9Ie2XBONvjbey0B9QVdcOcSjUzTfGdcitDxDR/hs7IU7euH3E76KD+m5KrO1b3nlKzZH1bpVvx7VKFhbvM10Sx3rJJJR9rppt0H4vd4CkQi0s/pLZj7/ilk3veBiC/S7pbG9u3eX9OO4vvTdn89Lke944iJr5HLWv2h7X8C8h/+mG/jHIchGEg2lv4Cu+T+59utULLKBoxDqGo+1GkUkIcj+2M7fC9/tH1JeRnL+zNswhkAT5u907IS+rfaA0r6nmzOcyoYx4qbjE3zWZR8Ill64o5h3tNaGJOhudczUQkLsjYLL++T5Z+IQR3LkLRi0qKZCtP0ZhASIETykbiL/fSkhnZCkJWi+iqVtkye76Zu3120KyiswWJrfaSkrxurCvRPTjpFZKFLF5OBBithbavESzYdv+ZZAjROP3RtG4PN7UclcumAkyefLIY+KTiPU4JkcXmTM7kl+kWYsAklPuuZPXZXUFnWJlDhY3YqSxXewCkX0Zed7s0dfk8XT3qdKhIEZKJ/I1hojQnPvZ7+jqTAAfrHBz2iU2NUBqCjpB14HA+yF8NpXsbPxpG+Ix8c49wWh+bi34jggNvJ0RH5KFGDuWdIu6lagN1Wt+wVYoDjHksKXNYYPaVXblV9R3Ox8RmWt7G3RiQxX5hDx6Jvojhccb2X2/R/FTmF/qXpIex5rrI8KQAjbqwJAdJ5d0EC0GJN37BAYmwh7OFw44Iatn+fbCB5AR4TlU0haEYNWq/8Qs0QAfu+pHS6cKOHdiF1uJZQwiWhkwmrRDKJ3I6mWKsYGCS4aQNJnjorZO+g2lG2zu6Vb6CtW+RH87MIMetGIahuQUXRfZcGski979ZpxHUB5b4CdACMxP/b0uyRFFSer91VFHWkg4u8exyqyHHnDgo91Tmfhtxm7D8of7jKLUsLzipoF8KMQ98Hfc6oODrvNd1T3lY9NzXApq5lrDkUlznPPy3dhA7XPgtKKfrY+25hCtcen/d/tkklTvJh8hMNdYalv7GDH2chFMzogxHlOiQqeA1BALBK9OpObKvMlRNrORVDT2dqrnJaYzq7ilCJbF1QRy87PC4LXV3cOxfL4oXmAcVuOG46EbjQeYi7/4aQHY9bXVkWvmQa7BUdS+K8p6XSACmSDe4CZwL+8Yrq1UVvIsKWL3jdYYDrKoujeLdwfrspFBUqcJqVdHqC8EXrFH+ryIoXZWfPpt4IOuDenVBQ4T84+T9xuPzFvpr+3VT5a/ErEi/1iHWdAEM5SCu7niSat8JC6112iaj9VtMlGdxeF706MQANGlnp6n5tZXcIUGuy1M3L9pqdYwybbsq9PCDaBRp0gtZazZhZJL/9nW9tHTYlB6xTbv8xuPrlq/qYFU12NfVr9iZytLIFo9FTskZkDHLDmYh3XN9sHupdwosv/bPgBWIGUGY1qUsoavimv/5Dzsl/ryMyK6rGVzjXVVP4nk7UTcsTZef+WciJogjATUnTiJuNraNklZ8uE1K5JwkHqC+u+4/cHy8bp9d6wqUTK/EP210xV1pxm0C0PSrbEezAem/Ringy68arPB+nT0elfuDexLKaALcHRRok4qLBFrwmqnGW7bK52QkuS740NEjirtD1caoNDP076n9I4KgnMIO8tc2YmDN1omkdo/3x/vpjBZjC7Luzx+CfD5vWIwUFlJfhcD7zOU5MfZAMdbMIZSBpHoct6fNS81jajRC5lOZvZmoNR9dVt7DWNUZCVOjcVaKU14iOjvWmwASkANVtDO5snjvygngg5rAcmd6aFW4ySAjYSG1xMjRriRFi6glzB8msBkef/2p168ZaoRGubwGJ2NAbQIgSXf9yZjBkvnZ3jXId1dTNsU44KipDdbgjnmLJqX/ti3Y5ZK9FhJYxCkeokTK65tpfxeTQfJORFJwPh7eR9WIKctBbjgwmzRZdZb2M6b9Pbt0tveUQba9bENHIWctqSJUzTthvD9er8cbkLhXCXjJ3pCF2OhUT6SPxqdnHBsmUBOkTuWcfziivwVddEpNsTH4a5nDjJyGp1ZeM+OiTFyQtoME0TJjF+05ZTUrsFc03NZ6RRSyjelBgDgtJ1WSY5hOiznGsH3QKNxJRgeGFAXIK5UtNW3tpZq0adVZ4FiNTb/ZNIPctmIYiOYQBWYRdK9FF4S96P1v1kTDh4facZs6v9b/ksjhcEj5919eH10BcoyBFmFWDLLo61FOTJI/FM4alVXIZEvz2gBYJ96ggfkRzWhaSqL6VU7y6ufWfAwlgziwikyaBajbtEJ92/QGUhZrOjysb6Oul9YPBrqJe6ewjRfihkFGk5WldHXipzshvJ1TaUp3w5rzaCINDfu8n/T8n8MwMITstSRsOTE5v8Dj81bZhIXjjAKVoaNMQwJMyWow7DYDo1dOvSFV5Sh7OfnBNpWGGLBDGBM6K6W9gPwRJcUcVyROSM3OnJWNbfHiM7PEYst8IwmRuuDqCsKOzGD4RLPmLrkPdHXiKXq/oyVOVYrkjZXl615KNoGfyTeBAYDN/MD7RqE/wlBtsQ8TAsWEdXs9ogeor583Xz8fX/98yFYmo8JIZAvqGFK23Y560DZL3YvfsZ1sB6ZhpBRPF3h44/hszJ5rsp8ONsKzhLRh5svFgcr82LsOi5MAFQAmJt+PE+ODYFBfZi10XDCzYu8tlzCVDs/eJmogI1laI+X9+wmWIAJI8Ol9haxgP/qDDeh4NCbL5Z1x8L02/1x2fNwqOzmHyd6VJC4mupCUL4pOIVRgSTqvUh+Ck8PPCgbJNz8eLnsWpKvi1cIR94IkjaAqx6BZH8r6OUNSZhPZeLF5wAZz4OFxP6c62l7rfgKpQLU88fX0BGyzJf0wXshqIFOWtDUZ5bg1mefUm/2FIPmINCPITCDlLBzfaiEvhxTmL4VxXssFdKz6sVVNNWTRC4XHWJ/ipzZGEuU4XUIaCMR6ghJxHIlRqRbSdMSz2ioNI7AlD8w5mZ3tFotldHyBwTMNLOSTB0DxaS4QdKHfLTgoIcwCWe4mkwNgoS2TKhIM8vrLdMnaVLDo4qXQkPKQDkDLrCca/lNR2o13y1TqKRdrznvrLYNKQxc9xGzh1lOHhbmTRjQ4PDnAPp3h9/NLOT7b9Hk++HIF98z2agEhq0ziydx6Gse5IVxqCxEZ8H7GL+AY5DrWW/CyOcF5/tcpDFEC2MuFNBNVRjsZKnsYLVojeiXvjU9XK4BodGeRyEHB1CJ8jjWxlsAxgeZ0dIDE9x9Mwy7As3cKLBS8mxezSzgi1srVbFxzpdgC5WrXAKkKZpxEgPjc1Lcd0sDP/LINM3++gFg0PlplzwIMRjCUN7FOqY89SzHYon8msc1g2PBCXRjZudGzO063jdM1MP/Bb9IIFSQFSImwSimvJ5MIkRVFlRvMYTm6Fnb2H9o6y9TEJaxJGxWf6N+gU5i4IVFAAnXoJNCxDRqT3sH+xI8hqGV4l6BdDCPWGLIIxFZp44NJP3NXtlgZeo+xJUgeV0HwoPtMs0Fv48n5fPx9VD8Wj88PTCQ9QHp0/xpSikibDyD0yrG5m6pDo4aC1igEmOwMnzAxlmTAJcdwp3Y/3dOOMV1shHh8NhQ6UrAdHVXcyfSmLtbwvB6t+Uy1hA+pj8hPSKyU60jh2I8O8CL5zLevJa77MEySgKDOWnrA6kBqNz/q+w7VmL0CBQi9pJrgYEhtF+NAq3kcbYPemGBTkvFkwWNdMx22ufqK3M9Hmz33zT6kId1kZglqs9ey21ankSoixt51w67Cz7iltUsEgQLFjIiRM3PC9TGnqI9sMKgKxfiCLyaT+ndO1huhOsxCju1v1rV5HYl2AERByLO7PeuTIaB1ENpM4UU8UTASGJzggDW/VGu2tj3u1oMp60zYehbTMliCBgOI0xrwsFVWNfK5jWO4h3gDr3OvAp1kn0A/oNN9fqvGZ9H4eHz9fT4+zAtqT2FD0UCJA52UrnIOpY2CxFrLjtfpW2y9ymZDjjuB7gYoBUGJnlrKwoTmKiuPCRIKtNP1Ly+42eN5CZEgE+v6OmljKJluiLlDRctRIy3P3YslCp2eLMFGXoq/UOV0PPuFz0EhJ+qwjslMrW4zNjKJijxQ0dxRIZvh8gO/3m3h1rU6Sw+YJe3lGA5BznYjaBE7HZ/f/cdHc/Xj+fcWNx/pivIiQ4iYgSLIljFzotXIjAuc43593Z16Jglxx5Ldwzr2vPCY0pXllCkP/126yQ0Z2C+rC4btUNVY9LU3F3IYpVg6H1FClyQg7bqIS/vBaOKp4IfrMBl1nqM7hdw2d41DJYnuIFywVeY76mRK0IqWXtYbYxoMU2GQ4XqVrrXgx5uAO69lDzdiRKhqgWbqNqeFkJuJjvjG42Mr68uNV0v2C7qLNw/TwHfqVdRqBhWRExtu1zw5OYDN3nUqxpPFNamHTaO8CHzKsDOEcqCP2HGby91zLHGzDi5/kbjoNB6yUWyEqOzk2wRpFuRE8wJZLTSsIM34zQLaGNTJRaANOQZKL8m9a5tlnvNRpQNn2GWs1g64yUb6AANOHJZB6DJTY1pGlQlx8v203jooVDBe3+4EvYmEjdZRV9mfV9cq5K0Lkvwj4lyS3IZhIOpDuKoXrtlrkQVKWsz9b5YxH151foptSiSBRqMBOvmcr5v9ARINuUT5B8jZduP4cIJZChg+1YFGyaSl26KNXcclVB1GW5VW41pjmKqaCsNJD7DJlCbI4NSo7vxIh4JtDF1VRLRJJwKVP6RPH0t69+xXUdtjkghOyFx7sWJtlWnmr8gK18o/AAbuhylKLY1MFYgpEqNXTrJFE7wgmEnOHdgJOjQ6GuzcjQNtW5SAsUIIcbkv4QVdx2EDJsK0sPBmv7u50Pn5EuNDKfMVj899H0BaqJ4nJU3AEW3AGktEthYQhjLNAIVdz40pI/UfghYGrbzDOKAu1zAP/QWoZrZ4C+2dALFVONFf6WIZg3kkEtHJL50S7rEmtC0EsnfWQX+WBokEHMdEkb65zwwqgmEOXEw2GxajLjCUnKU2T9WPjCvm9bwSeWnEmEWt5hrRZ9LXlJTtyS7PjK8rYmvA7GYufC8WRaO6ySwQTWnAxfDOJPvePzL07w0iv8D8opI+ZAYSUt7xKNHollneeiKrPc3ta2+c3ugY67Ozg7G0dAcBrm0JM5vM2+45VxwhMC2XYbP1NB50IepKsb+uYcHjjMFSyLTjw+6XktvEOcGRbI54dFEjAcJpxJ7fxmMFyuQsrRUjONnzkxwMcXFvJO1BZTJDiDYLq9LXpMevIoDLqq3RQ1BGnayg4F4DWBlnkwrtnfVhVCmzFh5GR0vIT2AH2/4cNEKS5/fz3AeYL02Bjz1PWJFCdHkQt4aARkZil/dMqAZITBt1GOYFz8oUOWPYgp3ANPchbVq+TFrT0LwBSLvouVoC+R6wBGxkMLMsi7B6otHHyhggjBCtvCBCGLqLT3qK7uZHikssNAHLJYoDPrcsEP9AcMiw4ruebjVlpTRalA4bpLr3zcI/UufFlIl0myo+1uvWzC0Nu/TMlG3NzqQ9afgoeDH4RrzhzYY/2wi/Dw6fh78+9/28TESSQP8riWEf4QdoAfbyPgOIAqcjxfG4wjyMYUvy+uj5GEKZAy70Ij+n39m7RplsV5fcrCxrtbD4Jp+kiaTdJ1Yo4nyMg5NEMQdwhI7nOep7Psq6Xk3Gjownc+TEUlpaG9NM1CJCnDHMIByUdXraUwHGyith0NrTrAoyRDiKTko+iJoh6OWUtoOnFTzmqQ3NW/UgsQ8KFahMRCACsh9Or29qGZo/D9h8xeZQe3+BT1ioEACsSlkyEcZF+qstFZrQZ0AHTjWQsGxk81J+hkAgtm2r9ow/XNg7EWMjg7UNy4iZBwc4g3kKIDcrqfAiAC7DxJJFFM3b/GYMwIPUOVKBUbBTq2MzTMmMHc4DM3icBcunPenKctUiyQafFbDKKUaVOsD0VnGXDFay9PDhCqKE6JljUa4ZQgpzkGQAV+GYWDVOVjoxbAyn8wp+fO6Dwnv/eCi2DyBdFGnEWCAjKBRGNx1lSsqcYMEMqYOtIziAMus1P2C/Zmwwyvw0ilAy8IhhhQ5WyHFp12EtM2n8r1PqmlkyXyLTf/FZBos5KrbvnNWFs96yazasAnf3LsQltVIz3PtE3BgHg5rwmECIqpiGDcg8UZcyre053t6gEgX9J2eQynpEKRG10/pOtb6SG9fJZzWTxWs1cUF++k7J8GjJhiQoS+qafOvrh5LmeUDkydoHj/dr40lqjZ0x74bxEawEh+N2KlM4Acbt7qlFnuSxy22rvxyFDdAlFXg7GXwpwC7VdAOT2J1lCQEj/D0HomjXe9UiM82kInvJx6pARjPWeNwsNm1pZ5KLySbw/LBXkHNa9TvUfzKUFloWU6C+oVuDO0gU+2y0dRgrWZUJLliG6woH+2cQ4qYl2RsdiwhcfkjP8bHk8M4eo0ZXLA+qM9lcz34/pxsO/M7lXJ/tjr+w9wIFopv3EIUsd2PC3ZsyNaUws76MjQvqfDzII4P+H5UZmwQsVmZvK2Du8ItXjlzv8Xhx3QqTvlvWp6B3Lp05eB5sbq713jZTGTHHioMcwZwKLoPKgq8ODYxARYlNKgQBCmoHKLP1tgBJG8aY3KCCGW5Has+1oRvHNLInTMMELN79eDRm2WrAb2F2CUBKy/UkYTJRfA+Uy326QgfD4sfwE4OVh56xn9+bc+tF4beaOQh9bjRkspTqJZSv0VV40hZnJ4louUxTEi0naOpQb7VzlZTTJ4FHAEN77jYNVGiz2bmSmqKIzVuP8CAALZzr1wlITFiRn8nUGxFapATG3gy8zCwF2J9L2+RmML/K1kRDPzW2JkaWtgBZ8HIa730iDka6OgsYsJDCMAdTg67vIZDhFOtQVaKnOMso2otZCQJ69Qpzl75lkK/kRGXN3htXPxvtuPrzReORi1DiLzx5Xp2U3SS69lo7KfUt3TUFmEwqb/jRHiLXkcFN1jyHwHF5iZAgokbr+iHjmFHXOME5YmQBUEtP+nW2/3oK1h5QNlDlWILZuAgugKAheNQwRoHz1tPdFWuWJS061r9tvhueXDLaK2Y/v8YA5p3DxXgAATCWbuy09lgX3SpJtfoyy/iVGMqabZXKi7pRn8oFaAFpTgdjCsynyLaiVp7BZXvvHHz9+6LvsZyBK1dIHqDer4XbxGPpxBYUTlzgk5Ci21o8J/YI5NUt5MRFC05zCq6xtra7nciGbzFfAaWmbIUETuE5++wwjx1BgQOF6gBNa01oUdEytGdNbFJpJ1DiZDo7g0+NIfGta0WnprygMeWxYUbY2bIU+CRKnix8ncjC0zevCFNxAUwCzWkUhL/xrmDuBO/yZlUDK8fH8iKOMIY8oC9UqDrbC3r/J+RMkqWIYSD6b1ELLuBlBiy4/80ApV+8qBA0BfSv9ihLqdHAbzw2Zuzzk7/q0yubP01f/GugskYpn8q44RQ2jvJISN1Ib4M0+EiI0gqJkk7V13u0x+rRnRx5MW+W4JKybdY/JC+T4Jo5gri+4luSoZI9egWGIs5QvAIG52pnExdj/lrZNgytzfa6W/dI5VB6L2WVo0koLkc/YapIg733qbjpS548GdWPZVCRVJ0WZU0YQ8h/GS3ooU549U9KG8GIGsA1JjsUiuE4I2vdV/OZ66jnR900UJzEuy67KAaCQY+jihyiIqqQbRN/lWnk5ogxT/QXPQdXtaF+G7wBoWnF1WzhMgCQwTkgUFU0oyx5CcI/5eyF0TVEoe8JLCvZnN2/tVI0TkfNGnJrRlmeccvV6KVNEUGzCAxk+wZ7TR44IjDpFyBA8MeJusLc3AENoALzqc6AkNGeFi7QhystbKUKPL/VojSS48ari0Y9vgldo3joPLkHgf4kN0/4jceJG8c/N7WeK0N891hIQFy7hveDD93jmhdaQ/6duvhUUBZUblaRPOr3QfY6PbuQvy0xZSKWqWesSMnBH4LrJClecYREnA6/Y8/tdzusYYuslQ1GmBvO0kOFn7iXpdKTW9HuuCaa3ChZPw5eIiWeoKjjarvaxljg1vHPSeXRqY0sugc31Z3S/BLFBdZWh0Ix2eoBulxYl/Wgz5J+Lp1YY2wEAOpe3ECUZ9++N29pWjOveO6B6RjOL+LdTFgc9HYar/vqFxSST8PzesRcLwFkAugI3YIfEX6Fe2+Rw5VnTQDA1ZP5bwHyYJ8JV1yNGzjKLCEFfG1aqrzrqJinRQfhSaegDU6fUzwk079uepBMvR0HmZylciPvSO006Q3mcfoFRoxf2Ev8GyZFmdAI9+qTKsJufwsFpOf8U4B0eHdjIuGwvLGii7LzHv8rG2V9Tsn79geAeOom10UjH2M/v2Zt4igMDEdkLYXBdYVZcwWat6TJfoFcm0OKDm7R+N5Ly29vCEaEKLEr9mZA60os25dw5/AYDYnbTqOSw5S8zLXe0Hv8jCIk0zGjTLB7V4177DKVeYgbHkLY9OTMjei/yC2rUGg8Ycs6XZane79dD7CztJgyhhObL8yShq+H65lQwTJKyBWOxi/lDxSFUgjPnZBLVOs9BV7RR249JpP3n19XhU19yUGhsvRmkv/K3gTRJCtMIQwEL/gOtH9QAlNzECvSaIc0AEC4Dk54f5en+r2iLB4P7rclyngR1hG5ZVPsMQpXkw3Wc/0VEKZCOtPFABs2pSu4Mg52bmyolxe/qILcrMq6gzyI+G0edzfFaiXtUZGF5BiEUAhLod5eTXlLjhoRai7lmGX6ABGSyyAj1IpekhnS5G9jBkFeM+p66QFmP8dCVo+8MzqyxPW9VG6LPVFVMfB2Xm9pCeSAssIL//N2psZ8tN2LScVW2MABqDCT7WESS3BWN9r8elIghiRRH+8eaj6SOWCaHiJrZoOROgCyISVqIEtjcb/JG1PWLi3m/UNpuH01zblxBqeTdu/GErjbQddL5gkLHU7gLXIVPNpA7gBQLawrvryYHzw2wcZAkmkLVJIaDGA5FOzx/LgrK0v0hepnSCQWftsH6TRxGky93QHBrOrEOSbS5prjZcAZqpNGgGSH5p950lEaVMsJ4kGAt7KSoHC2jmmVYCmJOhfYtB6IdkGkiPuAGOOKzeBOoQPK/GqXB1KLZTSJ7f1wRNjr+DIOJ25IUJTivaAQEc1nWtv5AShp6ScfXzmpvueubDDX7dP4oRLxWPthvO8zVn7aIF+wmVpM7+siVunbD95KvrKHtMrZcN9k93hv9AFoxXhdEHgyYyY4h3f04XusAKkGl+kSEm84ie20mFnYZbwyWaBHnj1NpE0PbAPQLkMMlgznBGQn+OUG/eZedOUWN5vPCMkm1WARA4mFNIdlHR7Ymbf8j+lrHPdy0S4kYo5w7PRcHNGPbr9YJyxT+9A3xB9mqgoJ4PIIPCAcCNv93tJWaXFw5A/49RHNwUA4T5wYrNlHG+1rJ6Hjmd8HfgFPzSPkZFXpC7ZygdnChCb4sJvjvRnRmb0NgvZR8AnFn/a0+esdfhmDhaZmixB+PXzCaQLsFIKepW2Lwe4WB9pjW94dn59I/SP/C15tcTzXP7ZNsR+bAsh2GllFOSaBFldEoLrBHtKwdB5zKJRsSEJR3ifpMkAHi2omSb7saicYxY/sJITpzAAVeTgM7W9/eto6GPG4fDVg9PWL6p0GpCzcPkDPJwHq/baLULz1XJ5/ZEqYvwB53FkHrN/NmrB3YaB0cBJe9IMeKry7AUMoPe/HVklVf6NBFWB/t1vBQtmrFHAQPZaXGVuxMSoCiwWI0z6wjJ8iQDnnpUA4x2+i7+PTYV+bU3mt6Vmle3/DQtrus9G6kSdul+lYu8JQPEvyYa+zRfrmcLbmpb/cY+Fp77fd/Wc7bsC+5f05NPckb1huzO/V1K/dnHySmDNVRH9sKh3z7ZN13FD92ov9n5F8fB7lN/V3D6NPIvZse9euIsehi9LNbBs0929ypSD/FOnu2ZjRl21G+Ja9w5aJo9fG/PzQvt+lay+5x/2PCfGkDlt4/O/zxdQNiF+EmV3K6zAMRLuLPlww3AUozP5X90FbczCHTPyQyrIt/2g0VtLJQ5Dia0r1lHds5kr2ducxUIyZ3o8fnkEr5+ly6EjyCSaega42kqTYPneQJJ0ThgplfAuluy4d980/BY9XAWQpNTDL4nfhkBmfaG9IuitL3DpqPTH6jOk9ngKfVdhB2G7U3nKG/JytdWwvsXeQXBLJqfC3ugaW59t4vC5hEekZkASOfSxHa/FyxqghNSs9f5IwKIVIavKRsbeZxFgDuG5NiQ5JyCzdpte7jal4jGtr3onCCoZEQVKBvwxsoo/kequdguDAwI+C44UoQOp4keUFA8fHaiD0s+QEZCQ9bp2iPhPKJM8W8Y6v+dTBI/885x30me/2Jz356TbzmPCRJ83dHbhIpJBKAMb2j/v6Evxoui5Q+sKIcEWTPFEqmUEVtEa5q3Dv4/u53T95Dx55QJGI4ImISmOEmtOr84UagVONsziN6IGwSrNWOFTWvUfC/vzCAlRY8kqw9E/EuDFZOPKVdzSNmILUSiUY8LEOeVPNZ/y1ZZ6i3WfvR3pSlvqasb7yBlQOh4+k9vWgr96ju3L9YJTkWHJSk4st0bZKyi393FKEx8zGo1G4FQcoqVwfhgxQfyjaSG7xO9+zm6ORjNBIcdXcC9KIWlbPDUTc7x7mMn+D04hBs6ujXts0nREgDlwFdfpgpQRIgnhBNRwx2ga1O4q4Z3PO+vPLVPyhSM//AqBgCSJ5vsaTbjRJf6xy+sfI4QL++iOHRUX8ofAJM2vqB6b8DopvR5MKd6sHwW5EYkdrq5dd7Lk6xQzVYCBh5kxsgZG268WEpykelTk/SxmFeJ/72li80FzHA/1LLL8hKbfMALHdh35x+rQVcFa2uCNqwXU8gIBdJUw5YeSmJZJFEcOd/AMuJEz+wP5GlEF8FFDBjuXGjpr1+jpb5FjN5FnwtK/uDGMoSgmjyAyNJUMN9xJ45GUGYb/BiC4BpKbiVvk0JeE86D7v9UeoueBaDcNAlH0gjcQCjLz/1SGSHh0Zq6Vc2jRN83HG409fHjFQtRGplReRnDfu6u+vFA/tfO9zO7sFVzJcws6aGTmp4Lxy0rdw+m/fkz78j24GrZ3/z/m9xuLlTexVJVO5GhObD88n9Y++qH7J/gjccI2DOT9u6tHT2Mg2P6E9SdF05OutDLmYveMWwjPtTUs+4ibLwlu0lBfn5T2jnkgMMWBVsNlb4JxliM+gcuMrDM5IdvtyTLXtjzSm10JbbJ37PkzexWIgMKWT70n1Ln8/2l4XT9NrG9GQAEM9jJ+HD6ezOC88W/j8cZ2SckWK9u17TKJcp1EuW+nuvNBv7DwDxDMHy7HpZ+eMzq/+uytCZugYJvzLmTVOK9Sy9kYWSJ72tmlMvZT3yv8S/lLfXORGfIcB7K0XH0QtfVMpi1JjMrgGYxL9E5X4l0iTJn//1mn8fW7vA5udavKQyHoHGBpobTYs2VlRZbhpuTww/Lfwk4adXxR/0Mn2uLL7XhS5kvFBxPtlO86zcE1XTGB/cW6wjROeFotuYSQ2GY/CI61hsDQlVXOdtdIfefcTPr4BWFLSXk9Bxfj5lmW8wLw/KkDi+XcAeaxBifE3Q1hnOWVYqQxaQLFNNLOwifZsM4aLyyAD5B7u2/GnaDM3zyc76Vn2ud+JBF6MtyY/NRF4du5L7qq9C6Te0UBSmfMrp+OB9bBcNVqA4XK4kYySSvTnV//yEMqoBiC47vlBXmGCR+0xyIMnoUZ+nu6THz3DNe+q681M7q0vK0PNbhrcTiQitHOpDyuEfoNvcOI2p0fmpTS4obkNsDi+6JS9aRgt6NsIy5K5xOrsT3NimvcoZwcUeix67XWKJpLqedl4J+26eR/p3F/X8JZFot0S9LEW1Loa1CGm25dl229vhny4PuLlRI/BhpcvjbwNavIRo4WF+KBy74dUxIEyv04d1fYxdhZ27cEe29VrikrA3W5tPZDsldIVlVU7m0cIhE8QisP2bwNWjsXgAwo+Y469xo4edO4ysA4wQTUwSDa5A3lvbBEw6P4hvOnmlHGWYvg3dmh0QZ3l5pxOPHN8RImRE1xoFWcvP1KsjCPEs+KG3UzQnmWPl32s1FM4/NWJe1Nd18bKioGfg2fG6eO4mIEt6/bCDgCwpOgp+reiv/KcK1JFamRaq9stVSTrD2QcXgPHIo3bM1i8lfTM+UQCU74isemPh013kzPVa1UV2cMq6/PDFUtkSJcvITajVhjwl1CEBWfALXdClYY9/nEF+UZRHwrwHwTjNJ1/xh+PCNVKPx5mZ/rXG81zPPdztabccnJbvcmDjQW/ZT1myGX2+b3niqVf+Ssy8DV7Dd6Sgs96wsk0st3UDK0zuLa2U47up6l6NmmusAQlyu8bkguKu+3jUaGKg/6VPTlod+88/zXcRgt/T6AQ+NFg5oV+hIEai1Bzxmhjnlg0SLt0pCC400dF/5GqhUUeUP4wr+mmPf44aklbibk1XG2OvRV7Ro6tg0gRq7sf6qEWOxdFckbjeQzFwDqLPXRWx8AMKSpSYaX7IybrBdFxA127+o9Otb5xsR6edaalTyQXqqEspSL9ojuXH0Hchd7kSMiT5yIWI/6DnainsA6FIJmChog0/VxFT17Z727uc7tJxh1x8YXX0nVcPuNWN4EIyE7FcMHzktPU+wqYqRI1Ik48pAjkkb3BQVjRmWWeBSbP82Kuzl1t1yFyQKeQ2Njg1yJMcei65tyB+qfXg3yCX9jMqya2G/Kc3XUX+Yg+1/6JJcZamw7XbM9KDbx/D5mkB8cn0yOvgsuJVZLrqaSpmyrm/2ikeBI3n3CwT3eQ7Y24IZs0owRYXq029RDBF+YNpy2Lj3dU7H6eKmNJlL7qFtZR1aHPUpU74myQvJ2vI0PdJ97kUOQLyfHg0ZGkhi+DGx0krauRNG2pzJNAqYPrOP+wVY3jK7f2IbFG8I29lh0BHCGMcBxOJZC81z98m0uOFEEMRPsWLBCWZoVYhGQJJO5/M8AxT4/SCBroqU9WptMOhz/FvL3GBmAlZTdQi7qxXTEzqISxdVbNbqrdIG6MEJkuO+pbcMuiBsg6LBzo40iqY5uiCTglrIJ5MDPj3R24bXJW6jNIbHponFVfgTX3U7B2IvaWRmimP2ko9TAquoHrupQ7rL4oniBCLN2qB6xmmIYj+WM43acVCVTWB8ZHrojsMDWx5u2wZnSWJQnHDCCMC1fKmx/bkK00ht8PXg5c//u7AFZDBDML0YYykwP1JrdydLek7rnT2rHeGoRRevi11h2orGNWtx+zCe0qW/zdGs5gDlSzFjHanNqIQcKgq22paXqES+i5xnAnYBzWQGDQcV9Rb2w0t2hCR6qXXVIp4Vv3JB8g0aiaJLO40LK7zVaqzxYp4I4+OKjjA02Kz3cgf5tP96YGlGDFnUywvzCbCu+n8ufZKZ5B48YRiwbKdX5IMBczxMVtusN6Vqmqe0whGCsGf1EpVj3uCCuyyLM9yJ/YTACY+I3mGlnsIELYt8od6q5NQ1taE5x2n93PB1bC47FqsZcmq5sHG8oXDex57NrvEnM4r8ZLunE2hvF2Vlf1bmbxt+0E7fcUXSXE+wBJEAr6pMgOkU3ffk/0Yi1BIzy7kXe//ldDBaDpUbnBW7ea6eVkJ1RFOm7w/WFnRs2mPCF2Y3hi06rD5xbkVXFzU2I+RCoUJ7udMlNywY4ERvKCehwaYeIwL35ZiIUB5fe5yJ1qh/jeA5yQqSx5ej6Rk5iZgybOBRc0XThOsp0XX4EO3NyMKu8qhhBbrcPauzuT6HVGtTdQJhypnR/M6T1pk0762x81v0IPvJ7CIkHVVBpwYaOndenDP2fXKUhOzfMN1+w49GQsZhJIkSBU8LQMX1U8ZjN8TPoD0p9gSWaexQP3BLXyz4ffBag17b2phfXxgB1fejj5DKNFRZnmFiticb3HKuYcQYqdPZmS86gUUF0uIspUL6Nn667cssBb7caeVUKpeFrb9ufnY78HzqC9XuLrb7DyzDtqf5wtXhhkL575Dojl+B84ofq0hjVezOKWoED0mYks00uJpovsf1M4diKrceu+DgjC7PFa75V8rLUCYtOj2fDsMYjJfaWeQcKVksy5hmBazQBrNDQfKqqI9DUVTjNK3t8PFL7lIKAR8C2HRTcaWEIHEzkb6m/X3goVWo2nHH8VoEiuaSEM0+eoiq4SrHFV/Rt5IeAyO/TIPrkovGf650e39jKZ37GJU+Rvs7OgAze5BvbGGiiFwZvbMalMBzcg/lH9+16kgdS90fFgCh8cl19xKavR+uNXMZma4XWkoOIZY5FMjjCTGD1NFjtzoKchxI2BUHb80JNJAvD1R9IiPPNTnpsr+Mnm76hidzE3kOq7mOow6ZGfwHhtEPOYLaiQEyOZORT2Jzh1vc/lRGI0J1BkAfo4pdFjA/Jr95HXICVrhjfoO/Qk8JydSHMzCDttShWOO3vqg/Y3tvwJKWwthfMQ1IQUZusZycQEY6dGAAhoHfbsPCxBDpBeu6Po8MXrcWLkI8NcR5HqF94K21hZxqH0tQrj1TZArLeB1djHTDtaxXa6EIL0WudnUPC4WIiZQZkRcqmhhxdAQqsC3BESGYBqLmK5raNM76bW/EL1/KinQaWhGw41txSpXz9tM+wXfa6iAJPWiIs2ZrdxdTd10ebpggApzfll+v6tltSbJHnfPfcxg8Q+ezwDgyR13Aa/lNqssYR0mhQns7xJoRXgewkFs9Uqh2kPwzA+IuKSITsD7dk5VZkChOBJyVcrZ6jAJyVh8cFsi7ugtjr+pktOv7ifBKdVWvxojm/izUmfGphxuzZDZYyhXpp3NX9/1NfE5x5aW3PqACn14nVzoNduSkkTqtnkehWZRN82TpirGWQDYIAyCbR9nn4ICTXtzH0X+L4VxEOT6bNenIxvOlkjGJTAjHGcEVYcL+bGdYMYqbOdWDMdbnshg406U53TnrFEki3uMWF413rOoN2vCtxhDHLgGSdGZq8m3zQK0x8H+UhPqhqeTVVikjOLm/RvQ5Zw3rpQ0GuQM6WfYdcjpczuT7o3EmH/PcptvkAkn8Poj4u+cznkgiKytoIAhICk22mRNqnuugudnHcE2/F33VhANjcyMK2Po9QuY5lcpDi+P5MqEwtubx5hMu19x7cpx+8Tc4xesDjypXJY8WTgTSB4NDPLAYvN0doKsFhu82q0k0A8xJGtQ5PEsQP8PRaZp9CQVEKSWCfNjFNfuQt4cQJ0ybJsthqyURhuXxX4hqgi4sKQ6nY+Gj42vPux0SMYheIDkV8zm65wVbaSpmsHJhwr1TvH68w9OCdiL1SP/57Cj3IxrDRJgRu78zVtc6jgCjPRCjaO9fg7yo3DULVg7O9VLFS+l4UUM3suJpcXsmdNUnwURjuCmFEowMjiafCpboCan3SZ8JAN+QmT8prFNqukKZArZby9u7ZNq0TKJVsdjYZTapbWQ75pyojnw4M9SxbBMik1/+LbjHKkiGEgOrfgg/2Z/RkhVGABEve/GcKVx1OEoHdhupNJ4tjlsp2GzyaG4k7YteNKJ+09iH0mJlePgqwxF4TVvNtcugCX9R6QNvAZZEr6N2fg5eFnTMdGDZRT4SIKKRwanOSMwrN1jMUdw7pCVZZmmEiQQ39jmZBDZWQHHh8368ukVQ94YP0xzHMHzngfnGkubb4YOTuQ6T6HeWbR7ykhUdWSGw83d4JMDMb9Jg10WxMwVQ6dpNYaiDOkYiZdfFLMZLW7wv4wbxRp14HjnUPSKFe+fmuaMDEPjvf4O+XBSHPHhGN8OV115sAd6iZz0IwWiNVrzH3gny+qoaladgZ1D3tbEln5z4behm4QU16okrPuPiTIK1gT40jRvbO6wo+0i+kJtScZFSBfv9jP+lZjIFG/IAsOxLo7to3cAVEC7ICjKsPaL9QA+Ee1wtWuXG5/pphGdCCN2zfsBxuidxIxkoa1adZ7U0S/3SgEZt5aYO8PcJQgn/UNFPDA8Ms0tcIkzRtggQkJ7+E2eKSHilVM9cp3OpqCrDAvE+WDMUBVTWNs9EjyQg9COA0izwUk1dNC7z7u2IqgnYdsEkqymv3Ignd1ljbsxAiIUVrUB53VvI0wBARwQunakqAMDfbIv3D7qda6Mm4NI9RPOxaKLLtNp24/rynjK9HwVjGdhVNGXASWMFnpO5/yw1B150RRlq/H9czio2iEDCVH0SkCfej9czck+z7q23KQnlYg4M6WNxQz28aAwxbUR902jAWCgyOMAmTKZfh/qpuk7yFZNbLvEO2anzkdBVbcwfQBW0JAPLnPmNirgYMyVm6QEzGQK5V6WzvQdx0wI3MSXotU5PS4nywSyYr61csmEmgiChPNlRyyH3ex/eurqNcAnEMgCXjDc6pM8pdSI24XwkC+y4L7R/oDffZ5NOndc0Pjyja76qNRGliiDHyyS6finEM0NFAcZAk0SQ58QQY8GMwmzaB2PLZVBhaOxw86Li8XBLw5XNGAsSn8K/fGvcGRGDMgp4tWQJ7ppQ9SPjQfGfxYEYiOxStZ6lEP/sqicBbZnlkqUGEAdC8Z7rYwjkW2s/O+CKmrZSJhpesTnxgJe/JOZHdEAGDUSo4kb+DRqkYAeuf9t5s1P4UChqLjgRvoSWaK/tOXdq1sgE6f52M2hEs+VN+aolalAU50tim0Emc+stxRsrfFsrGMCcFFf1kqFA07ADxw9TGJxxqewQtQZuWzI3VRg2F2utknKGlYB+i1ZxIq3KHmCS0CFEm7C6OwSOzJAg2HVhybGKKb3SZ7W2i2P/XAIYCxPERS3c0JBM+LGf+657rbJcsfUEc4wstjcchxD0mLBRnMGfjPeEXIiO6JkoKPnxi9dxpSREfiIEjkD+KEv/hVIjC/iqZ+rQjhRQPeI25igUDSO1c2zxe6kMdyMmb3ot9IfEC6hjZgsLtOhrZlQorMQMiNY4eaC2+4tU+Jx+2ZGYJNwF4K/rrrhNw6HKNeQkO84Dch3hzpfNWIhvqWLK+LAv2QHb3+bvyxe4BmivLHnm0QI+ErL6J3u6ozRNQRzZsiZa4zmUEnMXv1O9BmrOpboDJ4wplOrS1y8GiYkoP6YLj+zvnu/rSNsBMKtRlwU2c9fUMaUNPoIKwGVZudpg0chkVMEtgJm9B5TlDXA11iiLykUwOEmBCV4K70DwxwhZVICbICdsdYsAS/alZMpM1fCdNcNyv6ZINffMlnH8L0j/f3L9++f31+fBNbiNOEl/dQqBaiVG2aZYwz7Mh3CTrn9o+UygSt52C8HTyht6oCv1vfe5whO+swSedExig6NFU9xKy2nt8rytRubK2lxCuJsN7Gf7fIFQkwOLs0HyM5urbjSlBcACHWcHUElDEoaaTNcKIbJKOoQ3vWAWzjQ1pVd+iFTbH4Lz7k014Q/GKhdK3+Pt65vr/e+g5P8tK1A0oHcbjukyvx0zEEGtt4hj3wPjXqsN5wljfnvW5Ri6hM4tp9xgngUUyUSMS1Br2OTYRtLSM4QgdzUIHHYcZ3XIJc0KugSMWaJob2kb6zVqYj+LkKdEkBpouuKuOi2gaPoJsR/o4yeF2jTz5ll9Djr/9dF5O+SgmszoIC8v3L+8+nZgEaPCOFUipqSMUSaGd78GQBCm0NsmTkCf0ei5jLDHO2fYMuo0awC3ABEQRnGbcjGxxV82D4jdFB/PlwY4wExBahbOxAUbXC7YhJWM0P96Lz0HYtOKWxss7ZN6jX19isu3epYzIHtIJBWOpwNiLIvCyk/4fK51m5vmrCvYAUk784M7PcOGIYiPoeo+TDMDAICMZb7n+2JNI8PBRoG7ZlzNJqNcWlWKQ8vy9EhlBiDfrQS7LMI4213jw3rN2tm63/0U+6N3Ejon2omDMkTzDDkEBIDdhI9GWOJFedQAYWyBONUsuZlxzfEZvgwjLBQidr5RFmrh8zTnv2BZltF+C7bGJ+tqZzXrKCZVfT0XdK90vUfZEir/w6HtHbPaRgPJX7R3CoyhsuIGUDogscPpn0pAbd5qb/iGZOIfnYE4IEgQWvbUVz4/xsWDKZDPw7GlCTocRexdwG/ygo73oYcCgeUO49OIWp7RMrFNr8mg3vwhQB3YRo+97WkR4xkzlImDbwTeqvAcNPovNqtZCf7CFzXG2UOo44Kmo3IZY02DuQgIPiuO+4ag5nXaBTzOQBeeHlVColAWSknqTYeGCOdCUK6WF3UMEBwIlpMdyZ9SkLgSoxyXG6DxQ6Exu+bWyb8M3e0lDTQ351XJE+uKIFpON16YWwy8crrZ0oZPmsWT7pdwkvkGReCJS5WWZzK0Jnj42HCHedqxwJkxm96axQcHhgIH8u1y1pO7YGdqU+TXfFFM1iIpZmcT00du71u3hUdo4NyOd/f9lKXrp+VvqheRVGvBdDh5k7OKEqoeyrdN65SLbWCpmiUomiuUgHImyqahrlnAzkrdRY9Cm9zVaXoWanAkOuyk5NdYBM12FVGITHqrPlwppZCPyo/XL39LErHr+Hx5re5HUHFnNcULJKHavejmbitgpkidpRdBgFfCZsCNiJcKVvJ7/aj5aiXGRKVhQKkR8qEgB1UO7kOuzVH8V10N7OZoIdbisvJ6xzozpicpVismpohOoNAuYycBr0XXiYLdnsDyC7/wiB93H3Smhq7tY3hpzjog/383VitO0ygNXNzVGDEi+GebCLY/YJ6mvx4i2pAQTU8LoQVlaOfKh7BQcmlRWgil3wzsFiCZ5hkZrOQ9fM8lXHY2FDqfNQk3gxJbyDxQdis9E0HWek1hZT5+3HByh8Z+6X/KN0LRKQforIY1zYsZJQsLw0cB6y19ahcCe2Dac1/qbmUEsjoeZY87RWgbCefCL3V5l7h2NWN/nTJRSki7O02hQMjpnlEE/6bsjLqUCK9UY4spik6HA+U0jIvqngbOncbiOTIb8K6c7qtn7Wyydg6OTGI8YuNojA3D1sHAJI+8nfqykxnZ3FYcV1wgKSRBmewlGebbLOrDi3ryPayCDEpCX4qyTeBou5vsVahNmpzMzaxCc25nDtHEs72ij7ANP5LGs7GUOVmDdrGtuqtUGMablQzXak5VgTsnFeVh360+CchmvR8hG8gbpx7ew99XqcD7DY/0NOinx4YeMGmngs+yp9iPMBlBMro1IW2RKjfr0huAyD/RjIkXeMJw7kuX1zfwXElJwi5rDF2lMRFFQUShX875WY6Y1tUisdoYrd51kiTI6sOMTBxkheFO51M9nFIkaacE5C3KohUoAu0WlrLx9uiToBCtmRuAzYHezdPpmll7zaWitNlVfXnVh8frgPdF4xDDtvhQp/Ddbhcs3jd1d5tfmV0l11GKZw/miO8CoatPQw27BAtz2Hxpcl/gQXXHZV7fs4vKOdDyTJxAUu1/r/WlFHsvErQCySVrELCTJ63AL9VbWCYGUBly4ZzRUMaoDZbLVyyW5YfFJ5CF3RXv6l28xyJCmCINr3wPsDVFILBT6jZpD44f7ngrYXT6YUkExXbrH4Yr5W8ecTieDOZz2137PlsIv3EJDFYV3lT1BuC+CMCqsnOw/GUVmTMy5mHrzp8kQv6/9n+2Linh7mVMBXPeaYgyGLSsAxTlyS2UJYbO6BrLoyZX7kjVd7Dr5v1ehAJfSsL84skNxnMiCETUwlrMmKjxUW5tJDQvFQdc27q4E33UMiHWQiHwoc9DQbxNcWW1wJ/qLvNWmmvjdE6xl75Gkvf3V1tMjnk4STtg8O8vNfDfKNUZ4TXEzLS9AAd9KnLI6KKu/3ieV6kxonzxDWByGedZLdnpmAbvDqXQt3+V9YPi6nVpzh8Lbx+OgbRyu1vXYJLCsCzl6JuTUhRiYzzirnpdXBAoohzxo8L5DwTH2A0h/89uD3fPV/sM4UKY1LPYCkDLrpHMZqQXXCZhhs9fG/Zfa/+j0K4exB8dpuAy8h+/N/nOTPO2qqcfmZOltqtFe5c5Dw9KkCMIuDI6l4aLkppFbawFWU1BZ6sCvbTraPo6uc62WacLU00pebXZ2ibMa964I8hjX3mSLqxRrfPD847c3RGTNtS6S245ptNs7ddsQLsDz4ayaZ6ifi7znyd2pKddfaZRiWZ+mHM7kl6/r6fH86Re9EY/3nrwZC/3DzipxnDdmts3v6tsiNBRB9ItcJTRXCuGajtRFVtc3h7AP6EDmN2i/CwLmx1LUh/mpkztDJ0GB2qP01+6IuVz5hhQbJykeezpAz67sKXb2KWt7SVYuEqpk9u6tPAxpkLx4NIAVmg488S4Tqa8Wn3TwYIaEZbbJesuYsl87Jo4lmN+fD6zE4EPpcwsi9iyx+BnQCz8jNHb/ZwT9aNUz7fEHG/a4Ca3kTiPn3uhX2V/x+fX65SOjx2BCsVHUvUmjSmEuV67gRVscK5/S/MTvfCdljcjn7dI8NHLpVP5ZSenR1z8PKckPiGaDFNmpJR2JM4yieudFIyl1LhdH2fFy0ldSyMt5Ybq8RvMMIOJJGpqogQ34XO3OwxAH3+zDlplWjWU1pZCQfaoMbjVqequbRpj4eJQ1XnIBj7j8gPCjXlCg/Z6wWZ0cPmf5js0gvfgy6NjojhFXko2TuLgtjRc35OphP7Va9Kcaq2gdnKUlyNUwCs5B/lH8gePsmxvqZ2eNSpabpQ5aH2GyKFqG3JtXuldP7Mp7E1HST2YrZuuYnYpvxTmbWsxY4tVwyzwGDDU1jC7C594LSAZ1XXIj8Xzn+XoFInNf602JupIQnHtCSlH9QiHb7V6MzZ/7zzv4jc6KrVo7WVnsv3wLFJpHF5+vr8z1FhvI4h6akuoBMFMVZ1KzJeuM36m+4fqb2rR9ndYFZKWJRzo4zR+AtqHT3M2YS6sLAFuimWbBRJv8Zu6T96XeLqYZRECMtKJoCmocKBTIg6hit5VOvbd9Ls2s4EdPG8RndLrHEGN7u6UTwTWkWcbvQyJ5+1Q3ZTRoMMYMSjFo0KfJqQhMBKT7huzVMfaMhXDyeR/UrZ2jlpKydxNW34I6/BG3DdmL26wMGWc0/DEXJ8ACZtV5BUAQcTrEO8kZbKE7FyBkx1Tsijlcc60MKD3PhWbAVvz/lM247Y939zOzwBh21sBTIEe2w8RLecSyAB/IAeHES2mvpgE+DApEKxRZKGWz56nA/NCV79dekZoUExpgFgYqFBi74+kzRbns2V06YdjJKI+29fnPaulqyLSTA+JLgfjyL615y/HEgTCitrHoDWZP/pybJYmCYq3TIX0L0x6VoNVDuHx2PMWKgtg2T4ERQhflKSHxvZp5RHPAdJMP0ilQ2FDoNeJfLltYD3HK2gnE0CotROIsUHqwZbMc5AuVY/0Bp/dqAx8VjTYzA8JpHF51rnbRZDpDyiqXcU5BU8Y2ikxXNEUfzFTkjh9BCTkO4ubeoEF7a6KDPhiG1ssMPNFvVZyPY09DutJ9/1y2KyHrJH+/LZs4lqq1rPLL4txdNnkDSI3jki5uxvXvDoB6SD5QRmtSGnh1dDJptkWtu2JZExkVqc9hib4hnMspXPQTLRT6MKJ9BCC6xmEdVjhoSrQWZbaQAO+yusZV3DV4+aZoxXFmWdr02uAI/oESog8ZEKsCzyy5o/GyehJD69PgtcaRtE6tWHQ98ISAeIiVfu1RbkjngOnFkz9DkMhaFPUdZ8IVMqzdO853E8RfR2PYjHl181CSERHySuHq7YdqKJrWNLvOrziY4QPI1G6v1UVsIzxjqT3wAH0kol8Mc5ukWiMC7A7vVryjKDXl0lDKAfXE1shOlL/uenbuQO0Ex6q2DDLZBuSFDKVdbI7aNUq2OpRQZrUCER6jGa42M0h/UZNfLLUImvOmejSki3dqpnQi2zk6QAk2wxnvLIshvJm6GZHYjqzOXS9Ub3WCxU9cDNAuln34EiG0B5fz9txXyM5UZeN6BoFnNfvLzs9fnSzCm5fMKQPP366GqYbVTg4vJthkyowN5miGPDY3GKQ7YXgVmqTKOAkpUwbN7NIMbeps1kPMpXh3NmZkNBmJP5LRIUPvZYdHZDVQGATUJ5MboZUaAAbgU5rpLhsnXJqR3YxyF/SPdVvFggRwD+I4OsQ7fy5M/boQomZmR6k4/OhCiMfNBsL1/ZlEKhF4RMyT5lETVEjQ23d+lkFwtlZD//v33+wWi/cfvgz1so+MoU8ETumcWzX3lkK9kj6+E7dc/Bz7z8/WF0+/pVWgL0wYW7CAFU41oFHxY5CAaA+8GXwNRVH3FOW9RI7XKOSMsDFddFAHZ9x6MrH48vgeVA7kzzBfn6cjfm0Eu54bIbZfp7M0QFjte25m783Vkhr0AxZx6UdPgHSK5zgEwtPY1eBTg3J4cmGGnMI69EKEZerPE1dvFEhmB4c+BUDOkemI9T7ZaPNhFUYPuMpyVMPSIz7V++vhxOz4//vz4yQCIigWlNmj+eQ50++OKTxD5+scz5jJojJ/85+53ALxOC5hBpnFIG2mngALcBB5mou2NOhBLsYr/gGkjnSf1JP9nVC9EoHBYhqh5hqijEO4u+QtAWa9+4J79JHzD+XEBKBgIH1NkEglXMTMgz6C4QJk2q0SDntPqjDxiQOMelzeXGQF0TGwwhiyTaTFCJK/jW9NxjZlNAtSbcFa/PkhogVOSigzIQIi/treC2ZIBNb2/zzvOhZcD2BGaHgH5mqJY/Z23z9uFtKoJMLnNBdYRWzF5sgOYiyaDqlyJRrimf/B3xtK5pjvgKY6z6fmuIMNoWa/WOBuIf52q863ZKWyVfMGzIOGesr2u5uoHxkYHw7iwEWRTeyF/Ltpfyx76L2Egf0wIYvacCnD0lzt9gBkBseRZStjRmDmRXvS3j81YtvErHtJqnTp1c5JMiAb9yJndg2TykPr1qBf2dwfg+mPCkKifNpExWWqDBTQT87rgai35xThdR6I0bfJgMoicgWotiQQJmtk/99F4mA3o1MhVGG+0qZyPrSzkDaZwR7tYHNSTX7RCnVAAPqz2pz2cMMfATVDWF0DBoAnsQPPnbRawaIp1KN8dCNJJo63Z3ApeeAhi9QN8skpzFHtBbYWttAfYR+LCKQFE9LYnfMAkFs+yOclYSzhJO7yOOe5obBKKoJF2xoL6lQ/9A0yz7pK7MiM2LTzjYeFIk8wsY8WBjpSC5pSQ+SYAX/Yik0umKZmTvg6x6q6RE00UcxvlhWZVkAmMvA8Ksy1mIw7UR/dE99swnJF/AYR7G/ZzC8PV6Jnc8IA1c5eDW9xGNiP72HceYHeje4lmFx6LAsI+rOhtM0OXDKKuJrIZetrNxr6JjeR1ogD4WSrxrCwqYL8gYSOLQTMIM4TMz+q3+MEiPXZ2LKNJICOZaVSQS5sJtUphjgnBJKK7zgBSInhr/3p8LltxEoQtauIZkza+XvbGc5EvccjeXHnHMgHJzjx+BbEQZcuweW9LVtz2PZlTL/fW0TJnjimKFTk0IZTMtRXEjuvwKMxUbYdqDjpsOuiXeMJShHwgpXabNdxWmk+OdrlQbsskHwDQpI+IaQ4qg1AEgv3+H06Fo78Hs5evGZNxqBvuYBIrlPnAI1jYE0NocE8IISAM/hsBkO6iN+PLlQ11OWvEjhTBHojQ8OrC/OlHC06mWeEgFfZ+S/WSShv3iHckhUzIVnytF6qaARW6KDTFMP1+DNQYNUvqAOlGR9gYi5smn3fp/tAQqziamEiCtoa9LMU2NvCxdcUMWpApN0IXov0lTRME1nOOHrT5ekZqJIMGTWIVVF6YQoDIi7e2K9wDipAyMNH3TMRgO4XTRXk3kc85XKINVoN4DtjQAxxMz3YUINQU90rFQh2sb4gmYYMelMlt4n8zu4tj9l3laH6HPb+lufNK2P4C5CuldkCZ+2/RLotCP8QncnBxEQhWtM4cKBIpoimRTSIBig0N4IjTolUhSQzH1fERKyxQTJDIZOQRApxKyBPCCBSnZQxCTqxtph0XMmoy1Kub/AlJPjCbGYV27X5x26RWum9DwFVt+BRdWYKF8S3UDxmkoWiBEANnazap88ii4qCOe4Z3GuGiW5aybwJhmjwQYKnlGX7Z7E8nL/SsykasRbBjv7gthYBWNt6CQgL11ylFN2lknOW3Y6xktjVma1cI9PkYJrUk8we/OUPURnx0hxSDaXejODDC7Yi9rae/RZqyNqkbAx5nekTGDeQjIwhVQwFKcGg7ijFmH8xjWxuAbaBE4P1fWRwPC4rK3y21/aBazp1xpaKfP9KHCnYgGakQQCxqOmrw3tQchCBRiGPdnNqRRzD6b2jhEbvTbrQAJ9IDw8O6VLtMzQxV6dYcuFB7WLy0SwIfb4Hj10Gg/gSIL27TGIcLkzmok8LwwkV9GFDQK2HejYk6L7NFWWfIZca+FEJkeKEw4kENwjmiB8k6G4xS8N4wPGNCibvLaHdpKsnNoRS0HQToG+uyOkw0EgMIBgoSIZOhsCNG50C6doDOQ66ZIpbnXKnX2r2y9WMmgJEoZ4ua1pW4OJPOlRv+wqPyV+A8gIASop0PCmNFDmZlpKEa2hFut7muJIBMlP6ksH4FlF+PklN+yFF6rUr8xs22sBoRQYKizBhMKEix/FimI5ULKN2bRos3f7gYmBbhKNeKCb8Jp4Lf5bBEijqO9ndZdvcIRWPUzOa29bo5NH8GXnwVcITXyMUQ4GKQUPWYJLfVbjcKUcT2QGJDVGtfaGvyCKiaLgyvW4cjCo31tCst3UqaeMA2BbO4Rr2qyOycKRHljg7d8GV4Zx7U1WVzIziTQ/IDtFtrv3KRbPLr38+sKNv8KkDyNWMVID9uYFEB7wZCoqMu42iLHG7G2bRwTBDk86FaJMawo/S0SME5Ok09l9bR0rdpn1WW183a1ZuBSbNSKGRCGpEjuoHlhim5a0q5LUSTVJsPBlPp4pbGp5mHXrKYxwgBs/srEKV2azNuzVI0WJsAloKtIYBslcBjuCBNcDqNLHc/caPa7SDVPAMLb/li5lMv+fVBVcPfLxDXNMbt2Um4cwcA7j89acOC9R045m+0J9HDhZUU4FFCDNWUlI1BgcaImpBulq2ORCZrFZhS22BTtdLvagQ+quZIKhv6WlmYsmtioEPjljY3afPnYmnFnj+ScIph3XQ3oy0OROficvWrWQSoN584smD2Hhg1PWm7YITQqg+FqVa8ZiaVl5A1DhY/bFndjo3fSdsnB+7x06Zk4Pj6Fh5UrcpvpqhM008VmjLh7nLur4DqAUeBi6sOQuKIHh4Pj4qgMUxI38Nk+016YSJ5bNeMr6gNu0JDqJhy9usTnJVE2KJBFXXIPrgT9+6ygJIxYIBFldajoNO82kpp2lpjuifHsbnMS9PqMlRmnlslVHiQxORH/DMsSow22k+7Az7ovEtWPY6jeWWdkR9X5Cgu+Usj8qMY0LrVnzdFRgHTgaLirAV4RY1jAXhI2Tp9XaAZsqq3LDMrs6ZrdG6KfL1AkXdDSZ8JjXZeisVcce2DxkZ7UK5yJJD3dcXMlmQra8P3VYijWgkIRia0KNFZXYaN4Tn2qhVGqwnTuPov7sydLGRMHthE7i1EnwbfQxa5biGYQwGrEjluUlXzsA+ZCubTL7HTiAw64yP/Zt7cVqMKgijqf8QjBATxISPBB///zzQWi0WxmT1Ik2Crkz7dXd112XXpM/GyZBjU+IU4FtSsMDyScrNEtFE/CxUNc/MaiSkSKLbAhV/0Law3qf8LSjFOc70hPHouFwCgOmct/MsIb7teHJwHCl1LFjjn9zSQG/HALi8aeb8PzuYVrEaSYX6fYDBEKEPjFD4eCPmsfhmVTOKZImQk0Gj8tDag+pB/tCzNfGMLtFD9fNr4Jmq4VN1oXM/79Do362kDxImZbyj9uYsvPseFFJfKlKjAC2BImMEeItAcKgoRDxMOYA1MYwUrMpFMg5ZJ7MPrddPPvta7B1Kt3OMxfvoSxaKVcDUmW9mKP0Qusxp2MZTJkZ60CbT/OtrrP6v4DVRzHVO+PBu4GXxZS2dwR6jEOERjblwoiQsT7jPSzgJffUxbQHr7X4dziwGO9N/+PX8BAOJoOuQrfGsmuDXrQHiUL95ImTDjL6D5NZWK5mgOFAIUH9TggNkcgDrVHw96Q+AX8xBomBExjlkka2sdYEluxualC2iHQviwHUCkg2m5zOgjEAIqILvZt238isMd4/F/WVRTtJR4YgcQnUaBoL5GXqSS0z815Nc/MXJwyOcr9eRtsWgBLYd0ebuRjZyLMLBEs7tcVZOH2ljldUEl00+4AYHdgIpTlOu4HhYgQbJVsO9bJrfiaNKkmdbXE9SvK82Y0rwG4kke65Y4Ck9mRpvC8KHgbqwpqSfIIN4jxK9NVGalid4Y1OkcY9e/NeTk5/lWG1jOS0gpRIRycDu0fllSm4J8p0Jb3MwIHCJ55GBXK3hpkOQAnDuT63NC2OeWW+OhaW62pPHSvO5uiWF7dJN8DWwklMYud6LkPMmssqp6nRXYfeMSuLjUiMHdblCLwQaBKZF22L8Pihcfcye3qMK5fLuBfNpM0w27tvSdJMrijuI5trYwlMiYs50jD/GekXDYjiuii4/ZzG0pKmPV9a3+w93gfC/YD9n46tDmwFM3GVWBcymb2NzrYlEVeUcz9WAu7nrPOTNGd+LcJy8+IU4niMFO0hsZNFkgKUULMAB1us5vxWctROsw607tjRNA3m2/SoDqKut46BznzCG9pf8Bl6LuWO6+UYZ/js65ANa94Hyu+j5Rs2ZSVh9OQHK7uXVGYs/3bFbCIWJXtYRn5586V1/SIZXOdC7H4Y4tmR01AZmYvGbB9fm/aFd5vgrZuzHRl330sS6109e54kO5vfqS+4B8fWqUMddnysrRzXsp57FdTk4Oxg9gc+WiVNORvLnoKnPd/Y/grES5031APv/Dzi1+tYmr7+LkuRnOSVRhQvKq/PeTr8eq8Xh/OFhSRvW7KyDeOGyL5ecgofDzTg353KHSdArFFWuq08kXpCsCaY6klbwDSMWVGBdnFxv5KVQO3aEv7G6bwveDlCGXFc35cBQQkkhAJh7lMYDVNu32yw1QRsyHF9t7XJm0PNgCSz2o12E9LSy/ylFaF62AoOja3oZgDaOFszNvM+JcRpjHgLw9yZ0k/fRekiSui5J9hHESY5ClQlm7ANbNmU9XO4U181AUnu2Cm1iR6cBlxl4Guy86kR8B0Y4lpfRTQDVL+5B7JZMdkD/KenUzOAHl4fOqwE97sbH0zikFUJyZVGn2rx5eNttypVj/fEkoUEdRV1huplhU/Sx9GYDhBHC/kR05gS2RtZTFrsosnXhlFb3QIls5luVTAvLmdSa5LDCgscqDFS8Qkhy5hH4NtP5BViZKwIZAQ2aF9LgclUmHNrhSMOHRVdl9gc0CBmF9ZjlW0RUhDZc+kFumTTKM9GpVfiVIQN6+gWLNRTciYcAj6pagS9Nv8SVwwI34K41TgSt/IkXEnUQaHIKfwB09tk2IOQvltmkAwL0Y2RjySRhFKAvh0LjxKovEOMajhYAaZzfxk3qFMB2H8RKfApA/vzvvPuFozsp2Bmp3QSwrwXpH2CKlB3iuG8ldsB9uK6sosOgnEoUMJfAjE2ZQieyB9eXOOYXl0dMzR9pd8jqSB2agXmrRpAPH8AgePXMFASXa1ckOecq+AXn7sZ1IObLHw3a/bXGPXJRMKutSDVzqknHY9maxobILIre9wowOZcxO0VNZsBwgMldmSBJ2G8/pBkDDIdS1wy2MpHJZjK1XusnbZta3rukta8yMRY6L7d9k3FuOFTEMhOFsBYk98ML+14VQy/rmVx2Ynu504ku5bCcHiff7//+X8ufvr7LJDw7bpwWeAJfYwCbQJ0s3tGTpiuApQEz7PkI3ncSI9B+CCHzCmdq/vavBZCS0wlefI0eASO3FH0+laYzqyeZid96Q2hLpt2UQ2sZY2JantTJeh2A0/WhYjzTyJpqb1S12a7MxWzAgbiprzrqEmYmaDDd1Du8cPZFNqD1d0ylja3ZjmvlSyHQSPREzxadKy9nwznOGUgVoLuhmfkztwDZiwlldSxFguWHauguzfr33AMloVAEjAYl41dAPIZm9FaI6mSak31sBZEX9dYkgKrdRd7vB7RbB5S0FlxN8k2OADvxl9VBIBn2WUd7Khx+xjSlOpAaHEHg5/Rt+gdoOqfUQXiwFEtei/laGKg/wkVrfWkOKj2eD007Gx/QqRQ8haYcabmJAsQZOOEwIhAWTYxDnsTPZ98lUAgkSAUFL+pjdvkw4PLCxK7jX9mMVRggIhixVUVhxlA9T0j1M55svJ7pApslwhr8EhbmO+9pm+gZwXM2PjICxhZEAqXYX90eJBgjGfI42RIFu+1EjU5NS58Ls7NuoX/YYolXRtsersB5icI0sRVX4hMAKryFZR22b5zT0WeaPsFEdDW552NNEgblkEeP3LeA5K3SxOzCYh9vfcCqvhgFbv2uZwnPeti6pi00BRt28ucIeNDAHx7Tn8MXiTx338R7JUNmY700wbzYa3c81zcStpYowbvEqQuEyvE3ItKISANy4JR8oEVKKjDucZfeS0vLuPYjgwXNcYa+YMFFe1YrkKYmYqRimiElcguuIDtqRn+jSA3irynzxVwxr22aXxpukoheSqW7Uk2YtupgdPiNTKzRbQdlsbunSQMWRJ0YjMrCrK/hQxEWFvNObLdaDulw8cjWJJhDwZ6lCAiPYCguZ2vDQqfXUbOWo9Qb5ZX0Yr55xTf61G3anH5KykG1KBpNEAGSGxFMLMDAnshqjn9COVG3XNkKLoFgpAe7Pc+iqbxjdn3IplESsQJDvHB4QQXr3zMZP/Ai0qKFp3bO8VvVQb3YVPTFYpz3TfUO6i5wiL8yFud/aACIAIIT1A7lmF66cjpvPpiG8GOEQvwUGLSigAtQgoQE0qdlCkU2u197CMIAjR5bhfs5VCAQ69eOdyOMqf4wj8zRZWm8aEKGgeMIF+CGwaYIphxDwAgsSwcGoVvvGxZiFKpjoyh8WgPTUSr1uqSlkBqEG1A+FHP40JqWoPw1qdwTnxMlXYe3JrMZTNyhhoEhoGgilxrFGtYTZfQ8pMZqesglR0K+bWrKVecayB3wVEU4qsBLLqGxtK40aJotGDO8Tjp+1xYPIdBhVmjYIcJWfomAt9ximkOUCNioYR0UbkOTBDKRRV4hNoUUHxqXQC7NlfFKGlAvZVMY+wFwwSEdUYKGp1+wADw9PlYa+xIZ1SlCTzwiRrZlD8jjW5mAw31jgr+mJAt/T7gJafE46ngJebk+8j8RgEkMkWc+WUA+FIJvElZMicKbTFi3Ci6dWK1zNahRkk4OCie8wCHP8TeymwHVtk4cmTOm+ILUoJS6+pcbncGmKLSDXvHfxO8ynnD9Ch5Gypmq79UgiYKyIzLYCWu393pfmiQpLmeTKquz0yYOPHDBIbHY6q27/5Rd5PGq2bboseD2ysNIhS3zYUCCFtb4mXzpyt5MGQmcqxiCz254v1AyL+Ww3R5wIpNkR1iMiogOkD0orRPgL6JAvR4y2rekJ+MuTBhuEQEu9aL6X4BARZmsnsUHXNspjnhRprEDLJ8utVGPQAb42+OKb4KniwAc6m0VCqBLpcAfAfsJCn4izWGxTUSrakTB0Hul7bgGhSsNKi3mr3rtrMrtINKAnC9gk4tTl/NfjaCnRrSEmFX76c8LRviwtJkbZHt+e96za2nEf2SmmVnoZ3Njr0hLkjlgZos6YNxkCpqSTe+Yz4hBqrhnMdszCf5zbSW7lMAxFUe9/1RkevFyEiK1BmaYo9o3ij9IKdCIBWyt0WMavv1L7JDBmWhMimK1J85r8lCurJhX1pxmabCEYZw8TgS/V29Q70xx8FMq6ydFYPy1AP2U13dLYaUgkweJPBCpONjnBCLGtUWQTiY72tPSeyp6DozB6Ylc3kLLQfN2KZFo+lsMPr2l/RrQX+pBJpOIApx0Qtnw0VgrNPQmvyUjl8Whguazg+6vSNb51i8sW5P5aw+VCoF/bIyjlj22TiOLex7Mdogg1Na5lGWcTyqlJ++Hc2nAbG0NLOElBYdtSLEHjAFoAZ5TgRELMx2ElaNPRXEi84Kbi8XzwWM6rvD0AWhbz2X47UcIMM9S9TJqwAdna6wltyOwdCHrWzsn+Gs8HTAfSC5TY+XtN9AVE4LHOd7bkE1oyKdwSs7NnBS8h3CeQF5zDarjlu+x2Z+Lp8qznEHrxnOttFZYhzExAnW6hIWrgtz0BdpJCdyZZfDS4zKUO9xUtDrSXcSBnbK9Y2WQTFGMZJ1dXvPM8BEuplLNDbcVOq3feyucYbcbBSvKvkW2bz5VnBt743FHH94sFCnD/L5fYbf/czE6BG+8dVuiGhZ22KIVks4G2uLW7OIAFxpn8CNHhP1T7s6NXApZBpiS9lnzzFDQ8gikXzziDAuzZFv6IoXikJQP2JR50Eqc4xuqlBjuskPb0YX983QKqXTCjEsQtpx3a3NoM77jvYYi5uMd+l6cZU1C1B2Bz4FLU6Oa53ZqAhA6N7HOICs/FpCcRuL8ER7PD+XrB0YcIWZGFiI+4ROQo7cBFnE206DKrhobyzfZvgvFC1Gth1PO93MgiYAnizJmTu5mEPNqdvlp0UOdCg11LpTl/dWQHs3X9NVhOtvruI0ElN+9h+yxkFc8btQUSxRiUqxQVj+gWkm+Xu6owxtiX2A61H1IxOXggUDm72pT7VqApSKleeBoDmxRL17s0JQHUkklWpGUfXaLRvmO7JvTA5Qv6gFs1pbfluCfQGr+l3yZxDpN0SPdcAb1d//+cL13AIADHajN9cxlC3BrsPbpneezrqtJWVCrY8snKVxB8oWAgvd45cF/wCpdDkc8r97E+z6wjcy+/Y3lLLonnq6UbXBTRhObvasi5huM+euDDokSVeXEs3PN/NoWeL/GZkCVukN+2v5vgNjI23uED3jF5p+kdoupze72RrY/vnGrYP7n4cwStb7nww1254DQQw0C095juDeb+50PUsp6sgYSIFSAC6m6d+DczTr967HEQH1muJbRSxa3onAvvPNht0XZqvS/y8w65/fRCkP9+PW8M9VeIe17/dT0u3R9Ul/vVFf7dQCLvA3xr+aOAij1tI6Tdp8WS2weJ2P3FpZM+3dvSMYH7G9Jp0BJw4zT3eKhPeJlJG2CMz6pmq13tA42jHDlVtV5ZpM+JORKheOFpjOvI2NwUa8HAhpaZQktni50UZIt6T7TH1ybaeZpMyZIkHZAQsdxWyWySWdcSk+g0IEymoTqB7UlU0lLlCYRyxtNAJqdLdewNYmqApim9qHd9qztqbgFAAbhn+VhFH+2XgsyasgWqBDHaSXdlvLXqTNhYEG6QJjctsVvM9nfhPEfLHVeB+mvXoh16Wv9mecAhBSrajJ1QJQGs8Slu4aiiTy1yuOnwqMh8ppjtCxTqHQ975uFJPC+HoCPoMRJq6m7yU+Ou16s5E/ONxbOU8jDqLouFhpyMyXRlX5I/UQKUW0WlJkROzqmrC5XQ4Silq5wo4sjm7MN5Q+S4QhtnqJMig/rJpzChm9A6hsB5TCe5nS7mmVEyHR2MLKp9c+u0IJE8T19NvySicVj2vN+bZyfisyQ1+byjU4Mr1wQRKLCFwKBLbgxc5CLSABD5qf7qxeUtxc+/Xp15omymsR6sjsBvu8DKA0vZI24XRHqTGL26GrNITSE5OMyt61/kQ0165fYkXEZdhZB0OX4DSESVcqf1UDmTxPIb2WVwwzAMw8DswRW4/3xFTRwOhvNokcaWJZKimk8TriRZovx7thjdlecK32CPj/3paVUXQOd5EkrmnegInZO8lttR70TaYkKF5qkiQOSW+DS6Vd71PfomqcevWnvYB6UD6JbnFKqNsKmSJhFCGvxWQ2OOdqScBOyUPMhFCh0Y7G/UdtDwaY5U4zBmbm1gOsnrud8/+rm67boOGo4it/lachV0valpHkkJRb3dDjNnlg8uZ0U9mKQy+tkkeXjb3Q4kT4mUxuWyUGWlssYotfVUokuKTuZBhlYAMAhRVWuEu2SuXLuYPdEBU+92CsLTM8aZeChccJV0CuaDV2u08xtiUFhzskOnljY6wM/s7hRrld9EQyixLpuo0v4L9Gt7iInecBlBgLESp8wkL5Zsp7XdmmWYy1Qq7J4EOEo+Hdr8qVh6wAHE3GI7FJ0CX5ic3b5F2/wT7j1VZFhHxrL9asSziips5yp3MSeHULMTRtZTQs7SWgY8vLIiWFF0PHgId7K5KUSWigC+crdR4uTzQ2piuvmPbEZbHH2Beo/pQB1pEM8xMjGwoGlfbN/6AVywpIVSisjA8WmxoHZrnRmV/iZMHklSGMk9BXWH8HW1ZfAFN4KPCrId9LIu5cXg+MadAUN9c5CXbk3K6yNeOPBWfrLZkX0AhPQzPAiGz0PSCRuIcSJ08Avgkhi0REKwQR6U57k0jPQgXEnn0g6zQfwNcdBLiv00u6R2txMrRaQHeWLqsHyoW7Sc8Oqglzu96mDYxEaG1Uu28BCHi/incj6YcCS/V+rCF3LDdlNbi+zIel0es8NTS3JKzyHWFLfW0o2fAmib8j+sgbcufPQTaeJpCS6qSbpGRhpne6v2hhUVIVCcKcHa2gzPncvsbHxTLsnQHcuowYnWo1uqidFwu/CcH9d1dCNXDMNQ9PWhFtx/fftxcEHsIMjDxLEtiaIo+atE2R+YCrPJIETRFgUFBvXhtZqQ4UqadWgdd46uwa36d/ndSroeJ4OsipZvk8ANRxDl5U3FxpZV14kewv6xhZd7qLJWf26HcjURuhc/k/NICCWoFHvJ8U1iiWRchtmxea1NxtvRDITFTbsrE+RBuFbE3DTDbsVKbQLQaALQDjZC1Ep8IZuVWHgB4hjZL9sp50f533Ov5Oy1MJOR7MQqjIVrZ5pCF3MZk2ckdT/ktnzxduPcElw23/EAZWKUZUqaFlyO+CGXXOlkCnX94YzgeR/YKcdIwAP3F6eUWmkQpS4KvMabvqBeZHPShzurpWPJemlYy50z7D3cFbaEbf4RUsd4BBz8HWDnHqVP3Py2qfr69yZZCbFnwxpYXNdB+AtoeLzP/6e+XR+r6F/gkkyfn8GvIeOKK+AvNYxmdB/DC6qQi9bEOfwthbvWA1m0FWBGmYiSk8ei2JBiC4ekl0TV0fbUerwFSKduJJml8AbVXkQOvBpfJiHIEppOSY8v/WeoNlVLw2MMnFhcbVVLcQD79N71ypBLbh3qpuDTud+JD4SL/vEoVbGQwrbeMykEmjdsc+y+can6ckuKF7rZOmvXh+f1AXdc5Q5PkCkRyRYdI2AGijs3cwVPikZnhTSZsL+Ypmc8riNZIEZ88fOOmd3J6Gb6esqeAYya+1jtCslWl951XQxO91fdSQBTzPH4fAj/3iZaSPMMHxq98TBpwVUuimsTE5TdXFpU2l7UWQ+6ZZq97hOOPdOATdvJRyrhBxNombCw8TU8DYbH/QITq3PHAw72gijzMpE8OlIeba5bwB6OjGjIsTmWxJWcl/9jv/cPJ4ZJU3aHAd6guhYnVSKC/URbmqO8a41kCAEeOEcUju8RgkOcQoyiaHiGyzSsgbqJr00v5KhF6V1oUNEBY1OMZr0OYIYsG4gVicTlr4M9orjRO2vCaZuTvLBgpX3NxHsICJNRudjB749KO8puI4ZhKDr7X3U+Hm9g6bTJxFZUigRBkG58WC0iDqmRToYBSdyWUuQczuiRmUSnJoOu0N72mNr3YBcSBnq9htBmPIQDLiUu5BU6iNssg5KJP+rbJNQ5li8xs4qFalpBGDilvfhQulQBxSRuaC+3yvS1CNPFk5O8qDYFLcV7PIvMfBDlNIIO96Srq/X0NxTb3hvYJSxnblefpjaxBD/3EklqutwkoH8SDsa/DAloxYMIC9NqdNKxXbC20DlA0CIMmcxVomC+IQVYdnZAaSOHaeChsV/Hsl0zIB73UVJD5PUpphg9I3bV/bSjdppUjBhJ1fxdCLMokncn+aacmU3FciLRQYujAE3DdIuDpqgVZ5b6c2Yoyf9xurjbev7hcaBDdwLS+wbNNMGVdQnsyJXeNWs9IE4EY1KHivKCebWk+pTC+lM5IAehMiyqCncqSOhlqE1KUZ9EI0u6SIwwlcidfRO0g6wkOYG+4lTsSeI2IheJlSFtB5IT7GAThBFDD2uzMilXycG1o122l1twiPEUpSFAzfglu/wxngJDmXR7fbArytwnRFJMGej08KxWQ3H06iQtOQlNYk7DBUopGDmdSVS4Kpch3YrT2j1ZjgvcNLq98H+RUWa4Z4u2RMSmegBxtIwAzz1qZ5+7oqG87VTByLQykzNeSiy3kD8ikb+xhbDhGwnWRTMq/7CWF5WAFrhMXZg8wr9xMZ2u+hy81eVCjJQhyt9ilr0RLeLGJrCoFzFPta0A5V65ZT5E5AG1WjGkL9ZwDL16TLWJvbjq0KM1VElDrLN6UUEhSoSO90RyQz5p9AXQQ/FAs/sqouIKUcba+N7vP81PdoZzwjNbjEuZ2T1xs/yS+XIKwIMMb9+Qk/e2N68ZLGKlvNBSBq1hRGn0rkDKphkDeyzFJGwHkA540n/OJV/cBDQLLl7RvnUjxLJoKNz6bHMPXJPXMlkbebyjJEF13DvqWu+R0eqB760xxz77YktuUtVVzPOYoz+eQc/KxluL6HcBMu3tVdXW7zBghQropNao36VUnE4Amby+V5WYsKLq0JQsEyIdrTnwxtBjiYIlNkMSH0OZy5nQGwIax+A9zTSBijNDKWsyL3BNJHnEHfC8/9wjGvTIjGyB4OO2EGxyzrS11oSdhFsdd2GNRd58BArXgR1XtVVYNxY+5QTzrs06Hx0CCCaVUi7Fc3Rdd3Hkiun6MFJsmxC941VNia2ouQ1//ls4b6Qpt7D3RsOKs3/XxH4OIlAR8PQFzwoWQzT12UnNydVN+qg6rebyfcShC+p9W6xsXKxY6araJ4EjA3ezvo9VFhYk/bKvo/SDSEYRIVCBGK+BqdOc1Fdf3OCNq7NvX+tTfsAns8e+8ESP3XvDqE0MxpgW5lyYNciaStg5sck02uiRzzxNYkra3ddgpXIImyxjKEalfdrcs9MNQN+5AmrdNdRHZyBLj8FyZYmhfKnvMEthBvzw+inraTvUJHS0S76VL7zHxIwxqBAVYaChieieH/LJn6LPMCj0Q2vCejexw49rCq7LfjQMZ7oxSTh+GjwUSWbYN6daBlnFx02F5M4VSf522pY6OFErZy1cSSa40UWL5h8MXALF8wIRB0HcDYwqjzXIyQfmcJqfpMVKjMUb0V12KeAO85XYay8a6miM3QrHT7za6xR9AV0nApwz7D1akUnDC8tUe9MXMwEEsKWBHPN9f3zaSQ4CMQxE0T4Q9z8fi+bpq2QJL1BEBjt2eQpM9NBLCq527QinMFqXFQ4UMt6Ox6txzfo/O8C2ExgYGFleftgQrdV3VzGUpYzGnSfJmGQstBUiz2K6OQMM1K8ZOeF7W1HPMeZLxf1+1XU9/a0rjqd8tpIoUSMs5KVYTY7tUC5bc2fgt3Gabs9AFEbGaRhMxH9tr6mxmPfHQQK3c8zE0wvbZn3IIyVr9ZLCPKTWimjOTWh8bA0hcWpeSfjaoSeM6vCU70IayfX1HJdtwq2rknx0KJ5NThKZtRbu3SGstJllaKuBBCadveGu5xKrbS8BF2DyFX1R5/VMXbHIRTYT4Q5klpsQSotW8XlImCxifF83eRQENu6f1gvrNfbJ7TJOXU1H/FMcQW7VNcvFTApCJAud6UfESzcyC1XjwDg2wCUuMcrq9NGXtVV5q4IRyj2EK2eLVB+8lMVAiD2+NqUG7xkkPdmv1QHfLZONcsN7jIjZtEUlYJnxmJEwzyC65KJGuWjlTrKEaRdmtzJo+ykkwCRwaTVpVzFGfilOBTS1+5I66ZGJsASrTvYREdayvNTS3VPvdNI6gFm53jMmy79PQC7thcqoVEchCbKwvTq73zcXK241Gly4Y3vcNeMuPWoxXMaLrLavaNWi8bG5lj8phSY/w1YRr54xmNG1Jlr9XpUJNheNRBo+18ku3TgU2WfFTYWp2juDUIfwd/jhUcDg72TBIABWcR07YtqoJVfpjuqcoYvCC78VFLWQxE8LG0QBv62y9ApicrGwZIMH+PEd1cmMD+J7Ylz4VYqsXxhpq5ah9c6YyajlPpxLwNkQ42uxf3recvBi8IZV1lnI7VEp2QjpGA/JAoY7FfUuoICdLLXuZarYOgU2em5EWoEXrJnf8NzQOfNekfMiLei1I3t8STOXHIZhEIjmQHP/83VT6Qk9DRIJuxJj8xnAuHCRB/a8FVR/qQCGVIT4qHqkJynd2aLzaMckTisZ+Q+diPOlnxDQxbipP2147ZMzUQx75boJp/mnPD6R6kmsM7wxbRiQ0VBjOAJnEOjF3lzOcK1IEn619epJ2ga5Oa4jPDOJmkYwUnScr0CheVFcUM59fGg1DDAEON1MgFSXSwqr+krScBQPNxgdORI4xZboMQvST6bsResoOftVQZWk372YvbEVFhzuCAWoDMD+VMLhogEHkgmW9Dem4hCu7nx4GGvEUKi2LcOZTVlfS3aMWItNMG42MbsTLVuNt0RNtMdmD58bp/Js91PR2UHQnTZ1sVERs32md92sSO8Fa90cw7WwYE6tTPE9wvEeUn0uLBGqaAqbmUKFjAPCxtnRyqTWe3mGmSkKSnpl58C5pGj2A7OsisEeuz/SpOtcTjkWjZQdfOPJpeQUEeXRraA9bGC33Skab6yfJTrJrq90hyKx2tESrd0paUoc8WF5M/calg7+C8Vdfa8yDEjQ8zZ6Ypx9/8n8bwiPpBZR16GfMItLzPKKuMxFWUrAVEuRNvJcpUO6hfir7EEDcJXrIxXoUKKCwuROsRbiqwqMEpI2QFF6FOANn9HQAxBfLrmNw0AQ1VXKG8KbELACeJP7n2uSEYiHxhsNIRNwmFiOmuwPm9XFDoNRAflCIjJVwuyyp0yM17dcdyF7LwaZ13TXRi7NhMea19XFBuTkoBV3YuuvVnxe2kyWDzJprbdn37/Hx99x+x7HXz+y/my9d+0Ul8qQZ+d5tSCr8LmwZI5h78+Vnjk95Upo2aa7ssXI/YQzFjKzUpGO/t76cz/QNx8HRvdn6+0aDNZ5hGeK5CSjSCfZ5thYNlFMDuO4R6NgU4r+thtb2HICGZwiiFcik+KEydDUpACfnPrBHcfnhSdAvAbMRha1QyZMlJZNJZbOxagPDM0tT/glU5yt9XixnW1Anm/AchIhlaHb/Fo/memUfROjIY2Q77TnDhIXxw8s2brjcCws01JVvIYXkICkcMSMfmDc43eSeXu/0DSIlLQDV1LGZ2M1NDjznsnORe2aihKFgkyjqJLB4LARfKefYHEZlf2EmaJdkQjiVNr86rS5LjWpkuTprHt91BzIJdMuEZEWu5oTDes2Ku0/OaxqMWB0JiySjYhdJn2CrklRvxuW1iZYXB1770RBkDqbM2LU0RsnZCiARvnXLXgKG+saEGqRfFLiL+G3wtgyVMzOG64gSC91oowLZC7moOVrVcnk7VBmRohnZ8ze+357y9i/Wgk5dC1qgfjM+n5Ip0y5eHXDMFHoJUE2BBzjQLShigZcZIa3juPicdIGItyqAyKr/cqZGxcxxV8v00T3DBLeSYHyh2nYEgCMte0BM75jPPqnWnDK2iBhkBqqrdgwBhJKlERwEmPWJEwGBQ7xFb6CJlKW1ZojCt7F4hq45p8achKsG5LF8IEwklfRzgqkQVsexi7IxBDgd4hAvtqUzjX9zvHR7/VyTigVRtz5UKgkgoaNvWOXWbMl64AGuUVADrGjvopa4OffTIttwZTCCgGjwktgyLqtkIuKspEPEkq+CAuk1KIBu+hyR2PAoY4PdEIJFjC29rj94tj7p3tA3bQUmgA05jgftzLxbU2CEaEeBYNAF1p1V8PGv4/ZDSRqgBhPov1CRNth19QoLAdYyTdiNfaDSKMsphovlaEiYRFmKP987bdfH3u7w+NJxmN0LFyptVtBpD5L3RIchy4Yhm1Jb2E1dGmEkB4C6n78mWBUDOTWnkF8MMpwiEJK5W6oFNNJ2dUIjHTUVhHBeOjfNVBZNzasF2iXThYdYuO4cm9/qLG71daBGAjA+yrOTciNA3HA7/9mhZbhYxCFXDp72p71/kkrjUay99tF2n5v+LXOo0jv6pBJRlIWkTEErANg9nZ0M1xOJ3JUvcTxGVRW40cPo56zGJBcDWJ0VuwlsktcybGzTRct3A3woQmiRw3PKuMFMb+9UaZ/XoAb+81bzTRKah3XAz8h7qr4K5DO9AboeURxFEDS6rH5rXwCpyOCc3LeIOxZnoiiEQ/pT8FL9oRHl3AGAysnxQ69CIFnCqSxLmdIY+W4zLoiWfeLoRFPcpz3F3gCCbYAC1vkEu6tbNTUmwFoBSPFjnNs0IeGiB8AGIkRxqX1dnMjcSNoUMxKYpEy6JOLNGVa6XyRxVboWVSDMzsoaCnmOvjWRMjxdtW2H2+EgvHkkpELRoIfH7Yg0G4msx4cG/nYgV/JbOAAODVQMTw3JXJ+Nhn+a014HAoB2zKNqceHp/pRDMz6h0khkSEJonHdm4U8VX4S/c/X7dLtdZ9xPDIB52QtSIJmU2VTYkbSz6J4mx39Ha/KZqad5bAcIQY8W5iz4ZQewJPDKBjrrNwHUnwIJMUPe4J7MZzgojJ7sZ6VW54Q50Rvldf38/YF7ShOx5IwimyUMMCXpgoLqB1YgV/s6P+eD16MooMqvnhF6QSJQO8xWItUzNIs6iZ+g8EVzztRWQGmQM0eXXBgaKfJ4JUVxKsgZcD/coawfFycHLXjIW5jFryf1jlM2tODu6JJ+DAKsQzZmI/vbAb8QnnEIKKt+lliA9ncmAFaskkm7N1WZujnbukCKEBXSsdmLqJRL9A2wA/NtiNGM7adl/nI80nbn9u4BW90Iq9olDW51TCwSk2cbZ/WGRVLcq9J+RRCwSr8QCK/F0zUu5hIABRXAdCKeuRYMGBlVccFlkTcRZmtIsgSaZsIFhTx3+O74PjbznHbYJEXpUZmrfLIIkjLLFjUuAxFXn9t7oqPIzLEL7QuipeaOZgOpBfnCT6aoqJV7zEA1p/0RRCRmMy+/COyDAq7AGxFQrbpGsN/HTum7We4A9Lyp8DKSe10GCyApJdJCLIT7iRXhm9KsVtqxr04Q4d8IVOKCRKAhjbQ5falAhVHzsBaZglTmvZ7kUm9rqAh25H8QCaNrvrR8bN2vHk/vfgbCjuoQcQKNh5VIZZU80tjUF9P5gGEy+jluYq4pnjCaZyFJXa+5tFjEdifrzqIAV4P/cojsGy+Sgm0amVGIV7f/A/7ZrTDRAhE0f0VzSaEF80qiS/+/3cZoTfH63VEW01sI5ouDAMzhcMAW31iHNf9RuDwnezdox3BHFyUmVAqfHu2KTBwqI8jYYYHvw/EgVcKsIfLWHZSIURQwDP+HXiM0nqgCD1yl0Rr2UJTPjt3DL9vJX47Zyt69ugIklCh4TVUGCVByZBQREgDG06LZrDMmKJIx44KXPmmrUoPx1gQgPE9lME7ACZI6pZNt7Jr8RB/5Kt5gjb1TjbEIWRdBuGUlBsvgONEEggZOtuHQAZgKuBo4QCup02cnpjxE6ybMwH++UtUb0fRXmlnFKONAYvxQwVWqXXCh5IKxlKeUlBVKUVe5QuNvtr7p7zKFGdJvr9vIv6Lrt8RmLyAwPKpQRG7KBJvEEoEjNYM4s2I24swhIPGD1Gbtge7O1TCNnI9eSRG608QqpIEjiST4zmlp/hR5ndu3H6e8qQa2yrzvQZ5uPFXQYEf/DkYFLCNQfQzdtoDuNDFAu4UbeHkMKYSddQzTNIPUnhy5LwrdJ1vzRWpvX25xKtyKIixtGN9nsIDQbgDPfWH1ClBZDbR8Wn1p+NOzwCJWrjAcS/IO2gG5NiymtIEK8Ju4cUaQkQOzyzI99fZrL+Nkt02ljJGxu8thX5uSXoG6QAMGbFlO5uEVhKMBItsg9jBOSkl7yLmwPNkDfMpBKRSPVqFJ6FpJ6Znf9NTp0/NpyWRY1aBAoSQIETGoAJLAJQLIvhBiiR29NL9nFK/cSG0Xo9qjyaTxNBR9okaRtNbvmtqvObh8bv0makuEsBQLhk2eSDm5Yh1NcmFf3bpdnFI8gRcJ0XIzWaQcbN2gEUcI8GI5npVGyQvulvHPyvPnYIbABOO5n6CqCwklFJS45KQIQiCU0vCUCXeEyE58O2/WGkGC7UmOiHzC9fT/y7zi28li5dz9WClzl6X+m3aIVwYpqqChaDn5QywR5Ce5miZJN2xoHCoQvIf/s8Jf/i+XZ/S93ykfFebtuo20apsm3dwNDMg5uyTA8iE9971he796P47/631b6d322HKygwKj8TDexx43A6RMyqOWv8O48Xeve/ndd+E796TP0rTXvlxMCns6brXJSLkP5Ze/TLzg8vN/0T6KZCPDlXf1aSsf/1l5npohq+/oHzt6uvSvg+GeeSoZN0gux3fwZOHZJQ2ae9fLwR95+cWyIHe1pO9PdqOFPIg3z7cRdJ1lTUITEp2b2kvf3ABfWzboUa8r0V2xzR2BFuKssFIa6yglt7w7ABJs/2Cw4M9kD0yY/1VIfXfbyYb/ObfC+X5MWXXBq3s/Uw1L9dI7kXVgnB5K9ZsSEYEtj40fMqjfyv3PdFpeHgRI4jQCHEJaO/Zm3F0lCsp/QIqx3SoARZVBcVjfka8pA/ePUJazua54ezRLf5CgAzbKFyBlfuOV/qgVaaPjBj8xFTXhUGTCAeumDGiV313K0uzu3mgwvNkKWsQOAXHzcBQs2wzct00VfL1+xRqWcYo0FWa6P0rxq3E5HIkKTPd+yR8lIm6MwOnlsTpyl4s7dXFjOzrbjOKs9eYojzTs9pHR9QUKq2bPNwN4i0TIxyWQsZFbzIysA7Mmh6Mw0HSP9iyhRZlaeFLh8LotMEzfo9lZDSsYsMtf7a5YrbghweTeVHtLJ0SEtoIpTuiZE1Pd0XZgvGTIIs5VKhzh6/2fagbXSh25IMtGlaJe7PAKDfGuBsJQU2POXVYA1yv0+aorLijPIvr2wgks9K+2bIbDccgAnPqG8OdWRGNcKwFB8crq6a90Zy+WNj8J4UrgdA0T6JUqjfAqRf8OsYpc/gysAoydPACDWuO9ur+nForT4Lh653GcI4M2EBUnw9EjhJgTJrZTdVNa4tSQ0mGbqZ9qplLXPFA21UX59zWRYMh2fuQ1vRlOTbbTMnhX7A7rzje14j4yWJMj6D8RqACd5PhqdTpuLOOV/Rs7645L9qSr6QtgNGuypZaBb/T2YJLakgBLllZMzYFnAfx85RpibWkBKAvjUXk+zdjDtAQBwTKCZloFVMCtE3tPkf5pti/Kje2Z50WiRRNOaYtbzBfOxkDMU0oWBE9gbcABaibqEs0laZg9naoH04qfczHaigYhVGbgjUsA7elsz7XYHW7lGuAxgDp3rhd24Segd+a5S+Mm91qY0cQBvUqAUEzN1nMCnyT93+uoKopOoohxGtb58xvH03N190j7zN14bVLVp+CMAupEAj1ZUCY/1+uk8R9/dBKBxVS2HPc0P+qOeU/YX/+u3TOCwBX+hCJ9cgV5Z1B9/hLNimzc00+vfp8RqY72tkSEQFHq4u6Luorv00zNSAlWN+5Mx7s6pKV33RjWXpAHrU8uuie+qmrGSqI59VjhuPLAT6zLGuaylIH2uGk8tslTz66SPoqZ3GfNn2iPTAQAeLS1VO9/Ikp8DDaqhqVnzdQ/hNNumBHqlgPzaE0rX6CYdZU3gsXy7B++9s1PwtLLJWpnnWjBoYJoKIwl5YjU4jlcG2zHOU62iori8+cYW5+7kRa5A7gljtyCJv/2DhrzxXjHPvUdBaPh4+Uwctq8zhkSCXCQwViW+e1ItJW1M/kFCY5ZgCQ77PCFvhHptJypTMri3VYzdlePy4kVKTCdieEh+2xkpxC/kcMmn+O1h8y+1msmHYLt8+e+s+VsNxzjhEJC52WMGaryIsvUVCpXlRcTfHTJF9HPLmdJZapgZ1rJovMMnKlPHCEav7plSlzzbVA9X2jTrHNhhgyJ84M6N84RHx6Y2wyp87Ms/Tuu2BcOEyIcW76rLNrb8ZKGIwR/udiLUhuaIc0PVFGqwo6+/nh1X2NmXLwNJjp4i0OITTGommpt4pxYvqJXW/Umnc3lhDapfttlFkZj9Nly7N7yTnl4UaHq5eKYFqalqlqvcMp6lIsWBs4ppkRWpTQ5aSMMppgf8abkups0bHBWY+0mdiUUqC9yJpB3gMfHMU9FcZNdmYylQ6uzQ4z0Iy9K4z0njfF46gny0rTxf2Xy5FWPFv9MOurSzD0+zOBqdX2y50nqSH0mSwDHwPGUNh2QVkq2v3O9vzp8Atf1+SM2EdL5b+chFKwfv4akSjvdblcv2C8aWyrCAqqzWoaCNiRsVaZSiZx8kmnscIKrH3Hdn6H+mtoPVAV2OLHNjpvB0roVw34oLsgCzalMvzLab4eOVmr5qDgai7UkIw4qX3HocrJBVyri16MK/QXJPUSSM3BpgD/xaqWw2wUWcmCAxAfjMYQOom+hl69rA/C5inaa4QtrKT2FlNm+wZZm0IsOc2yHkLhLJ79JFWzE8kd6JeLU06Q6lwypqXA4UHR4Sc9TDOFRW3pDK4MpMranZF7mZtiABMYKBgF9ozoXI2q9+jBAWgYRj8P0msMAFF8wE+bR45s8jgD1tCThmueaLoZJ++xOTTA8S1/Av/a/cvdKW08+PxzGoCn/R1xrW9HOQuAMlIE2Xpep7kMVJTXTz5z61Zb56AO33iCHUaBvky/R0TZlk4NQjDTwvJxW2pRIULAUZ2DVoKxR7uw5c+NDnN8vHMnnUztJge0Kz/lMjV1XdMm9CMqx6XojMbG+Vnn6wQlP4lDZD5bMy1rOzsP4hmD57aXRcBmxB009HnYBxtHZuiBpgU+Qd59P5gP8tgQBQPUDejDpdgd7xiXPTw+wyTPoPvn18qDQmfAHwtelDF/JMo0lV7p0iNbuZKIFAYD3/bA4z+/Vr/0mYspzYLtaa0AQhCvmylRDlhZ1cAL9zP0qfCiIIUfcih7/rmnFyxU71m8HPf6yuApl96zSNvf5sMqz7mh5Ixaeu7tu8Hh0hnk4zjaeKXTHKPKEooDjzcRmiE9gmyuGUoEub6UMh19ooGp5e3xkbtpj+p4A2bGFtNxXBg0Bdqowe2qp57pON5GaO31KULKWzMqSZIUbfnfXfkYyuvdTtzmxa2jufd5YWntu5kib+kBunXAiRzIilrnOMo27bHZjrShW+BlVQmNeugwtXCmhqKQg4A/hwWERdWgsPu8YAAftf6QZhTTbl449jlKRnLrOuIiBfR1GMtYTcaqhzs8IjwiJ0YRBWhp9ShW4aI7Hq1KQ0cfesbHoZ+2bfqkG3/IDewPPd60zYG5lLOTUX1Bu2iUZiPjtvLMcSMzAmVjIKr73pOJueSwICUIS2Wioc6FGAcxQICmpmJV5YlZfwWQiih4QkiQ1E8S0uarq3pm7rCqhvyyDrC5N9lp/2iGNq6YhmCDUAfH1+Db5r4Hv14z6oLvIqyZRhYZenwBCDSxueGRiaW+rUSiXIe1GW4gFqYOThzIr05eoo8ELtWn1D8yzjHIO2OtHbkZcJZlPPEbDx37ODwmsmloNI+jtYxsqmb2sRlzJroHQVwjju/A0Ux0GNfBzAfCaePj4cF1+mw/yGj5FMDg8kU1CcknbIBvi+oPNf4DOZogVsAUHraVpArsCkj9rgJ4nZiKnPZKtJqpiTlrK5y/r4ILuhWOprxfXKqMiyWb7tcx790tDRJgIHPlMbYxqZyCQKpRGKCOClMGHSnjMMIouKYvBIUFiU4RlcIOvMUPg1Cqq+o1gzPCYaZjtdImxyYhtJSpmbly/iAFG+0sGKEbw7sFNJ89dQeWNdEkUE4B+wy/tKYAw9fX9FTfT2BIGMxIJZAagNpKWu6HMTYJKweitGy7hU/+Agjfn9stQ2qoxixwNSzMypR8CdVGiCIcrIet9PeAl+mUa0gCuyGEvlq72Hl/vc6ROzl69QmwfBkHEYu7uvfKvMI1OKyaDEw8CF7HPHA5xHVyNmdU1TMks7pL1nMU22EIQ0HanBHr3PvMJunEbzOKl4ajpMgq7jxZduM9MHiAdg8YXjPGfwA8c8FLS30MasZgE1Tn+LRGnm6IUbkpNMSE+28lCwDKfzfc2oCyMD9ccYEWlMwE7wVHXp+5Tl7Q3oLAhpZSJ2QU3fISXowAadkmTbTdQ0e5pbwc5gaehqYJM/1iPNe9p+7aucc/3y/d5iAkN0ZSfQgFgSpaUFEzAJntrHnOvBkzYWHVcIIIItI6nDXakXIoZwbXy0bd40DzxSUIfpoS+hgMm+m5CqbUz3s4dc7BTNFo8zoPMBNB0y0oU/L0rWwHzBmOonxHkllCTkE9g3W6k8H9G+mot0onD/sLDHSuX2lPkpUTNMKStFKOMM2XFyMay+X8bVwAKGZVmKnwHdBf0FsciEXlIIEs3qKiT2YIJZiWQrSplo1NryVR5PfsU9skmg4X/BX+bzf5nJsm5Kd0Mvt32sA1vOf5UVZ55M42ow/TcRmCSQ7lCIYHm53gsWSAimZtVLbr/zIUTJyhUIdKuqK9cyhgawE3tnaEpW4yManyA69qnHJrTb20UQE3u8dnSLT8dUZ7n3DKzrEMvD0b6E15W8bIvwXRNReqC5a/vfvIVGR0FYR7gLB7wMnKRTF8FmGuLxaSqpiuSDOb5Q65BbSHpgbCeIjUbCujMUSvDblrvnxO/UQiaxvHUtp/S+IQAhoTysv41g8MzICSLvN1qFeelM4z9FLKPj4sE0q6481If8mEy6pnzs2lGcSxib32fBxPKc74XjhDe5xk3BJ2vFwbcySLKK/2PI7N4d60S5cftwfM4E0/PUwn9wridREQKNrGnyZyHvCbyPkU37q48ts0Z+OpYjT1qQDOf0H4zHVvCmNP75bquI1XCZe4+P+6gJVbCaBIem33ZF2msZoSYdswwmnkdKUR+7TBr02Q/GcvQXXO32QIZc28/YgeyzIciwysvMFJTnBmxp8wBJ7KngwjpkigSS+McOtR8ZT8Ajzi5+IzkYtKGxiHeFRT6OdIOFwfoVTfD5WBOgOjzjg80DnzmFEcRzlW0dLBgUlaDzQiloOh7B+QHxIz92LvRtGIwjgMwg556+PisulCywIsMCUquW5Lyju44rLuuU1VN1xgpERd1Bx/U6iVLZUsfaMwM1PvDXwhjFuuMwdQ5W4Pk+BxDziLUCLTgYsUKrT1N7tctQGkGd0VKLhYskCYaMJqRszCkrAAhm3hFc1xSV5ze89YfQlXWPThKuKgKXNRG6nCGJ2orfHx4sDqS1IAMYrPouuHXA09bpXHzf8Z3YcaRkAK7YkT5xnuwwPcqP9cHLgL5G394t+09Yg5vl2pHJlCoqMrMeZXKuJFdUkl9Tq7GGMpLec7NYNCfuXrE10aJouyGaeGB7SnGrxlMuELG3uKvMP397yWtO0ayCBzPztsGnoyh3ar97/OnDFQ0+uVS5sq6rMBRcqQLFvJ18nRsqZXLXT6J1bRQCUEJSvyowhA6ay3fem7JZnJOdvRQtBUCQ19z5ViGEa7AA1p0mATp8vUPDiqGrPxjobQ0mLG29cPCFTrw+NpGSPN3UCFLG7bw2b1OmGftz6u53VZA2/dW6Fg0iWNik+M1I3mYBlWvYJb8+nLbSqyEts3tkCIxthTWizQksQLA5tJsxxcO9XWqpPBQsoUXgQV3uy4z9QW+zYCmhmyhTzNJFCCCQ9GfQkg+OnodNQu16B/rowul2HsTmpMrsrQUsUMfs2JXWNLlI9mQGE0KR3uBA90SixGUPmzWBWNxEMyROWBNAM5Vqm5WAag98lE8cbOByDh3Ea8Iaq6CG88zB2RNHad363yxmpcqmGxcm8gsoahmXhFjZ2kwjYBGVy4fe/XI7YbVEmJpIEFQtjYXshgyEtVdwnrTv0ZLtQ+YX9WWAael6eHLxf138ZJvqOp43GlXkJTCkCYZ6xmgSsGuvo30gl5xBu+XhJBlVD15wxH+XQc6OFL7dK/KpDFhyf/DBfRbHYL+RgEg6LCJcPv5ni8btZTd84HBhJp7kGi2L6wUePvfgH5+2DO6btGK/vThId9vX6ZXUtln6XkM/W7F48FsG9YyRtLQ6/htnA0vMhbIlGyF1N0Cv0cdkxnw9Kzn47X3WnNZnyCZpDvQlO7W1kWvkePQU7D8Gxz/vatHHxZEWSnLNeZts6EiugAkVhKh2/Wmas0Jg4EVla9vxUg17W8SUnKp+qZmdYo0o6ryTRE0DcsRcJkBq30EdLG9aeQ/fhjhOk09niD9+2DG0XYh37x3Em7gni6nwOf0s2PybmHEuQzKmRqkKNLuKLJexbem/7LykLs1YphKtRAHVyWCDt4zcU+d5tOL4IdgXpVjYhF4D5BLT6j2J2X+5pnhvwm73XOQmeg5e8ZZUD/pP70B/3ApeOeBOWUvw6LVQ6LyAo0KZI8AOV6XEK+ws9RWZQfYUBiNEG8GUDLQA3SFOFYdAgoxKIZcaFPD2bh42gn6Tw9eMKh06bwmtRf4iqMenLTq/yJe49UW9tsNYL6/dUydNTc17rdFn2lTpVpySr1p3a98q/uEVTPraC3v+mUiorq2rKBqHbUpS2zLAp0SYu7qBZcfg6pYBf37jaxKuur8TxSn+UPb7IoIU6WoGytse4JkTvJA4thrxRNJvFvZiGlTTdqLUMpaxqkCnsEVDH2w7yJk0FCM04zPbd3H6Swftgi41r9kGXzquvWr/5JbqoHfPoDJ3FIwo3Fl0GRdUa0cK5r+Jtds9ltKgbCaN4hUrcVEVkkC6wSpEpQ4P3fing+H52OrCpCbDE017/jm/jkm5nbvvG8w4IvTR8Ups8DRFr0e1vxceBp734hufG3yyFRGiyhL5UASKrufShhCyTXqrzEvo5yC23TEz4Df+2zfOOWt/qolaOkr0VSOsgh45pWepzUMwTW2rAyh9EPwtEiOZbAtXwl4V/8fsQ4IBLXXjBW1dA0qSXTWbm/mU5+JRiQ+HrUPvV+DtGxRf+3kAbu7xN38nyezcYU7tpAsZbVxUgzr4PztPSeroOkLipbXvYSRw4km0ssl40Xx4QCKmTeARxR8N4WLZCJpC6vFigz36fbmW32DvFpLJ0IHSV1SRsTFXGqPGJDH6p/DqBA0dFcEZpIWx4tVeF3KDnLkl9Ou3qhO0ceCGqQnOpbGSjsEgzgcgN8okjiEMjNBod7FUSJQDMt+GbXqgS8wrhMZCzgz+kEkaE17yNoBnM+eYpS4kg/HvuseFJC1mZ67HLliE7TeWid5tQyPb2g0ynLiUJM9S3eL68UJ7c7ZRaqTKnTJoO8REAiEYXR4oasJboZRD2rFRbSV3FdkZf5YaR2yDkSYyazBenkFGyLDH7Dg3PeOO10xUqMphY5J4/KXxuXy76AndQlSUsTGZxwYY7+y0r7sFAFSzWrOvLjabRTb15TFPaaYtnQdK1wM9+rM7sgSiLu2dLqyJaTGRZKpj4uYtr7rFiYWX+xO6GDgsCyKokOiSGJnUgwebSCYlQnWC7xIuXl4IqUrOEXhIjqOnG3VXxRMV1/5Jm0CjNxyoVw9BrAD1nCPNRZjFVKdiUrSkSS7diaJb4x9uc5xqOyzzn95cl2uh2ym+tuyKsD+xow3tR9W91iwZ7WOPsDOK3HEseSU1VGZiFVjvsiq8kJgSVrCCTLXA0TnMWfkzuZQ+PjPOBvSzlVQ3VITFyHYiFobF+oMrt0toBkOXeO3qckaaajRDgV0GVfvlluqnbuVD1AcR/RBI2H60/WHu5pxz+Xxxvb64Yqe5tneKIr9NMmeBQFPB6uD32hh8YiGcywVUV4NRAx0yLyhcBi+RMhHyoLe4ixewivv+w5MMDMamGGxlqu5LqDt++OqiXjXz7/L/9cvvAN97PP1Q+cWiqKmAoGQC4QZNlYV5GUIQHRObOJFvheeG3fGlZqGz09qKwsXQ2lE3Ou5a7kE9Gk1r+V73k8Wu3Nx92OPup7vNq6HX9jweveeaT9eJGj9O8FeyES/yV2HsNqKy1U4W90LFnvPIHMYrHbsH2veUPsMXKB3Tk2sgErHK0xXep6MM6ND3e7pMlM7gD6kEj3YHeRnreZ93N7AIat3sN/i6czL9uQJDhtm7eB5Kur/wrHvpt9dD0gcWt/uObGkYMP3O2e3Dn5dz/MYMEc9U6INXWBGAkcNZIjps1k7TaPT5eUd3r8dgHbfOzjSi33t9uV07Flg6V0GFWOGhqPzrdT8YgeLkJwtH+nxU7XfWy78/1Awvu4TW9oX7MveKD7bRVQ6B8lKRTKJJEXg4P2hSFWQIy8Gr3RZuEYyifUN/XNwoFRLHorUAzb5kfTwkGBz2KEMXrHJWbaLcxO1pQtBNh3PFKTiw/wscve4xrcZbTMuLBMCtpOFGNzkes6VHOss+TFZrbtaiwxO/Pe30dw+olQt6xb7u8CquAMHooBlK5BABP4L5pq5cJHKLEwrBqEGkPSpydlC1U6cADwnmiHm6hXWTgwzhrpH7lwl3CWnVwxmFBQUo/56jjtju1oXW7otcKY6DqhHakjG/xy4tgGm0QLvXYafpYOqLvxwkKJTlvLVrYvFWMQicWTgmZOASWKiqc80I6Rsx0DbDMoZkNNq2IKrCYBaM9L4ArOeFG4m8cdYIW+jYt0H2b/uBh3qq36fu9qToo9JHBAKQTyyYx7mZXTBsNRDfSkN51xQoeMiiNIXBc21ruDDLsgF9cCoIZFg5X9ixNTdCvDjtZEDajVHUFbvbfT/CXRG4dUtaG3yuGM+KlAOLJgIC2AINWevB2Y1PuFXrVSS8NkRZuq53ARKI0ljlrE9R6GqVjPp7Pqknc3ynT+++Ywcx8e7Kd7SPOrQpLXflL9UHSeHrETnK8rowkmatWq7JvJoUz3+5ICf+xoTYqcCqrfC6h0D+3IHNPhVReQsYzeiKx8HJ7jHUvl9LjoJ0M6Rh15Tax2TIKWOqeaBXf2WGQY0Mb4SBdpfeiIL9VrwxJFLA+pjMF7Q5yzZKDfRClkKxHK4ArgLf5dBl/RtOamaKJguzOzQ36gzheFx7UAJ2NWFBp7OuyArorDUjfjBkostQ1nvg4fJ0CL0RRvROPVjpUbiN0Lbhh9UXhWFWGAtET/6QUzfHqkbqiCKRibh02CMcjYaxWbm6JEuJYnR3LXPQ/9L98Tl40DWcwwF6uVMBzkY1ahzUaialptXFl0+3k3BnVunPnOrMuEY+vAiMdpm2lQpmUqoqU+Kaq03LfrN/Nkj1HBBiOw7ALtLs0v++/dx+eUMRCk5VphMK/r5E2XR8iJnOBeI29dnzjxNMlIaMZbZjcIq6HJZIVoXXpRZEK7UN0SIdAH2Zll5w7SyDsl7iAiVNaXgVEiHLRHTIbqnllNw6cjJ9GUkA45gRq9clMmVgNYb1JvBw/hjtCh8rQvhixJNtbEv0cO2DCMdG6Tuh6G2LEHKOyPUbFm2ongEUeKFnAccb2LupE8xnx2lAMHB48sRMXpIZDUMsaus1t3WdarrVINNDnQLioj1mhqMIk5FfpwYVeiYMNHErHA5ncjd2h2ZWAyUMqsGCfwMZumpaTVVTY4+e2I5Vff6AHDkirnWVoxpxFl6LfWAWDn7rehViWWv9S5OtMmNwu6WDXEEHeNss8XmZjEoT0qAoIZEOZlUTbnc16DUG22WALPBUBdMrE6Tb4RvNgniF2ylw2zz4CL5uaBeZh3Yfyw4OX+yYJG7GAyc9LlH3hQreWAG8Nl5KZW8cG/lyOV0kOiqrf1IByk6IZFQJwaju6ejm0jYJZ7cUifC+3VATDLTkyxKxtqx9vFirch8+LPfb4OXS8SU5cwhNygMKNUDFnCQfsrcc7+9Xb6/OPp6fn5+ee9/L6X77PMyr197376cfx1ur0OA1MyIOCxG4kqLBS3TPN3QCCEpB5mPdCNxMbc++DJfGaaQEPuwM8ruO5Wn4JBmAA2Hy0uDKlHrGONksqo+GBEDeKih1RwGy/WJUPsNWVSIttusZnEGrOcaDCigRZlOj0td9THvC3nysmjcXhhUChHHM0pSY1OmsiWG337+vn49Pzz9/fznb7r/efcfq6pzPqsXO8vv38+P91Dh9fiKNlOATAbHH5sx2EHWPQRWZ5ttBeHy99DDqJLPTg6nMm6AQNRtTczSNMRyxMfo8zRw8UX0IU0MUFodMkOy1ALKjdhxrCpBC+0MZLORpJaLS4tDJZENqfa/oOtsNK9u2dFvzkGuk6c7iIumhXuZkfSliiDyUheAmMd8O3zBLFYu57PEndeBF7req0Xuayec/VMMG8TvaIuZISmFp0G2XqJmquekLWEfRxMddZbRCSHahz1J1DJ7oMwtapqv2nbV49OjFQE+gVPjsArVRbtlDWYlReLPZ0nodIEk0So796vVGw1eFrq5R2i4szZkh8NLKwFvYXAXy/6RJ6dxDUDgvrhk5LLwKHfTj+efwbA8xXIqlJEXiOM5/kTHM/3zitKyaRaPLH88XKrfQlATdFHJf2oc7SasAJ0UNWKIefMsoOFBWYJulFnDAIe79xfN5mDQ+VNvymVzanaTxdjFpHw3DtXVnWBTW/6LFsSp2WBpynMWpM7J8uXbt7CUqwBGiZc3YuYcwMo7yuhfwrqEQXM6XCCYLuevby9PD3jmRd0C8drl0F08SyFheWcOeuzdZ6vmf389PIW2IwaSO/lAukrcKtCvjKBnUCW3kdO4RD5xGiNJeIAV//aBO0lsB7rZl48Kw9QqaCzqWfDUg/oVFeLMNraLWpjA5cBLbdkSgLYv4vwDjaQtOEPFJQqC8SSZvP5LeFun6FPePLEeqBQQXLwaA9WZxl/2Dm73SZiIIzmHSpywU2khQhlL1JBhIpKl7z/W4Hn+GiwRpEvIqoK1TRZ/4y9kD35Zsa75fLz+waL69H4cF0beO0YbhsMlUJk8BgOem34rbAcVOrilcymlc2DsyvZUIMsGTOSIJZA7PxeKek7lFTNbPFHHDB1Q4e1e3zMuyunr+d8fiZLElVK9o9yKQhpJDGpjFYTBtsOV4XJV0mNLLlGwpzGslDPhH2qohUpTJIrrUVS+WN7NOqWecazezLoC2KTLvtUfhXg28/DdY3y3MBqkOFy8dscGGrNI9BiRAUUj0CscDKAh1/bnOvh5zckr0cI7lGSc/wd8MEKI11Ld8ETnOGK9b+BuC6aVqCPn2a2n0NMdAZ5ewnPJK4EZdYLoWlRbFLgalQ6KlKZyqsiWXZnRm6q5ImPRlWH6wfg2bOUr1YZqd8ZTJ/6ZeYqE7AhlUJIpY0/PaCMgRn4AB9IMeIbfcSOAAeukEcvUEcdcrFcUdfj9t2tqeHpdLQydyZbrXVFQcN3uvxQOKYYjJozucNFDpeJWrhyt7es963YIShUEkenpEEFlStU0NEojxhpUqipzSRjAD5xLAJnzVkjaIW6kuHXEw7pt6/K8qjQWcu49gnvTCTJhfFWNK1HlOa83wgSUT48Ls3nEEpgQvsaXyY1cKuQhqRCdffYJkVrM4oFsGLCtl++mPKnbj2a8hvc6bFPuPmd2/2PKiOmqakONsMMkvlaDn6dHXtQXUp4lIFYET+rFZAR6tzWGe0GMIcqr1qcabUiULnOgYGmidhaqxFJjWCqT8+5484kHWcQJL32gT8UMprRsRyuPVEOD0w8iDiGc4alYDVQBCqO5CzQ296ZsDLQjPD/THWtI+BG3/X70onpVGVinR7W+0V07MIU3pgJVE6G1hgzEUqxJFxxe9xQlls0qWJFpCYusqpKGtWWlVHVKsp1gRs9Ml7WrkkNLVEbTzsuI+n21eWrUFdifXOxC/KBuOi42o8XZzlAYuDR6IoGOrlCjxs4hoTIHooKrEolJAIhjVWVjSXJcYAbQFv1eliA0YdBSL7QMzMcg81T/tZhPmOuROr1W0XIYx2+etHC2AgW5dRhFxGxWtrlLuJN9goMN8XJg++1OOQFn5GKSR0ekaqnrCtPotr8KG4qtRZPKCKBlU8imNk2beyZMnCAIMHfEQwDNxGMNBtHTErdUIO8dsA1uy+JrBpSuofOigQCnKFZ/mHSB4zix3zHVJgWEeXObJyMBIYhS3ltVR+mAGa2YT2S12PJp4LDnpBgqWNe0pl9jfercRXficrW5GPypRoxrG63AFa8f4lQpp+WveeTkmBqoHtcvl8Dn6CLmp73yH53UIPzhR8xDNTww2xMut3TDF3rGKayKq5tchgxgbM1xfzju/NhEN98Rsl8hqSGWk9cMnNGHCENa8RRTJVa7x7COBZPNz6/+qUv0eKM33rR55h5LBRMr3wdqveIqnbV2VXcq0wm39Wj3z4JW35GYj6Cc9lfgS54agW8OivAGFyR6iCM8IOXDq5co3UxXcFlLhYQTnoDu/EWMHOy+Fmv+wuxHwLZ9VwNjGSHfcgTZt6uwf/KMMaIJqAacuLBWVEuu6yOF+DWTuREw2Zr0D2nd0ao1XkZGZqTayvrZYHq6CfnL2QjFFyd7qYeNpxoxw8FAxzSD/Brg/R3KyJCXDsYCVl0pDxSC9aZegR6qHcOAMfLO+TbAxs58AQv7lL6m2b+Vyoy2GxhGB45wiu0op6ATi/6yorNW8wu9hy9qXbNvehc+io687Ga/c6KFnOrin0dK2UxwUQSTuePJBqIk1QCW982RMj0r6Cnk0VSo7ISSgqqkgiw/AB4HGO6CvzsevEVUD2j9vFbUmicEbmJLnjX0ToJrBvcyKHZ80k1RGcxbobqYmCN7XDzmtotfZk739Kc4+xrqpxzTOamdbhq3x24zq17JMV1+rwR93Xfy6tLGe6ZQtXsGz1FzhA4VC/q+nAiUJQOU5btSDMM/ISgfAf40zoU6u0XIteAkSqRakDGmEDRp+sld87M3PyaL2XrwvuTbRtqLuVzu0dA5nol1/c73PuJKXMnsj6dNf+XLu3Tj2v0tN/c1g5eUKxowQqU6ZDBM4CC3A5y5jPYxBz5FVNaOvJBK5nSpbKn2YFpwNver/uXgC7up0BjPrvOxjidVFP/TiDorg8oiyaRANvg6CsKeb4RKN1x/Uv/VCzvlL9qOeeq2r0S/heE4LIHGPDBxeI4o0MpwyNHr1KJi8YQCnXU+vIAM7qgDi5NYIRcETV9EmTGjhSe47juLyfdbs+qzW528tifTnIkN8dllTGbaCWMa9imP91BY5lX6v/Qwc7t7Jrb309f3WSt+6DWmoc6HxpkEddBXuKiYumH/UHsbK7KpD1rH2elDrYzkVNUT8nlBNiRyMR0U/IQapW67U2eH1tBBE1JiCFDDfG+Dokj6CKNyWOzVi1ZB1px2PPLc7eAvJWFoebf/FXm7t2yPC5bCFjqntsukEK/b8CVgD7LFc4asoAOa0btNMdePSb7nNqFYyjAZQCc6YvhbTE01OnG0z70MOCuEBSihEzSRmJ18O6nO8EtyLG8DXzK/HvM68Cr/yM1O2zHVVCERwzgsIOqviGDJNIdXMmxw6w5USY5gT2OoMUdbmxaiYP2EI4whyXRgSHotqBj4ONvHT5KnYP9jrT4QacRZdjIpCtRWvPrn8/obdH3dgsp2r3lcPzwA3U0cEMtkwwbBpJhLUUKn11gS55MBVC1EG3RBG0cNNO7vfimnx+JZfb2GU9soNi3fURM0rpnJ2Fx4zvzHd17+HVnxdvl4b28VhHHP+Wod81twoRoSEAQUICCOoESNqUTG5FlVWcHdfJFBQrJ6tFWjr3bx4swJHTlnNuiSHLcddqEjKot6DScpOIIVlRd4v+VszdZPh4/UPTAnQfZMvcYxAlLDExtElqXiUMaroKohSppv2vnZHWZIyWRD0gZ2RYgg6xdZ4k+6BwjSLmz2Yq98UpHf354L69X9s8fLJ86LGJGxi1TUoAFxWjOMozRsDnCDEaGB7m5roEtV7WVK/apmVmth3N32QApm5Imj0KqACqNHrWKjjB6F8jXK/urNOq0E51WhAwMaKeFPPDHOgOa5AS1E1us7ciphozjl0M+NXbiMPz8/ZIuG9JkkpLuW/203ctLIPgCxC9t/OVdIF+x7DdAtHwCkkHa6EkUhCdlKz09FBVFs5oK6kHqnSqhuaaN4t5ppA4Tg+47YbsvCZ76KI2q5AutIalOjU2gH97LK5XDb/bObdWJIIii8w+ioC8+HCXgi2DQFhnx///KdO1ZLItWxFtUmNLMdFdfEnG5q6on6mMMgzpZqJ9SU1cJEBbBUSybTsZJX/K76DHEilxatYVDSmePD/npRUG4Tcb2yRkmdnT4Yej2kTiCuV9uX8s97S72hFqmBW3hkDX4bBIlpk0HacgkewmmiguhdPHDn+rK5jStuLQMfJx/SWiTsJ188MbnjvZx4ZHhvqcTVZxTGR6PTruHGa170LbuECoBMVJLqn1QBFBdwAvZUg7CuGOCKdlsQwdZZCMl+Nm4FTU7AXtMDMPkKEj3HfDmBduJ3SESOPdTIO9hROvVrDRaQO3yJYl4ICvLxcNg3SG1yWRR7tC3AG/XOXhBtuL2ZuE8LFyUxoI0iWSZ1Xcct+FqXc4M8g7mUc9qstbDtqImVS1oWz/LcyvLkUqajXhIc2+cqLQ9ltA0/hvFt0siNXB53Jifc3jfp1juox1H7vM1R0eF7TODvIcZrVd714phYUwv5l1iYbWdxQigLafFFD62xAfggtzKJXc06RXIQxNJEacqjtmfHJYMThrHhfalIvaYE6qzH1NOgdS0OxQz2hcYGoNxxgWACyPKl4VGhw5cG225u5OMq5A9A7WT+/KnZDtOEwe54Q2/vC6QOmfkR+E4Xlfi6JRadgrkYveTRyVSMMTRI5zlfLHT6nrXwClIGs+bDK5n6au4KrAWVYz4Ybcpf1PxCjcY3Gcz4lfdyjDjyhm4X9HItPNbFYvdSx41VAfmLDVUOSzjzGyAiFJuxmocadJzM6Uv8Gq+RUarx0gT6W1M1MZRoUQhq8KGucTm6o0dqZwimbmzcTkf0ix2V3n0cc0ryZBHkbEGlywjMV210bID0EWpPzbE4oBH8FQrpfhw64tjQ+YkkvPG+bqEQipqSmrOhXJkdArkYveUR63HQEVMxMQxPamToV7atA3pMBGQUEDhU0Jzc6dvVl3ZYyvJm5VygjOhevgUptAbgRUCL1NY45r0ngK52B3OHleJNOqKHq1y9ZCLTzzaAVHjJ+4yZjCZQcxpMdmT7B7C40ch951HhxV/kcPiEkvlE0535DG3uerRaX/Q+F7P960FSayJHKSokb3gpu1G4BKnS1iEOHbZs20+oLcfioI2VfbNSiBHyCtAKzfcTSIjlJxDIpdjRu8zYv9Ze/LQmPuuRLZ6oZWxOoBrhdDo7ipRFr4OtkA5/VBpdbB74vXzMbLtBSEnj0fpzJ2wDa1H0RNc57yacApks/uHa43f5oaaNC0CFxbSYMRZ+DMjROnPy5bMi+taV5uyyr+HlgHywgPqUZedaJ2LNXh18oRmjMNznvmsdv9wrUQSe+FS8PBBVZNFcznIW8uj7mmK66AJa08nwVWYbVaDvbbX46DuZilo9tCGJlbSGGRHznnks17jPBRvdufqutvyNTJxwBVirHKkhjuzoEb1K/MQCScw+p6uldx2tCnGXSu3SWAKm5FbSCxVTICOd8+P8FtTp/98atjs74VrgZSNFhJjMAdSqp2GxAlrc4i0JAVPm0Bm+Zz1cr/EeUM2WF32Q/vAc4wLRztjTN9sXiaTpZO31pizzkPxZnc+DNcsa9ZnKL6EB16BrlUggtSQ7bKp+oricjrJAKvdna3SZrfNYsU8MZF6tojbI3Jo/Dak7+df7fq95jfNfsakMExIodiBVxcnoZmXxm4DGKbKJ/osQzlB1SHB7by2/GKL7OVBNuE70bkc0Dd2seW5zaijyDePTtPuftqzSqTHh02BYJArFxht06AmZvhftgSq9p49kYR84RVKIzzNrZLGUcgll9xH9V/P2079DYsVrkeK7BnPT4H8Q/bs8c9a/5qOLa6hB/AwxqWkZ5xOl0CJl0QvDXEmNiplnk9AURMkcxs5/UEuZzd87pwIlZjuI/X4fp75xP56OYOpcp7vaRYmxusyeLTPzXKGnemy0Jcq6jrgZFLWsAFX3mRLSsgXyfbIXgDdg+m0fEWNoqauZedj7MP+fjmDvQMJn9cpUPEsf8WqAcjLqyugUfokE/iWsqcdh3aq+ZDK6nYZVC3gV408K6zwHV2MYJYLTPfzKY32t07DV2sREo3qNQms6RAjuGFMeFihMy6bYCi4LKQHopJfg9ZOW2jkaGfyhiTGjURWfD4mXniAs59nPof9/fLassZorEAqasAge5DR4raxHRxZtDzRdptWv9DsiaYIZkSRpsreJ2xI3tgvMImrzn6K1Tm8z2tGJsDnP+eD/bWnM6sFBq6olRRJEjdJaldjLwSt5Qsj+GDMPfSZRGr9L+okh4zN4Jx4TT1ztBK7I6EcnB8R/XyMXfYvHPcsJz/G6phBmDGntFSzT3aEtiULnDW+cbpkeV/lFocKvqWyBr8gmM6M0BFIS5yo6chDmvMf4Pv99gSqfgVIYVj/ghetReOMsSoWSMbHcjz6TARFsu4Q6xbALMDmonxBdxRro74+AXFJFkNq4JtJZaI16F7GGbHL/oXjxy/sPbK1/Bs9NIXVIZgSH+ZgX/ubOjSx5aCHqwW2eimStRNAHiK4g17RyB3DE0Zn//xm7u+3t49/iz0YdkFAABVIyUS8VD7Fca1aZMlYzWuV33Y+rp9PiDFvy/l26pYd0A5ppLyp08m4E7UTxMf5t7Fv9m8ch2vW2aZpGOitvfWcRrS6YCqybG9016/oSqr4q8vL05wtUXgvAqHRZvCLb2eE1/kvQv6bPPKvRUKSBYZ3CWioiGMGlciuifAnkiqnGymGtsW/8867bMVYXcByTAfQ8WSxhiKPB5xnxP5necy/Oa6yqV5evDNzQdcqR59EKoo6UESvrO3SK+HLPym5gSCKGD5pmDiW9fb5VfF/lMebRCpC08RI2myID2ZoXr6IK7YNdBS1dxyHYEblV62t3jaKx5FbiBvAlzZ0GtKJ42eN/Y/y+Hgpe9Ut6WS0/Dq6hiqf0qQZoKGxp4iKbK5rRpufJhcbFA71EAaVybCZcU/Sz4j9r/J41NlqkwiATkxgTPuAFNSgzlFJdgemizw3JjKYvfR2uje4UwwHCWTa9NO9Mun8F8/+9HnP09uPea2bZs/WMvpOiVszRyldjnOcJ1rOVPjW59++i5Tje6ALzo4t/07LhugRrSdz1+krRGOEdcCN/zwV//Pn4U+5LO4F1N43xxM50FnItNtl86Gc/RCpH0a2cC6ctVbs5yYilzvGNny+DVG83a8mkATnq1H7Crfxjev46qOvR/+HPfmLq9ftVq56V6fuTiQdVJWoWD9hojgqwJo6CtDNaD4cgKRdq5kRB2DaajU9a2uj4J3PZNIghTBOUXOD7Hq7Xwf4zR6amVsF62u4jY6ez7F/H49QF5yePk1LyOhMf26LOTVJZLBR2sCg/3esBlXPchYVhZxMSz+cIqG+iZniAx3T0sAOlMG1P45MyEYLi75JY1SS0vt6YHmtUQilxr6PSLrz35blJ3n91u/3ABsk5tLVkW4NtbEexvFYRKfB7zmxMyRMIEJVm26IhapMLoSUUbmF1Thr/3iyfvaQ6fr5AJ58oNkviLdE6pxzT/GLCt7uFtQZK4m81uQg+z1yaH4Hpv8q0mPf/2X/+Pcfi0eYaxUN3jL96TbV9A5JD5MEUSF8z9/7OfTFWKJrbI5OTy0Hq4y3U28LoeyamSpqBLHV1oVqvUF14fJY+LDdKJywjQnm5EzgzCLxJt88ovv1x+XMkR9Yq+fXefn+Z7p/jvoSiOQJqdTidFhkIdZG1hVSoYkUMPFR5hyb4MEed5I76MsCsI4GltSlE9IqLYgK8l7sisaKsJuWM5Ru16l84THMTdyoaorGK1F7skvE9tBnFQZbNjSdjtjW0f2rOWjviZ4+4t2GnZ9H7Nfh/hDEGpN5KZiM4WYyY9ybUxYsOnRUUzZ7vI0WpnuAZ+RnXUVeVJCVDwV0WuBt8oB77s44BqZbiWO08UoFPdsT1MHYAe24VkAPvS9+KIJ9g8vvrhemP57MfZ1WUG+/ml/l0CUfi65AhPQlCvMKhuWDN5w0MzcOBt+DROQv8vUARj1F5AW5IJLBQ0BltAhNKoDO3ixzyDSXtDK7pEPGcCy+tRTSLcyVNBZtlSVOGHMpUmcjU2osEf3A7MnPRWNb3+/p693v7/qbwHGFrp/JTdaZz8ManDXCliL7cD5liK7NTArAM3SiYKhV0ETnZjt8GIeTWTLpoQSO4URV9mBWTnQKw0D5KhsCWy2DbzZN+mDtbra7JQTPakZ1LBFM+XKzqY/XZJMh9jpfn3k5gxWpYiCK9k/owqXtbGahoCCiiP//V5K6Hg6Xonk2gtF5SSqVvNE+3qqK4scnP0rn16Yday+i+0N+HwgzW9JpxLrPuE5v/Va3lem+EA9OPNFF+AIwxtAW33ALzRbhcYqCHSBAyZQt5YyydwbTAWX6+FAHMbxTw8w2eDaWD7QAGRvvJtGMbJNsBvaUOvdbCutD47A2meMB9Mhg8IxyDosJ36Ob7/dHoWUHaz8rpxfoXtfpvjZnN1EMebneV2ey111PlUjX37Y8wh4YgiRWlgAWEI3X42KF447hxiAdoM4jFGaSJ7y9GmiPv7njPQ7hcUiSYUX3GHOEr44DoZqg7oVnxjl8gBzGTo4YFnMPOaU3AXoqnmP5krVU5f37LgNbv56/5FFmttL8UyGi4uZxhaM7rgssTmYXDXvbxus++JgCqpbQWKkj+MYMnPOUYuP4MIRwwU+AmF4BBJ5xmJlBngVWqcsDa+F2bDCHa2ru8xwbuWUcT5vhWELxjb+2PhCOGg52wfDMITE1+FmIgD6Nw0JgiZybonkdqImzom+3qFe+2OYxtl7hteX3fB3FdvrHWcb3jsGApVB2QimGAY5Ajg9LMB2JI/oWTtbPweyPtftAOpfp5I6DcuxDeayQO0EYayppZHa+8OImMlPwvwfi2/AWaRz+5l9FDohck49MzuXPxPbwuoA0xkGEiHVjpR7X5Wvzsw/FhVG/4DE0GzlWr97EA0Pm5Xr5H/jAokgxgDY4lFp6HnX5I8UpJ0DlJVjdM0e6QDaih2gBF9SRKg48GU4/2BXrbBmdBb4gKep0fGPZlGAfIHMROUTy14dzPQmsZzDAHrdE7ffN1uNrxR3BWgntN4Bubbu7y7oHe14EOfFhdG28rIIkUjledG/tXQU2dMmjEpjO8IxJhN9shMkpOZDb7jscmvjFynwmOBHnSfbAK0808B6FjW5awNPnqPjPmNcE62mvI4qkpFRYJ4dMbCZYz2RC8zHZhsjjPeH7g1itULZZ8ePc7mvvchIAjFf1RG93Yt+re82nnqcxnKlrsmnrc3dBI4aE3xZLHWSuNFEr7hmAcBSPf6wTEMKOJe5YvBB8pXAmTwx0hF0cqd4zmyma++egmGGU8snvA6UMj6/yekt4HuKikbkATz55jKmx00Yy5woo4rg/uM4G83O3ra1N8dZOzxLvBsIvsSXzhKV20ABgMa4UxH19CM0Xbi77W/aP1Yt05SmSDRkP47QBvX3aGIVMWE3khr0BBOCQxPMACmK28qdc+tfjVCtnSkpAoRSPbJBTbsUzUkezFuNt1C+0AebASLFNhXN8Zpzqx999opzzXcKKkMw2nZhaC2EaS7pG0d1as7IoXelAWXgh7LGw2aoNqwjyTB2WXv8CJJBqDWRN2TOA22SQVpDfgx6XjpEi65j5Ykp9wjicysn4pxmqw1wI9105KTBbJkH3+DSjVXlNDokowtskivkKmlyRg+an9xXKxMXa91F81LQNINRc7dC9+DCotrdcr3qlD5V/InGd1L7671zYsfuktxJIr27o6SAS5XPZplksPXPo/WqgnGwNqo6WEUtn4TUuYVTpAtzop8F7Qm7WrISs4auo8VZ8Dok7aQPHA+bkkCctHAq/JDaTOpJFJmk8fYqflDwfCIGEu5bArAgQXsWrtUBJ6maxpStdU11BvKYOs5GHLBezevsKFzqqe5IvW1rfhKLouRFvtqRpdWaVTfCuclTaM0OqQCMtgAQ5omzkjYp8HkwpQthOODcnrCId0obwic+J6p0rAH7YBPWpskNeaproX0SSegYekcjYRcFYWiTyxZpIsE95ZLLVkwmdT3MEDxMdFoFINSah1IVNnlI7XXNlFuS6tmXBjcKc0dgFSvLEScVs+trLlV529I0IaywmqFJK/FnECHlYKb6NrYcl+HF1KBNJXMIgOHpnlE30aTB5G/JSYB/uThc6h0mVkq9U2flYhUUIXDG72/VIs9pRtshGW5myAVMnBqIv0To6FFMblKZXdyXVRdfia7fU25m/7F9kh4+b5bJej3eUgtpbtCBchuS6+sHHDDL2iCntIDVyp3By853NJqjpNb6OUWXmSLkntbhNIR3ODNVE8RlHFnM7TkMm5jETwItdMepUkVU+dH6oe6ItdZglyqkm/GbiTrXX79AD1jdUf6C6wgYxoY/vwwuCnUZ6A1kR+6pd+1asxmSoBodp6lKwgU/XJJXMkSCck+anodYyBhh5xhtnF8dAYjuCjcze1MAAl2uf1kXyzE/E9o/+7rfw8KG2pBV+0gdPoiaBRD0eUiBVMtF4C2vlA3DWIt1FNROYHaPayIECafoMzPAvqoKe3vKZ4oXBNXsUMLrsZQ8GsT8fPUSIoHnd9DNiKbKXbZY4AtzsWs8AsdE8zu5kILjG/lsKFsgLfOSOGieG+/zQn179rrtENz7KDp1CBRXZ77K+zDMWDHFyVSmWksJNs6mn6cb+3swFDAGcmxUZ5TC6qsWy/WULG+NuguVkR2idnHA72VXGmZi5KVTIHjooTDLnokcmGEM17xE3BqnFQd6Rsuq5FjUTmwNkipdjoMQ5q1mMxw/VRy2iV8ZMvLT4maerGEvPHnluwFmuEqJVUghkwbxW7WZc2YfMmsu6kWfX1rzfaRfiaP3PaxX8Ow9vJVswHX57sbjtCK1YyZDSSGVtajerKp3/Jw9zjuId8lfSzGrGOnvReRvYDnRpDkwqY8swgBLC5JI5/YxYNnBbdzQbWyqnAUpa65u+7BeO/nbSEU0FVlSlXmx1Tw/7lW+2fHes7l8Ih70zYNssr1sCHWh+pgWHcFBAVOyUPfXUhg+CyQCcFFx9rc95bYFpsEZJjf0BMleMYjcMRhin2qbogUoImwaFqp/yhY8yKShucS+QuV53ODpkVrzV0aXGijF2YZUz3wjxbYDlgnKFBDewnR15vjRXO+ZeNxyvl1EmKglTOeFz1VoabtkPOwtYjm9qaTOhtOGFVvVujwmFNFe0tE5midn0MsL52bpY0fFqA+OyoZLtAznypBurVk6ldTDwASDwJ9J/YBp3OnalB3khwqaCr5yCQ2LiFJwVSKV/Bj8v6dL273QiQzRGWqvs9YqGG8fE7r0b/EQtY8tz3RmyAfecHVs2BUiAK4n8ZKFdZU0m79+KF3CY+5k9MdQ7zdtJW33UVWRzeImX1S9zU0isK1CLSiUKUqWg8goPX8Lul9+052D1zxwB+/Ly8Uk0jfR7BUSKCoYLFoOrKw4M9wbigNsBuTdtMLvKerV0H9sNWbS3xUxNY/WDtCAzLZgx+FRhoEdA5WsF3JbZJiCPhTMvVOD2mwXeQaxdB7nN5ACUTSiZq6OeZbj2xPui7B+kEOPj876iczxfVbYtls6ByyKIrqk1/GtrXN3bL3qYAaTKXg32GPTwhx8xMAhSAiVKootCs6gSN1QPZ7zETT8FMSYZ6uxVuiVRwnCVYLwUVuVcVG1mvZZsOtfpP5/i7d+h/SYN9kvwlL0Fq2YfSwD9SdPQlEpwUc1lKQoZDdwocvVY9uNfNWhHaaWjwy2txfSwq8R4KoOqqpmwVf9YKzi7UaclaPVNOZR5bKLsurlCs1pw9pUXAfu/tTfi1Vw2Ws7sBYn/n2L76ukAn72ueWNvLnoTvG5a9spv9s1gtUEgiqL+g1Qwm0Kkmy5cpJBFofT//6qkKqeHi6gRTANzC/rmzpsphZM7SokC47fUyWikHEBN5A8r2Iq4wycbdUaPeVzL8qZEFtbQ7HMdgqICXyYY8M5NOz7l287k2y5IgRPAmYOVZk5vQUoZYjagS5ZTACmRjEwx7KHK568wI2Ecl7h1rDDjAIEPrYQzkSTciWEueF6lOMtPgcOTVkwMPlbk8YD8a3u4oENgYNjVcRzVQjbOz/EEi1gQQG5XHpIaIANFnSRPvvcU+EpNPZsG+xnUvhKKU7jqDk3Qr5ZISNjnBuxj8dIersglSpm2eLgMpfu+EIBYqV1AkpPnZpJJJLrGn8yaRIUVIrGmQPbYP9jHgFaulGxvZGn1hvzeTMj4DxHmoO8bIQdDee2kjMv5vEtMt4NGk+ts25WQZ0VCxtwktRklwtBc0Rx56lDKSXaWkbhRMpfIcmPMENvcKTP9957aB+il260FfHfuth/Iy/D9hcNksILUZN+G7NUJSSuFWJtNyFmteqP5l0Aeq2oBv8sfEKe6boo266tdoQJkV8GZBYgTl/1HAfJerXyjKUACpMAUjEyMVDZFG0VAHq3u2VSB2wX6ZHlUgLxDqwOyAFkJP9WUHvdN0VZ9tutUgKx4ZfGR3cMgLbeuAuR2ndpH6do9mX7YNYPViGEYiPorFnLqoe11oE///2/FkzVmCQurUxBoQuzB58fIUjLiVdpxCOvEL2KunZBppUY+nZA7IC9CipBkf1LpuXgrp6/jJhVss8e1vZYXW2zwbjP192hVCciaQIae5AnbBSgs58Nlfh6tKgFZEEhp9zDrvfbW29FAZvV9fKwGcoAIWCX57X1SoXOhP9TUCciCQAYyixi3Xa2fnfV0S5pLA5lTbibeQI4gDJ/pOyWCuSnYKCIUNJBJ3RyQ9eY+Y0Ug5g7p9DKR3mCeGE/634qksjfIBjIkQCZuissQCC0Xmk8DWSgg65VsiV2Vl1XgSs7cZDeP7TohU/o97lTFhPxn7wxWKgZiKNqfUKjb7rPITkT8/7+S3EMY3GgeKp1ArrSTTrs83EzSqS9Qk/Nlic2fcravSR1K3M+jNgbZEEgyNbDFEScKmyy+dYF7+mz2aWaQHYG0zMVU24QGn27m5G830vkA2cog+wEpxkxn8rVHEAdZHNMMLjFOHyDrenwf5AC56mh6O+6iMo2TFSaOyTBA1vVy3q6rmQ5jZWi0fog8YNQZ/wyXVBBATlFT18d5u65mUh+S1aObe3oiIGb65hk2SPp8UlPX03m7rmY65HrBYLC21osxSRiT6kXqPEA+oPfzfl3NdGB8dL3NPQZXJESxSKBUZPPRYVUb9Hw6Akm1orKaJSKXVDUeo/PSRncHyLJ26Pl0BJKOeJbUys5sp1DFDaYGnxqnyi5qh55PRyAtM3LwBo8yRNUvtMbjOqEdIOs6d9DVTEcYJDwyAp7H9IpQBANkq5KmI5CCbmVlMnWKjblgiqYPWdPtGyG7AunYo5aPywbBkztMaJyU3aykaQgkkIFemiGQ5spReC5op8quaIu3NE2B9OWNapFL7ipnRCE3c87fnkc/aou3NE2BxAEZsEcIlFacz80nDAVtk7Ffr2Y6DH3FMEXnhyhT+wBZ0B5vac6O39SQkpM6BuI1v6JxyJo2aUJ2BBLwvspzJEQDZF27NCHj5zebiZS9bLCg+d8+fTJ2Q4f8jkHn7APkY9piq3hXIK2gf0jZL38MwG8f+L+M/UmsueVIEcNQtPeA8sMPqBkWwAeRQELsf1fQvhwOxioy4iF6aiqxEyeN6sx13M1r28PrOOsc/S+AfP4S+zD+d4G8f+/wgJ+Hyn+Hg/3+VqROXTNjv87P8zmavnPAmeDVyPo7ern+YbhA3i8onPZ9PAot7D8EyK6WXh3N/Ft7nik8zwGW3Lg/n01t13CKKx+pXNfCtY5ebdsza1r7tDJOd1m3gR32fbgZPT0QHQdMnDWnEXpEQCPbpVs9YT5s76TzvOmeuH7qRAGMdF7ZejVY4QCxe/zo2AOkhsF+s/eBrAOLK7/rEHHifquQk8R075da+Xs5kcc+NLXbFzmxwtKjkTaDXXUixNhB7MbGTjL4QPvb4HDCLvTo74M2gi1ymIfYZ8vapn9gqqG3jV2/itrPB/RWpIkhnQmj3QnZSfrmM/ZBzyg6XfvGQPdgYNlkS4PKI+PeD4ePrsG/1E6AMLNOEsFsDF33jIK5Y+Y/oGLm1BLOJXxS5fQ+uHSsxWT5ZcU0CCvr7GoDZCdwsohW6uFR+zSmfuDV1GdoD5+hritQc037UwHxnBO+6x2OmNB8Pe0VUIQe0BSoXIdKZST264LdERYG207OsCRncroEUWxt1MjtTBBsE/Dv6xOqfwm3x1Fx6KKW+qnxQqSmgJ1rFJ1E9WeMwWR3GxhME/6cOZRVy56xSGiaNnQho6QCAz5eVSeXgjbGsYRajMdgd8imCrkmBRIzKLxmpqukQ3tq50IqVyI3tmGy6/a3hlvroYwBtqyYL3jgSotADs3SVOimhl3kyIqy64pyKxJOkw5iD3WIA/020/R864yI8ULSgE2gfpmfDSNQ01bjXKavnpE7WQXHWubQmCMRr9xVupHqRXTrXmF95Zal2Hex/gD/RiFzLY53bvifeP7gWGRo9dpCa+gkdrdkzU0a/SqljXMau24ot5IGTOm5fusxt5M/qRTN92EpNM0Ku/deAyPkYuJVAW3Hp0L0etf/fSYZQAcZF2VzeELviNYaYqjmOcWxoaYG8LMeoG/OkPd5Vkwux5dZuZ6S2GZJcM2EXAAt7Aa8voawiAcOFxOXAeUkxu3BC7i7hiuyrsyANIu3/4r+NY1kSWduF+IIjl0f20r0rc9btrbnjmtFp0QKJWzOcV7cmD2uGI2pA0PGNmE4ZJrLmJUQxPpmZraGwUPvjkzGeBrplmeFlcuD4kjbep03E62suZnckOj1dDpZMBOJ9ybQQieiDydxuJnLlqo4MTX09jVM8CGi0iVf8ipVzLZAnzLZ2dPVVmAAmFBDunWvy2QdxwIoNS/zYIapKp99ZdMuqyiV7IvV/LdnfNBDB+OdhA1iMGgktSmceVO7R0CnqEopHuHq1MsgHnV4rKihaDqoNuPD8N2KdDrhp+7BD4fwCFjLyFCrpmYJPHER4kiCW02f4AWEMmRPRSwKdzpIm+WHjkU/vZQoJunGXzLx3p3dcmoUhXttI28WK7RmZ1WSsfLceTKNSjuKoCMCOCAIqvLnhJmXG9oi2HjGlQZN1QXBoqU4ziOAkxFMdnaJzv6rpltWNoevpO0YI63OUGs9eKYXowklhO1iJ+JXltjIUdHRapxtSi2z62sIla1RcQfXNTFOn1n8RazHVQrJ4TD4YXqqTL+sGvKp+dDgCrDSQIwU4dboNUPrEtkwNVvTbdorP1jy4sYsDbJSW1e8TcmbRNIa5j/586gtLF2aLGZMsxM3yxsGqpsL/9U35zAiA+mRdUm01r8xqDPoZiDxEJrWfIyOJmxtWF9pdvXYguXrnVUnq6eoAUTkEfbaZ+P3YrK6Lyx3QePlQNTnxmx/gQxKRYWFtFzGMBtxaczqcs3pgkTLb7FmXRN4MMXhisSB8xsUSzC/QSSdmK1qATdANXknilbzNaa6yk51/xA6xABA0gUchU1EOVAmfAVAzpG+pBPQALimwV2sbaijHg5qiRvM2YBflDJNLjh9UY+FnysRVOQEAIKZKFPm7QEdPpZlH9GQlNzlvOdr5goiE5XHRrZS2KlDocXVv4SFolkLA1h5PQKKEePMRwD9wSZSidWjEvM34cluRRYfUKBhcSxYkK8kUOvl7YhAbfWPNWp5ogjYQTGYgnfNakdWwLw1gYTFauPAlbFcT8oONEhfgIuLVwNHhJnPnWiumqKNByCkC+iwLMDlmxQ+sM+YeMpbrPFn5AIibK5/peTR6zkVn2optBLWsjXSKalgqGb2KbGXKAYSi9sCCs307vxAuzeOGlH41Fqp5CPOEGxBDpTFsVCT51P8rJpbZ8jSQbDzKIlEppOR+N+NDxfNcZ7cpA5UYMkJtMIwDoM8aBnTBHiDsD1D9o+U5FyUuBqdLNCrKBYE/1hNcz8rbeZVJQ4WM4xDPAWTucQJORNZqW52DQovAaEU6fHagMkJ7uGuzhLRAFYx4kMmzm+RVnG8gjEpGilEjdv6yOzOOTLz9sp32SZjcnZe8Ed549SRnmPLC3xlqJU4+BQtpAof3pjwp0zKhpSqr8oVyLkcXt6wjcSmaTXTzP5NmhPD8m+/00TqbWwBFzKmrtUAFybxdFRbZZFhT6UUQZuCuspsVK6gTB3zs3CaR0mtkFlu/Mgiw7UsOZz8X8RvWEUN92qng4r0kymBjPrlFwegWveApGd9U7QmsHpCFAwcjIsw3BFOjKy05DyKfN8I4cIiZmIo4aq6+CrqQsuGSrP/PsFecmHxDDfdlxf8tbKF6SitAbZKpLj2I2q0DEVaG/7a0XH1TLypf/EtlHBDVTXCap0D3UF91ZWIaGBkktzNcbUGqclv7ROdGPnFAY5RzCinRy2zoSqjxGDzLGVGoeTqKVVc5rcysqUoGiWsxOqGIXfPr1AaC8rGqtW+n+arfgEkLpAmOcHGgXQVVeLlGjLVRRbIuJeAlxmFIqmWSJKkETNECso8F0bhYkdQv5qFaVZjIFRDKghzPogqBk8SN3yS1XdxC5Ak69yAUjiDIUVNkHyhIPgdiK8YHvfFlGnGi6Iq2GtzFunAq3oy1BBSG5VV0VIaxZXV3QHytCS/yXBG80U2oAEgECKAOFuSdqBawYxHf0xHYldrTc9WAQsIyaxvtsTEB7RMC4Z7yU/y/obFJOjdymR0ryBOcGoVVkEaH5ZRdJLyV76pAbr8wGK8vdQOkU/9s+N2wJOGjqA1Ar4pQYonfjYyQILNlmyLW+oAKsFte1ygRaTJG5utQVMGZz33hZ2zyc0iBoJo7oBYsAIpcIBsRvyI+18L0qXHo9QaLNiQRRoY2922A8qj2u354KtHQi930lXkxkQJ8hRGkKwMr9dCaRytkAprzo2XNcW8pvsdv4jVQMpZMcfFOFE9au5psoSPOkpx6hwoZpO0nBfxZsS2ov2skHA3BIqn7hiDgfIjegES0KNg0hMzAmpVGjgoVNijlAqfS9xMjVOdeYChk90ZbWWC9b70VrGlnLJJQf4oKqTWsU7JliTxMlTplETxlcomFvAJ8lUDETDO9z0NYjb4XeMTUk55nPnYJBnY6sakHogDVFQ4zPoh8qsuNLM+7PIT/B9CYHgDRFQRLClpLL4VRb8/0xRV+0M3DOsoCZmghJMtfOJxK/iw/gF1Jsg8uKntlXSrhC7hrN+eOpvGPccpXWgjymgtrL7pjjHwflGlVQyJ4kFsdebnSF4kLYDAmWiF1STuCOgMmRV/UCF1z+JZqPya2jMeG+qDnfeOAJ7+PLicHEYfgIzG2gVQQ2SiYOqxTp1Q3JpIyw0d8dRz3/CYEdUn4iKjxy8CZa6ofvVKRUEShEtI5ZJGrHG+R6lg0Nfa+PHCrYUNS5u9RpW4yDtjNmVhimyud5Q4vvmhiASaBpWLhuYqJydCsEFtvXakzkkwlTyJXWNrYL5AON1ZMO0DlI1VhYNqqpAS+2a9rDPHigDUwhQBIg6IuxdR+WUTRber6N6zJbf5TVtnBzegL7ai2Rz2QTj23Sy8z4S0hCSLLmAZcKc9A4/ssjDuSZLDAPpzTWuBHAgCivna7OrVtq92JkCuxclFZyYOwClirNwDOTUO1U2WqZUPdU7k4EjT5U6cM3ijUNCa3qRJEzBo7CMiVGmOzKqls0JfN9Q+TM6uJKxXyoyl7bMiXalVzfV8VeaWuGFV4SSqQsodAlpeTwTqY4cllhLiCgTUJ7AHmnEoaFWmWMq4hDTN9WIEFN4yO8qXhsImhbZcAmLmR2hJ2a2TPLwcd04eHzlwAVmnTfVQigggpftb23W1NOitBKxaCZJ4LZUjoqfGla/9GgbjScufl5ii+ghlQkKpojTisKlXhBDVoidt42ehlC4J5rZQOZIE/t8Kpgwa+SlcGcEqadliJ/k+QbI66umtee5CE4RkbjTJ3aPIUUhwa6OswRzwrmZpoPT5rSyeNgPKYqmUS+4UUyIKXQR4XdVI4Nbzxf76XBFj1srfTg5vRVGBlBFHzAJDPLJYY2bj4lwqr5ZBOH3tPCYTpHKlaUJV7QYwPq+IWo6LXD1Bb95J5qOcfCFkML4xBXvy/TjYBIWkzE4fJOnq9YO83/oQlga+1mUkZgCno2IwYx3eyrjJInjRJjKaeiaM7rO+uvu3+op/pwP46MIk3TazssNGTncfIwk28nvjKjZgYZSJLD2dX68MEa1k2dQ6pO70LyqZKV4urtCHqGIW9rJk/FZCP6NAmao+ZVOcFDXDmeQ52Fl8+m+aRXMwXd2r8qYpXKoiYblddVfuizojzVtsXyatRI5fwoy4lmV9tKCXIrvkUOsypZHF8PZ7Gv3ApvmZcdYQ4DBo3eItCx+2IaOSdYcQP/cTTLnQAemZOd7ZllVBleo73FNL20GmLzqBFdYvgFQBRZL8rFSK6cclYDyCRLFmrBDS4ZhoP7pgZ760urwDlbuLqy2GPMTfEr5+g1vPPTp/l538SHfpJAHg1Lwt17Zump4L4jq0hp6Apg2eqpfa6evlYdAQJINsgry7WafL6wLi7Hf1NuzqXK+knt0PoBYcGXUSt+NgV8R4uqKoZ/UYN5UL5zvyZXsr8s7RcrMjtRRlLs3cyb4SgfbV22rhERd5wQ1HLW48jWoz5GHVvZEm2eaHSsXoAhCuwT0hJmMDX/1bMOAcnIbjyCTaGdYnSITPurHq0S9n3YW2UmUXbrTt7khpxs7aitGmdadRJzbKdHeRLSVGdNrpbhG5SNOzlt67uiZ7LCZ4lBkQoyWImqiuZ89bXyV4BROVyuqFgsIUnYgUEiNVJzx9JsVFPCDiH5cjJim4hILpNawKpJnbkal7ub+tUqZkLbF7a02jcf0uxPXcZOqDGnf/YKj2LdwCXv63XUbfW6uhJmd9te64F+8ZCC/sTZoFjvASQL2DlDY+kDO/Ql7RM7p3BXOeuUgX9kjrdRHloDrE+reA+JV1BB5UP9nLo40A7ZNQHK2Z2kXD4VCHLYVV2bSi8jaJL8r1l1jvCautg8et0LXbUL+uWe5y/Z0FIYz3dlYhRLhJTLzepJiH6wndbCGNWL9c7MjF1xHwVPS5Gn8QNV4OhkuYvFXQrUP2tPZvLmvFIXNuSJ3atmHaO0nz0Q6HAsPvb8hR/WiP6RxMGRw2ZSTLAkkHQ/RQRQ+a8KiaUl47//JlTlhiBkhLHwgTzWp2dYl7o5Bng1nFUgm6NWPidOJIk5q2lcHvw9vd1VO57rnm6cBH6fX3U4628j4p6G3wPtw5e+PoiVKpohypSTQsr9qmNrUPywhrRUb7Jv27r8ybzOfaR8ZO5U3PeXMA8WCn05nNeZ1jq+CtpdsMngN7uJVdIP8900KsK23PuxswJU7rmY2zo0gK6CNX50ysKeRtRhQ3BDuCU25T6BNgRe7JqbR8U8PT8a08xj5u8Ss758NT/AxBB5Xe85bn+JbPs309IONAE7gjwU48T/idM1gkMYYD4sOJlPQ5UtYuASfha2qihC7gL9fYUZB9dWjBoq3hDh6Tte3ZOjWeJ79M+3QG5SyPZ46deJ/0QQgDN22r3sUPhy7VrGvcQrgI2Hcfu7awmg4p+1/spVLxH+3xw0uxL2bQQkOrHAtQ22TJBx2j28FoL9ei1L1WIJ/SnM1D5KuVPV9DvhT70m9T5sFTDWxi8EmdHKllTtx2fV4UalsiL78m3qWQRzyNP71KJIa9+/BC7J08FleaQ/mjuegXjd3SKffnPy28bNvc7++ufYTxNWff2IeXYu+e2cAkjNQsnzKYnvNArKghyFq8XV5/Bsvattl12J2HTduT/a2UeJ9ec/YP9s0gR4oYhqJcggVsQCgX8KbkFgLufyuIP+kn6yuwzSJWTyWxk5mR5uk7Tmrcvnw9xV6wtpp/G3G4dBlkWoMwRS45GFYfknKyrjGaTTc//F8N3Rfr4OfaoUAigw6Q6EA4AXcvYm5JYLMpwA+FaRNSPoB06MozjEi54tbZe/vx9RR7g0eWrUaKlZ1P10f6HWp9MIM0vZInulkBsTr2CUvWtJCIjXiHb84+FEgXOOfM6ULwiJu7mO61uGPWF2zC5qfK/n/WDkYF6M3ZGPbr6yFWqfCBAE+qMMEdjBdAT35MaawGzaATY+CM+86RMD0UUm3QkTEYA0eNb85uNm8Oz7BPhlwqH7po0gVHDd0E+V5vMWqixLWRTOI5Ax8G28M3jTG86iZ5Q2t8/3wN+3NzeIZ9ev/9Ewz3e8XEWe40UBmik5xliz5oW00ai9Z6mf2hYceDNsRpBPPi5uyjgexauCyBqisTVCbANQ6bK6EO5Ji0p//h10rbTVSzgBwtaQNni6wO4N46u9kxV9mfwK40Ei5qnAktDhQuIrQQ+HRWE9Jrjtnu8If16y5b4C38kMdRTwwQg/7N2dgxV9n6g2Np9P1XzdwMNZNSWG3E/1dD2bZyDtlwjDHbESMCIheeDMaYvSuRxwE5BRKFhJ5Wu/j2EWxRPIPHV/skC7pjEWvr7WC8KBwSyJByyq2uRrTjAnkkkA1HOxJMD+UGj12S9bGYnhxndvh4coPoFY4DifgN9o7F4Zh0VndNKvEc9x20I4H0FNrwpJclg2IJYjZMUoMsX4sShjv8rot8F0UAklrmD3egyIn4hI9SJwJs5+OWNW875O2zTwCwmuxcZAs3LuCojFEyeCAd6eXsBoM+Iv0H+1BADpRPJI4h8qKeCiuL92PJW9acB+Sri07aMQ+RbUpO7/vrZn6CRAzRFeMASQ/rQEYINmG39pCDKmYyWD6l7fmRP+47aAcCCSWTjnzeaDxWtVTU9C5xGZzMNK+TvMvZ69vsgRR77B0jxsRtjBjvlF3BAFNNi7g5+ywgXx/NNmImYBjCEH7f6HX/tuDO5jXUHVuA1PENOK7RglS9iDG9Ief8Kmb/NFci/9oZL4y/QIWrbCB5moYRSSZmooEsTEMUp2P6tJXr4YjnGj65gIyZnscEL+rUpxrus9lQjjqfFIRqpzvu9eFZQCJacOM++okHKvr7P65+q7MW57q52Ux8ep+oz/wwijjp4qqjYzl06FOQrqcC5a26/NbZRwH5sv+HycdBTFXUy53OKTMz+67SMzgSCHqINKtMslnNr/mh5E/sjdmEmkUgObpoFLshn2Q1rkQeBOTmYvB//yANlZlpE1JRjDjwufahuRj4wi0mIJWoBeLgDlvPKLWsUGXseuqkaOnmva05B8gXbG1O/NLhWP1sWukIEuwT8DrKhj/TusYCZBE5iYv6SAejPkMwUl1LESOKz1iV98/P1w4B0nAxCkiOPndvts5wJdIb6TNMJ1P78SRVtjRwwlVcirr4tnaPmiALauzpF8P3Qvs3O2e06roNRNH8w4FA+mIo/YE+qBAC+f/PajXbq4swNWpu2+RAo5vY0kiWU7y6Z0byvSnfYdnnIY/JQXZMamnjZzHTv9RV3bp6Z2Z9tATfmbVgOmV3MK44XjtuO9syxdvsD4YsUE4RJYL8vPLzfYC8kIfgt4NKo8yWoGqXOY42uqPt3LcbWXNJtEPvwvgvyOOvwlhHI8eoZ8QyezWFZHo/EvldgIzsNRQkSd8raw0bSwOQpUoPNZ9TM4MxaddFPmXISK85/Vw4VthY0gd2iSFLPYvA2SrZLIJZhwyWn/3D7wHkBak69Lk21bwuehawATmrGvolwCqDPRnqDRbGS/7iqINj3DaKmN4kMXUoNS2Cg+y86LPy80d5/+tn/RmjZ2qiLY/SYiB4sO7IABco+x2xO9pRVnr1N7Psn1HGPY0u4iKAxWaoje9Od9R0V83P4vi3APLS0tt6zCikR31pL14tlZppwxsYaZHGziHHXpzklPQkkhdPXOwlnGRXsUAlt6lPFoZSPhva3wPItlK9LnpWW+pqK0B6POA3yTzeBDfM9CyQUx7RxICZVfL6VgelAEzeg6/eq5+/fvgNgLzwpDkv40PHds+rw23R58HVoKzGlkmLFce1X3qaYheqCja+UyULvcIvGrrDOhHO6AI5tq8Pke/+a7BdczqXlsYVTIlcv6BnLhrl0nr/GzR9vKjXmFNWcqYoBq7KnYtHgGOFB3msgWETcj9/26vKW/+hgMsqLiRJbuEgBmhavHabT8NW7BwoZ5qwOH4af9NlRwgLskIzJBog0mCRPOPSlZXyCexHIt8N5OGGX57/kSQtM41uJTXqQxq4PVhd3ekUxgSQlAZGJ66zHjLz2UUxfXX+SOQs7/zHpi4diVYDRAGBnENfLNWMp89ZqlMzE/wm/GK33EE8Ja2eZY8RC0SkMCSmGUdOL9Xdp3/WIn967z/Hd6Q/MOHb4ZE3Kkdena+DVER63WtpmZGJzQJBCr/opDiik+Q3pYOaH1fJvSaGz1toP731Hyy9ulzd/ST0rRcEHbM0aOKeLWc/HN/tKqRYlUZGCFFFEm6HiCtf0PxI5BuBvPSHTnW1Y2c2c6xl3YlrlMoD1FVVj61XIHktN6s3wQsYY6VN1ZRbD/6JImd53z96f+FRw9ZyHXy1+Nix7dJrfYE+lV7arCdBY+Fb5GTxcQA+25J19Z/+5+V9QPYne7i4YxzZaVj7bK9VGQ8uOhbtPpPdJ7Jpik66QZc0hwoH6Py8qPuGV8a7x14VspOFK6bnOHZccNi64d+41nY1s6J0kkZdtDYh1VJDrDv6I5Hvev/s4WE3MDzy5JvkdcWUlc4fH61roVVMncOm1hNUiRbFqm679ZiPfyTybZvZ18YEAiQ/Kzfs+ZC1wxd+O82d6hWjJjWLYoi4Lv/7v8zwns3sy7Ei5ahRe/PH69Sjs7titjea1Z8DkP9i+d+/hvaevcPr49pLZ0AP23u4hCE0sLfhh7l3l70nE2yBXGKWbzM227/utAeVZdl+fLqtDfix8qa9w8tSsSRRXoXJLpucOqwWUT6KFbT1G3k2wgXIJY5+1+XxIQ+bT6MyBGZ9/RPgbgdIju1J4L2S1ltWxhcv3B4A8OP7NOpfE91Fh1e2LlAVyM7bGlSv0nIePDxZwkJlHEnV9gxZo6ajOvZ6rHR01MeSNI29d/SqI98D5GWR4bbSCOFwjGPPYq7W12R7XiT0APklT7rjhbuuMQ8d97T+SpGApT9e+rrmHKsa9EHd8059DPBnbifcanq1nSOXUcm1qVDesTKeB7l4sduWaGmBrmNqqHUs9dHrIt3HMJ/kzVqXvq/7NKQaDOsYcO8tr4GaBTOj+WROHhW5QVNBxdDpVDzBBytszZtmhtF/4IBObzrGA72z1ZTyDQuRC3d7lZrjUVeZPiTMLtXM8+F2uFxzpJFDWzA/SVgx9jXbHVE002M+OSOQmegMAohdtfhSRnBQNTefrzb5wNXDKLcQENULlDfduvOo1pi2zeampHdGHfVo5+5vWIi8NFf7iMH1mC0HypmmBwvGNBewrt219T7DCa6Qv5wNEItSQYRc7OE5ODJNUBvhZOjWoEzPPaREldRdqp1DJGLmrH4OPXkLSNNF1Rt4vVfJXKBnfn/+aMnQ+xYij9QMO6D88xe7O0vrvSHV8/ooi5z64FPh1UpseGWttux+gDUSOcpThpIAoFbFaNkkqqpB4nEUoic8MLfZGFNB01Yxh/eQy9Ece/jbuy3OO2rMmA2wlVvHvnghUoFka1CgeqR4TS1sgOI1Z+yLVcOF9UD11rxbTuEMLJFHiNRTC50j6buXSTZRsxEwI5Fj4hNU4EhZAiG5MXybjlfKBoEdwKedln5bRlryDtpIMz9HVy34U83HwKTETusYuUL0X//O+GO82KC4HiURVB21hm2tt4u+1TUCifSFzVB20y/nXIPyJxXpvctjzqNz8XCI0mzbTqySNdo11goDOB3BvbRqUoMIekGP+mR6G5kLwArl2DAq5oL/GAojtm9Ms598sfu6AEc+n2fNu7Rs52BWAtz2ckWy5EBWJU1wKwXEUd9isE8Jvc9r7uk6l6wVJ1MYgcAsY2yEfQUUvjFaJs4jphzCQ+YkDzauq658CRJyN5xtWvHfc+YtWU/GKMgjqRO/JXfnzlYHYW3utQXr7bVAXnTOnq9/x4d2+4KfxW70E1K4GH+aYBVWt7bKWKLooeyt4N/VzhBZTncoUFGf+gOVhRYQbvrMkayF8fW08YshO9gUmMzcNoWohRYCU9fNMbIqCcq4+Q3ssBqj7lTmf7ZMVMcXp9mXv3S/oETnWvEAcInpuvQ9cH4Shg6y8YVABrhQFbBQRePDcDfXI+86bSpGopHZs16PZMBlvzzviGTMA9Z2eIPhyPiyJ5uIFZDprTP6aqlB5je5dxTWBHn+Qa3n0BwsAZ9ok+7MFN3PzyO/eSmQb3uxuzt5a/3OdLU79q5k2dPdonC7W77JaCFHTgN3IHovgxqZ2iRyRHiCUqQlDJnR7n4uVOB5ZzcF/NDVLao0gmMBUTYYIaz8yTSqYGMQEQPZPJmUmjc/Ciq8bxVkpsucK3ECKc7+W174esU1z3JRHLBOXBpJCfJkXIJWC+cLx90ZT4ukBpBCG9jBXWwsNoZAhzg86pjq/VwPqkhE2kgftlinGa+7P+w0iDmDF6kO3j1dZtdJUPDHIbHv9ZHSsDTKvRmka95IuXMYkXQUkkF8t6Ke7u2Fu9mX5icbfwtJPN64WaZJy2IaZTkOEa6aTw+xoIoYuG5uGN7pQi+/bl93sYXOsDp7toFTjUDx8KJMsbvuogMEp+ggq0Xs9OlY4RWdK1tZwxvcIn9Fa9RPRQuGQ7oIGOp+sIh+cxeoJzAYNUf9ntdlNXmMK4n88Re7r42sNu06SXLICkzKCYEURMCKoT53RkUhBVNV1EIKtCe0xZRpNf4PL6z/3ExS8I8ZHhWElIlAQMNYlhoTkmiSbKRsOOykw+AUS40mWS7GWADNoXDO5ME6Pzmqmdytxr5uN3vxeOVl7dFtLF7sPupev8WxTtwFUo27F0jz6GrPjt9Nt3wvLOW4vqxb5hA9PQ+ShRDgmg48jWGwxxMNlxvo5EmXhRclWKMhkAxROOMEotjdf8wKlEzPr7cntCR4qLZLTgQZ+a8hJs2Kj2K8zfKirOayeNfsuky1veS5BLuLKJGmxZeBFlTquU1qvlDFWzy2wojcBbIbwNHjKQSXf2fQxHpuIUYcid/CWxKT4EYQVvFfHeEtCFvbdq5JfQMggaQbf0WVAWpYzcdl7EGqFenccOR1b8BkKbPSrmCcT3ozK7tMRAYvyGoMIAVCBLoIYly5UcYdu3aF0mZfceJsv62ukznynQp5C1AgmBIzPXfz50c/jSln9m2q3L9ubMkFHwSNnDc29gUHjnPSUgXVCX+7WXFDd6OkZWcdfTYCVqouLyK0aUc3SYnC7jyEzQ1h3kURrDOqpDhTKrzbqzYP24PHsHyxu1/SqemSdnwXLItEaK25KCQoAhVhooDimEWPTne5aQdu0pzzMFMoJUqgp96Emfg8fOQcGIQLjSCXxuyLHArBMKBDW6vGtQzdVxoRaW4w0izBJHvPTQaQmeOMHMx8Mmm1mPolWc1FLrr8uCLdXOITBcldZ86Gq/Q6QuVcv7EZ8+lPuG5Vu1cAGGOdbuomgHJyQ9tFoOTe7EWeyRVGXF81QybPMgThANmZmUMMzMY+SUVtdY5WunFY5nCflCklXLn5WKeY64M254Lo4n5r1iKDq+95VA/5jPkQK/AvyGrC44HHfZq/PrZP/GNM9zl6QNDnPZmWhLFC8lbGMuipDTDdX0Qs+eKtcfrncAJX6llojIzRiRhF91IlWIue6oCrCXAElkSJm8uYgYkp4mvzjRYzMTlNMAz9sLsBcmGcX8lmknviUfqX7NWoPIsl79bTobhyPnbnnHPJes3b1lqhlVxd9tet0miwg7Ck2Sw/PsaVN0aZ7NDGled026CP1b4oE6CVITCwnxO/vtMElYVHBBJxw/mCdvUGssHiNpvXBaYS+GfiE70LuyGuRtQocnUTHCQx2DMowozobtt/H0SS3HL0oPdcyBmICeXBuHzXr2E8v1mkwUFm2fpjqoFNJ114pYtmsOVKql5fp803DuuRBzygcw+QdXEY5FVKeGNFG5/qa7IsHuo2ES/gzKVVQ92COTs03DifbOUg225ZIoKzVSbDyWlJ+e+Xxi8r0fGln97xZLnqrzHQPgJv0dF3umkQQ1aJQqZGAlN/5Mt05qZ7xqhFwOPbz7+Td4a5rtNAGO0eEJXSv7CFJ2FFwP53Bc3H0dEwCkPKrYT6zCOxx2On6J73zYzTKyJwaInVwmGFyCc/8QsO6YfZ8BWZPDzDA4kAZ9OcKB0QZ4TUWUY9L9Dp6ScMkhxmI2jOVvmcvEMCSequfLLkGW9OIrcii97OmVierIz8SMdM8OLiaA7jtdtX3crrQvTuKG0Uzt9EjlInyDLmYCgWJDVb3ykQnkCFNTIz8rC/IKHKAJvjCiV0/pxTMjkCDBWkmCSgAJ/GAMWj2Hp6BTZyRYWbvyJU7ma5lNbphOzE+3cfjTdtuV61aBU8vfRosOPXquQ1x+vhOz/kB7dSkxigoYuqu2gi/vEg0D/7BdLM/YCoBcsnnSmgI3iQE59oI2EcYUK4iL68MUlREcyDdKjkDXSIC96pj0ESUZYotRF5RGhDZT7NQxZ5xZ5qX7dv7z0a/7fknZ+Tn+qTZDDQt23XwcTQcXWf/ryukLXVN4bE6OMSo+eQth1vkGQc21/QwF44DBhUxqaTCNzRkExaYE5LHaGr3GYJQR/2gnrWHyP/jZ5mPR0qcur+bMV/SdDMgnx2eHy89yRSKuajPhnp/r94t9JloCC2yGzPJrs6dyhtOp29y4Y86usghmLaBJEl1fqE2bEu3wiDVM4IUCpcXjRzDC0S8YgSwU0m4pIRaEQjo5dZiZhmkEeYjT4vBuJM89eBhYfVcI9Akktkll8Fyvw7k8hNAuiMgimtInct0PcvRHZDt0K6ukuHqXQqqDcUbi+lCXWOtkybblqFW12HR1Hldj9kMfGWFBHqIJBDHcOroBzwongAa71tXKeUp3ThKCYBl+P14H/co7PSxsk5x07HPC625J3ZxiobYX3fL2dbnrSid/haTVem5bxTeHdUxjbX9TXwI8I9ZPcQjOE4/tZGucMoHiC57zAZXnOP1t6toEPUwWcG36DvmAl2KCqvluOcfgQwXTiipjHS+9oRhWQPxJJusMxa6xg449vsviDiY1BMmeByrPmmL+mij+eJ4Wz3ixhdOxu2owrPDtcX3g5lBDzpAqnDxFDjXkSwQpsdnXwulxXgeAANJs90HmKASB4ChyqJDgTFGMxUXAkVOf4++HHYjREnkFBrI5QHctJGKnY5f1cSuXXavPfC2+PyAYSGXx2MKeQK2OsXVe91Zm9gKFLeNJohNhLbyrKUfpTQ4EZEtjp+NnrwFSQdWwczAKySIbqWBV7TwpL1CJ6UQ5RXSRLU6jRSX2h8OsU5KL/n4Ge78LsATfy6CkrsTI6wu0rv6+jpPFfZSQRz8UCH+JvhXpAjjmuQYe2JaKaEj4zzxk8KEpNRLiua2LE9LbIHQHIrr4EG/rMYt5iknDMdY/iD7ZXzrFZtHXpk9J6DH5K9MTjLJMZizhS7ae1ka5krp27SJsbztjdULpztVCfHAc6efmadoVX1DKvsAZ6+/eHnh+oZakXFahhwH1CXFC4ceoSJo3kcZrjMU8qDKKghTyNl1eGYLqc/UO5BuH91ePvNs96SRG5T0XLe1hR2tdq1X6W1I7l6gGeZ5vl95lIhJagxV8529p2MsvvSs0DCjTEY8gc8DNd4YDBQwiqhGTccGXpYyKwyhhNda6cQZVgHMBfBNUPrevWTnPI9SeQ2/i6Arad4V/DtwE0PWpinnYaMI0AiaAbfKm5QlUpmx18n3aplF9NKpLr2UNkMt4RlEBMsihbDpk14dAN7dgJv7MGHRm0FaY9QqIc5hOVQPRGCzp/epI/z7wKoaXPYVcvWTPjg0X61wSxzTjPsqZBV0lrxnGkmRNLxXqwkonrs+8/3R5NIBx7hcH8gXkDiIu803kxLNs4P++5RLFUPAV4LA3oFQvLOss3v7+Vx/s0uil64vXqueF1Ir+9VhVsg5dEaJExJKL2dHk13N8He210cjLFWAwZAG2h4r7JZuQZe3Psmj5Lv6eK2yurD+l/EoR9fTFyy4C08rhONcrRg8FQLhaRr1Mz72NZLkyq6QJ5gdnlSfbVJ8v2bR8+WvpDlkRBfZoglPUGGQkEpIdqv97rEl5UHaKowgPG0kpjSaqFVjTYPPr86Zm/z7wLMTSRfl8TV3fu4f0PIJHNuHUhDstFYY/HwZEjLfk7wjkZCUYmDhR/rHC1NK13dN3TCjJCqWPpx7xhqs8chZXHSwNHTl8fsjfdtc/XSg6JfsR2+7uAO2s5JXUNt3tEcIE/t1IHcTQHPuepfDM8EU21Pfe4FFsImJCCePeT29yXdjAWYRSXXtqZG/3r00/nMZHteHQPom8977Gp4qYmc996fTjyvYug7zK6QChx3KCvmBmJv+vWuw3vTQaWvtcZjZzWalwsAooG6MQeX9QUNykem0BYLOd7dA2Bj+/Ht8bojuqpRe1e89VUFzFJY51JaSjXTF0jpsoveyZTmjiOWPuprJfJRtKm1Rp4ktPoYeevr1S63sHzCTWfvjbV+QMDu8u7996/lcdYpxy7ooK2usw4GBZ1Y6m1y9vN4RnTr+GDoovizrDI5tJ2IXmptZEm961pm86jyVDYtsqVJbpiJlZGzDjzBcbalqj6wO9neGa9nKZrd12ibt5kfMKj7paJm99rq5evttxa1bcLSzG0IWy7sMMxhX7Js3WBS0PvsYiJA8U6d/dU88uf6y0PX204Fz5FTc9Y4P/sX+sNp+W0HlJ/lTBnsbeJxnwwQ+a0FS7vVfgpm9/JkiNDct7hI8PBZ1NOaF3/J++yXSRDT6+uXK+2siU96kwZPxtvA1MTernNPNd2rEylYXaWYGiERagetOuYywjjoLU8YEKZtX8KjaJwfuax+3sMd0Zt/XZrrxfgrqRq7j0I5rhJIJPLVtp/2u/S2qH2idS3b68A4oWHQOTunIdo8VLgnqOv0F/xPvbbh4HlKGrvF3ZqUnTuvV94+rpcie4Dce0mD8bcz6q6waynkwkZkZ6aOOkNVD+uSmZxHrVvoXkBvcv71S3m83lYD7WQI6hguHkCua8X1Gk7Ib9IyMwWjc7o4N88j558t75ZPnXlPo7OTlyCD0iF/5B3l2bZfcRQJK+9vHar3736SUwxVttednrZy3/vySUzvlKcXeJnchrg9KOgAoDKq4WT5F7w+3NbXETWH5jWkitc3f/Xv0214z/J6Ajk7Py7TRm43eo7rZ5pnp8n0X3gsPAy/C3CJG/60ZUPp46pzDOej0Lkkv107hJwp6+Zzh4c/yP97u/gJ/2tZ019kcNXQK5URgKFuGVZdPFO/4iXxtwsKuA/IzcT2RPKT28tlzfZChF69M59tF+7PiumZ3mLYvM+ljl4q5H6VxCuyWWa/OyJfLGuajpwkgJsuxbRNwPRp57qMZYFkc+G6XLy25SLawqCtNSZnhZylc2zfL5GvlTXbxk+I29QGz5XZ5Xg5l3Vrhnp6oL9QlpltElQeXne8vUCWyjl7eTsvtj+3ba/wiMSccocMbVLLfWCz+OjUfdy9g+0cJG9A5rZuZHe5h1YuU1EzQEgsnlfNcx9M5AtlDbnV37hZ6bSYnemtIsTdvnZwhhCaj9u2AzGHRdc0MPbJftTDAql6NMYZDkC+Hr/3mb/9eyLytXC9YIyfpH3bpjwGEphcBwiM8Fv4e+0cwhpcgWZDVxl3aPTvzuy8rRO57jnkbsc73Q7RpJNc9n+usj89kbz4JTTlxCi8WrisbTlXrx3hQqD7LVadgI+/5n5+40YtA6bjOn2WiLZXh9AxN2na6U3M7adpwGcnktdOfjaPQtA+uYhuyiBtEbWBF3SwuwmzK77hnunnONoKgky5V4iLnkZ768aoZsUOBXXSZ5p7xnb962dCNMgn08NeHx62L5z8JPFKAva8bSgl4DlYdHHdVgSKo5gWCoGFHgAxESLWE+8tWLtUgbS3OP4BYbOLlF2bS5Rg2yarWzHcLn0B8oKHzM5uHxy2lciRRxHIDSzWVuFcp9Wvi8pA0Dek0ZpJ9SvSbBqKGOJ7GGKWegR2sXbhm03sqfR1D557k4t9itnCczY34/rdhW0kcuSx4sG/tS5YkSZkZ0OmQgj+GS4Uai3KHneXD0t0LyFOjgJs9mU28b0GZd3XSl+XeiHFoONfjtvEFMB0gMaCW7dZY/dPFUkkcsTRElU59MdmMI+wRLRq7AMR1c0lzAOIu3ONYxCOMLuV+egxB44bm4Eqn0/BW8+Z0vxEmdzIEGK/za+oZym8e7vvo8TW9funv7bZ/iWPKxe6MMABzEYvc1Gg5z2QeOKHxskGcmVEZiDh6QKpPq6ie/jnqQuILXqQT/YhHeAJ7awURxgWSLGAmPul74u7/N589kahBnOF/SPD9u8zj5Uj6LHqgAypQeMM0tyhMNAanzflNhwDeS2OF8441IdJm74ZL2uetWptL/w9xC92TFFlDjmhdud+7z5Y9BvE1d0auR8oklMWiVKIQZhIWwqLP9nyApExlYYRP6EVZnVRwmJNY2d02pQR2grym6vNLNnC3VhGwqATc1lHwXabv5YjNwI1Iieruza18Bzp+///u5GX2iiRiGFRIm41hi6gxR9Ewt2igAUlUQSiIK40rQgdM5TIWUqJj1gCTSYjkCUX5VlpDA/XsqN0Z4Qz55A1mDqSr25yoEG7UdvaHWmVPzJOBp+aSf6TRAoLP8FVT7iVOFzirECZr/EPEqhv+0YEnIlCXQhTi6fwydzGD8CfVfV9W3EuGsrzLNUOPxxRyOH1ygDofap5lMt9quT3zzsl/4Obc9mRnAiiqBFseEgsRliiNo00wyf0wpNq8f9/xePq6OgqZKyCbpiuHKacGfmwq3zqRkS6hpeLzcfcHl5yt1DHaBi3WYcbWNDWo4VKzxobL/DbIMMaqymvdGl0F/xAChVHJb2ihhycTSgr2BkfF7AVDlfud9e+LztVPGfs17uZM5160IfbSuT01nUrUyn6UvemscmIF7VkBX4RJnaoYGUmWNjhAVap59ki2zcUVmKobAkkw4rqlkeIp3D67TQ5iTPeV+x7moSCQxW1Mm6d472ILFHiGvV4SL6cPLkmVoM9brvZQmNipp2gLOWgd3hfhih4Os8jy9gNU1RDmsJYV3ZkgbRx9YwobYw1zpsLiJHTiOd8lr1OW0tKK+Xe51Y4xqbM5Ia5NF3UEz1YcqNEWo6fE9OHCSP/APcXKwwAV7dtev+5ElUJwwi0Ji9mQqgljHQW3aBVDNvSC2URUxMvqcsupZqJ8pIIEUpu0ye7vdPeuIoSN/GbNuHTZOXxt8lfzn75qGvzL5s6B1wJJM48djyzm4xSwGKwS6P2iCRZPxzlNBxtrU6d5DiD1T0pdTfT8/Xzo7RMmDhDsmw2s6UEPmATKwJmf81Zts9igZpCB9L6qL/c/TijxxTw4Uka+XUJnT689xYLMAh0NgbAC+fgiraZerPjaK7jRo4CW2fKBSPXHjgpBsQz9pgpqSO224W2kUM3eTM/US2dcjlvQfiJk38gkZzqKF/IVUwK2sGdN8tWyWQCIumgBZoW2WA+KzCW186Yg3GGH2q2b4OwYGT3VKHfB4yOTYUzt8uGraLQosE6CguKGpO9UIXuZdNqcZkVM/NhkPxVHMVITgzPDOMO02FFRxgqgrNPScwkaCZjij+merC6oCedscjmoc+PoOqWvRhZpydGN4oixTmTUsxlbTNdFrH8aSM6KFNugzdUa4io8qmBl1g753kkv/0zPMIL9JRWkAKrdQpa6dph9Be0ICUkm20fpcVO0BenbjJPcRwKWY/GoRvgassH/DyfjNpMpd/kZoC42B0UHo6NCzgppUikUpcFF9wWlyvBauDOGUeC/3Ch5G8+mYkE6VpNGUxGfH5Mr7s3h1voJqiHzCFTHPqFaaBndiUwtQclQwzgRAozQKOZ6iCZEs0cmOkWJ9HtNuRKGVu0tDeOi2mYT6FSRnc5diR4OrTbj+C4fwqN3hHFJ69CmepMfPDiaTmCysgVJEC0XC/tVt5JGYos5Z5EZK2lRSEYZjkGec5ASWRxbB/wzIChcCW/Xk2s0aLETUfbpYdLPNzNSeb9D/O/E3j5pdIKi+aUZA6SYF4sQ1JMZ4sYVnnwtAMp4RBBuMI4x/aDc/osdX7iCK4jNps+/NniMgGjCiaJBNPqnTAlQx5unbYT5tzFS6nnAyB5239Tgur2kXWqQOoY91EM29P65MQufbXjzTkGlrhfhxphyrqplis6oJam6hgfMYqyq9FI1zZ2HyGIeG/fFzy2qsUCPSqo02PZNa6JuzPl0+VZ470jefvznfCZ956hOFJGIChyZi4UEvIqiqvsgSqJdW0NFYt0OY040O4uIO0FVg/drImG++rQzQcuiBjKJBZCYyrdCTWg6onhdmdP0WMtUrXh1R37nmPJPe/vqXML9CPPCTVW8tpg4qWrwxeMgWaI2diMLoOvmmoeKVWq7A+J4uTTjSYKntoFrbLtw3ZOYIRLFAxDAJvJjcMCpolzdaC3sF0rZcK+EFi5j+Wd/1jytvNJfOY+1na2WyTccFrHAV8jfXEhcmK9vi4c7nwCI8b6WteWZo8B5WQCdUr/fGMIZb0PoU5fLntTHOXHiG9hkSNwzXGWvV0u6JkgsaboMit7RWlXDqXwrnfmuJ/zRvL3Bjaq2RAKj6qUZLTgiKP5hUm0ycPMOuhGdCWEPBmrC3b46kWwLXoZNtT7qFjZbXtcNo4XeOrZtI3o5A4pkkelNZGaa1qveVM2227rff0Q6PmvS9dlvFQ27D3VA8uBxQRjPNp25tHq6cLDRVpYog3WxLTWdoeyhXVQT5kWpbhUnywbxduX+rdgYS/BcrTKSUd7dSxFYU8V+r2XwmuLOCn6ekfBZD65yhU/NmP6UW8udFlEyZqEiiLVwbKZiVJ3DBhpYDOw0DpWZW/7OBguWyif77UInJ4iQIZFcSOg5JMUzfCwS1MoliN7FkbF0lgAKu0vt5yGXblATft6F8Hk/sE/PI/ab/WzMJza/Cl2xZoqZxdZ09DGTo4G0k1f1U7O13NndHh6uppgiKsC828yNh30sgpspr2YEsc1cXDMq4gutNUDUSQDYpJbia7EnQ0lmf+it4Fufq16R+JlKNLZaw/z3s1EtlGYfPhLSmnNTGazW3NMdZ0WBllc8yihPZrK/jsmZ/6GJhqitQiGPWhUsDJWsrRENE1Hyh2b1KwRRnrzEF/iiJJITr5/sTKZ69TxLIHEaVP8twAiMKO4dsqTPwWxWR+5kUj1GtN/1yn7oqper6md75KfBqtyuqlvaJtc9Ya36rnKv4Ip7BF1emiNg0KduH0cK/LsUCzzv9hfXtzYQSuvsHuo2z5ksTVMrk5wsFvIrDtmMsXqk62TyV2nre30tMI2WSWS1LAZNFKgssECGzHlU1YIoQ228qKy1iPqNMig9syVuJUKNsA3oFBNv6Cs+7bn4vgeLn02RjJt2OFejt0d1WNyIhcchtS0NDUjTSNAtz+fWFkzYrBn0ky7y9RFLxeFhAWxU5kkSRNsSAXUjBRGfsUXfms9kDTsqjABzmsrdF/p3r+McPK280P3RCRyWN+/X4cWYdDUVM0M+CgKzlNyUfSoqQ+dW9uyToNWLc5omZ82TaY09KOQ3NwFEBIhYu3Bw8SCHxUxVRpCKMXqG1aqWWwxhf6MKInV6xsj/P9Pum/qeYfMHvi0/OH0jO8Rq8GoWikdB5XzFOQs8rTS9iuL+bAma+MESOCMJwxIGKnLVqR6L7rZlA7ahU6xDJSkMUvvbP60SpHR5PFoSIVcFYV6Dun9j6EUxrUqneYDSaHBB/p0VGZaeyramxvr0KC/9O+YKa0npePTbvdp6AelWS5+5TaR9R9te4pt30VSqEr8RFQPJCY1NWLrdg/LBWYM3rvCX6ypjzHasiDXmNb/wiSXm1fUm7og+ol++Kwn1cO1D1VcjiuUpkxZHfWTiPRqoNehiMtS8e/kcTXnEPt38xNTpHqzwpAtFTBl5zK2pX/Hmdfdge30iBrnYiTz6PPKPIp0Io1cGkn6f5jl3DqiqHg8h7gC6ITMcbtOkBPZcbvn9p7jrsicRQUUJ4xj3KFZXKeJkVrmYlaZQVKj+PXzvYlr6uAlj94Z8c3IgKPEop7Nq/IcqNO9slI90wZAW8zP+Jz1jaXy+ZYrAET1D82ecm6U/dO5S7M2u48xZsCSGpXzcshQDhLeaFp6kN3nGl7Tq3XY6CU2o0Pdao5i2nX7+aCXY1JLoR9rryatEMfanHyJqTcbZ8hRxJVWNfPpTcrN3I03VLhVXl1ZGxf21PLA8RIiU552nudUdxHBBmSOsYE2z9TqbPqMI/P73h5Bu79r25CovRCMCSJ6U5G7voATQBZTBVI8o38obsWCkgXzGtVDaWQkeKy9RrLUK7PIVYyHUGq1H0hqBhwo++eCYxZtjca1bulojzn/WtYal+uvCridj6HDtodp3bh53NKK9XhJxc3J1W7KA1zTTzbMELGzcD9TweJr70PRLbiMNKSQf6/tdnv+tyTWbn/tvE5PIKo7V0Izh48/XwjUpfVc4oYIznt/zocGHL/Wjmmh/joO9hwifPLYkizbbR7RWhJYLgfO+okgMGSW+IqlrC4mOa7uNBX9Yefh0qhWkj3EAJSdZNzP5fPz7Vb7DVYrzODiPaUew9F+Xfeb/xZAwbr02bN2Pa8RvSdGsPs6InVwA9tdxyBf1QdIJYeq/EmdAaJAqmIFXwqSUJsyKx2yqL4aezE28+xyIXBzhC/Qi0lEuXpAvf1Rnp7hk/KH6en2Z9l99wWY0aJf3Q5lO9PqR52u+XSFz0gArhg8ujofNw/CxqhpvIbV5eS84aN5rsqWzU1pVQhOrKQnh9WCIaAmwcyiVa53ec9UMSMyjWl06m8f/xUgnM1F09U0Kts1VGrqzLEzHwNv+tNOdz9M/VQJnuGNmwsvfaOu/O81ldf0aDhR2Gtrc9cQ37HLdLrS1trm/cauUUcZixIqu6BDOCq7Djeo5M8C4VIjJjLLp4sVrrJHZO5QUanIaUmjrk0EKSV4nSf7rl1rdxmFu9752BP77FOacaN4vQ84W1qg3mWtXZHW47T5cp2knxLcJzoA8oaG9aeowGFxkzGjxIVjRW2sqUSIi+rE3NVem0rBDw7MERFwdR7XuLhCJ5b4x+bTebN+QZRm+2UcC9NsAaK+ng6g/niyM3MngfcNt3mUYt4hzRiuH4zfX7bvVIX63uewUpc5IYgBS2wrd4OiRDhWIbOj3F6nQi6or1OGaitFcGUfWkzYOPWsSKwWjAVUjP14RhY/Mai0UQ8TP//XqJt37c2LbvVcgo+rfMfZ3XCBy3L8Pa3fbz/ugiNLPpxWYmQVcJsWKkqHdulybU9FzUkLA51jN1QGGOpl1sh28C6qy5Zp33Kh5AXo9T3rostRAmme1heb+tP5bbf8Exk9roc66H45tueOnYIZR6Rd5cftm1JECw9hvHW8IFNpy0drjndHicHoLKnUXOrawLmv4xkUseUOCzWZZyE375s05V/XXC/ijB739cquvf31XONLQmJzHxFvNkf5ut7kvj7HXOg64/nlm+3rvfxbawhWsSrPHtvancjfDt+hxj8aGVax2Sfr40mOCFu0FmEqNYQqXe3UBVCvULlx9XdsK9pjRV5dOYva/8JN+cckXcvrKyx9ueJrnePr7Vs+n8pxe+u51KF8k3OhsKGYvruSE2M2phf4NcCrU5vnn0puPAx3bpvzesiLat9eXQ+gZmcGVyuvlM7162v/+TVAuT81f4VU6k3Kt9v2Xe/emLLKg3XT26FAZt9C3NI50E5Ru4ozpgK+xTGiolV6WnibSw5LkOqUHJ01BLo11bHi5gfEC10SvP/6Fnf/FQl/Zcw1tWsnp9m2H/YmRsQsFRM1VPQ1QWafojn8td2FLR3jtxXu59SNXwzggmqVT6kwHT8wdH56gyH5qU+HUcBWsjQmaxfoj6+L0duT7cLH61zMocfetu2r24chKuOrnKb7K8VnJwUNcsonPbJdCtzCzP+MsvSkSiXIM86T65l20J57XEv7eA/1oKhcACXje069wfbm82v/b4lxY/FNGHXKcWfgev/5fm/fXHYSCIIo2iMkg2DiioVudOH/f6OPeHNycwJGguFloaarqrtHmOOt7ham8WFzXvWuS9BDlEgd5AEKnevTXvCt20qWCyAj3EiIFqifR3+Wsfi5aE0mVfYpK3rZlmhadWIULdde0KN5ss/bM5G8gzB17PC55vFp09pyZJ7QQnxuKY2u6t6As6vgirpAqMl3MYu0AhdU0AcXtCCxVw8hXStRyKwBRXUCDOZpVvfer9F7L5G/pfUkGG+P0m0zjS9bcct4peMUhtwoaGAczR1jawvNJOC1s+qCpks5cPW6Il6+aDWdcXtEM9oNrzuiim/8DejflVqd8xRfzkj09h4q/q2txrfNLV9q9TK8w14+0ZddKAwVoQRpwrM6VGHvnQySVkSFeoHEcUExLanmMq7VTJW24GbC6pvhGbeLyO3Z1+xj2jxid0udzcQjVhJInNqJzwQlOaKrpINUiXH/Zp4kBiBtHQ5czKodSt5SFk9iHBfocYpXvdlTy1uGvTzdvC3vxoBIq6HrGSmiZKEM+sQGeebR52RIArNXoxynw0RG83C4QUNcq7u0jjxUu3LTIFMeF+vPWPwTGR5D5Fzrbe0FeICXs00YGWZqlRD15hgHmZZshR8jALzSUpIEaOJ2d+k06Wr4heioq9A1Ebk9oF6Hx9hqrcM6VSLk0Wd7CKCp6IVatQlR/61vPV/FVUIliFr44YAqOf8FEWnMySfpg3+tgL2m+fKvv2rvhXSzGrJpfuYG1P0TET44oQM/u7S5wmH4hMW7ayIGMVAtGdLFEdvK+uo+YRWT8OYNuHgnit101Z6ngWHTw5o7tUMheYgYnflgVkhPxSL/VwpZEkk3hrRCtsMosly9+NZqxYXYQuzTXYFO/4s4/fkD2yzAUXa/WD6Gyh8UkrwVkvQpFFInRqJJ8GDxmmcP8DqYlH5TK6SnvpDzyGPa6+ZxubhvAt8B5/Qf+O449o0AAAAASUVORK5CYII=);

			.img-box {
				width: 210rpx;
				height: 210rpx;
				right: 18rpx;
				bottom: 18rpx;

				image {
					width: 210rpx;
					height: 210rpx;
				}
			}

			.gocom_btn {
				background: linear-gradient(90deg, #FD5D48 0%, #F63724 100%);
			}
		}

		&:nth-child(2),
		&:nth-child(3) {
			float: right;
			padding: 20rpx 18rpx;

			.name {
				width: 148rpx;
			}

			.img-box {
				right: 14rpx;
				bottom: 14rpx;
			}
		}

		&:nth-child(2) {
			background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAApAAAAFoCAMAAADXQjuLAAAAzFBMVEUAAAD/9eL/9eL/78//8Nj/7ND/6tD/263/687/3K3/8tz/9Nv/9OD/68//9eH/68//3K3/68//9eP/687/263/263/2q3/263/263/8t3/68//897/6s3/7NH/9OD/9eP/8dv/79f/7dP/9uX/7tT/9eL/7tX/8Nn/6cv/8tz/7ND/8Nr/7dL/8dn/8Nj/9uT/687/8+D/79b/5cP/6cn/5cL/6Mj/6Mr/5sT/8+H/8t//6Mv/58n/4Lf/4rv/3rL/3K//58b/5L//3K4xgBh6AAAAGHRSTlMA6ZIGfDcT6umSVxyt+dOvr5e009N4WRyAIxFdAACoRklEQVR42syby1IcRxBFkY0VCsuyQvYKhmcjIAYYHtoN//9hvnkqHxSpsMIhW57bVZnVs2B14mZldbE365f9335/c3rxHVp9/n6tHy7QA8MXDxenDw8Ppxenpw+nmrwoEPnBArHp8vTy8tIyUjoZK1sQNUzE7UnTk03p5GmluFqdrFaKsw5Wz0QLBys9yBeTzjTX67OD9Zke6UxDSxMR3Z5tNpY3Z7e3G73cWtpsbq+vb2+vN4rXpnsNC+fn5/f3ROa9JdalLxpfrq4ULGvFRKxcy+fPVzZssUhKFvSE7pa747tlOT4+tvWxDXssuFjcaJBvbg4PFY9vDu3xoKn84d2fH/d/Cfa63v/05gJ9F4/L9/MIg6KLDIoW+GVM2APKhDA5bSw6jwTN0kBQC+KM49MWDPnpCSBXJ9Boj0QuCUahR5acRI2utT3BIwMgZ4k9Ajjq0SDDpCGZuh/p/BoM7xNDErGQdDmAkUkhQ1EIagGBSSKxkBSPi8DTQiCCIwMYQyJQSIo9cQmYhqE/4Oh6fLf//qs4vv3JnfE/9cdv47qsodC9ERTNGBUUlcSjkxgLWCSTZoUzpj8mjhUgkwmQiluWAafJkpzRJqGALCodwxqw2RwSJoWkWaI0qJwkDjU3t3C5AUNNhWv9CIGbwPHcXHJkgGwg4o7SlTIUSkKP4EoYpYWYztglCDFIM0oFCQjtbZZMUQr49MIi3oVnEHn44dPbzuOv4Y7/e73OvyYkqcnhg7jk8Ed+b37YgITDYrE5JJNRcmfcZqnWiAmGJzOFuYA/xcIx0hAYwqOy1tRoIlyWPRKtUOsBQwk63RsJzqMoZCEGqdWEBqOFweL5lddrUnolOBKo0iDpyzTIKtnCkFItIJPCwPKlcMhhlQO/qtav9O7XvVk//3SxOzxihwDJFISFpMQKaTkjWIRe5vCi3WjEHcsai8ft0wASCLf29uQ4KrozPnUgBR5r+LPIwnMiSRzCGBUQuXQLh6N4R7lG11oUklApg4RCUjdIjJEN5PnVlWMZIGYOJKOEXRmLzBFnIBXDHSFxEq9QaDtHRRszg/Pb0aPFTz9PPP6xMzxSqXPzqBkRJOfqXGR6mFWNTBc0wqPyrK2bIwFvJEQnc9L7GZ4CsHjs+0dJkdbGISRNsn7GGhlysAiV1xopSjW1mpWjeN9w9CgqYRF5alpesog8T0QScEcqdbljFeuiEnccDwHl4vHR89HHn3eQx2UNiTzibVglqEXpzt2jM8hkuNIfSR7nhuYkEkTyzKJQ084UlZIS+8em7K2f4Q4ei0609uRMntkMh2ybSOCzxNCb5rVC4Kh0D5ASDU2gSOEmIjjMjibcERzJJeq1AamaPbXVffsIjBIwNhZRsGgIEg+jZDNLjzYF5ZGR+YLIHanXS+4fX/TXmnqU7UfIZMwlm9jckQiLPtoOEjhnEmuh5VYBOBWyZGu0ol3byK97ZOKIHEVw7CWbSm2BfibqNM2MpgI8mow+rREYWgJJcqBYe0g2j16zZwGjcSgilZAWPCVOejTZQ1a1ZqUQLL5sasIMWTiMvLsxhk+qcH/KfmY3eLT9IwU6hA0KQmUlTa3CIhPLWQ8zkzhlL9cMKQ4fCWjr0xKWGC32iqJ9MpXsZ4Ii1qikYGo0riOusUjHUcNn04ZuBmkxaOT40RKCSPUzRGEZSHbhjo6hq4AkR4etKRz9CJKgt1ashRrVegFAsUlikm4cxsMRBpXJImCmhKORCJl6vLN5uyP99TL1184mjbWV7UCzsAPOhmFrahqMABm5oETJpWuwqASG1OsuemswHFLmJQSIAHnmNXvyRJZMWGRWcw2OhmEyWUDSzmh6zZ5CsCh39J5mOu1hwZpirYlDauCRsMgTgkUH0g98tCC0os3WUQwqqGZrMqQo3KkBI3Vbevd2FOzd4NH8MXH0VluD4Cc8LOLNxUvfQhL1SORJ1WCDZNPTduvmCIoguRKZJtnkjOKzRjXVE4i5pkwr0NDIFHvF9iWbRw4fHUZpgKjXdEemHrzRyjOzlC/DGdVbx0oilQQg7kgc5XreRvKrl2phqBg8li2Wbl4ciWuCI3IQiSE2j0dHZo4iUomi/f50J3hc1r5xZBDEmQVJDjlYJM27xy7wywSNxCjTL32yTLFsERhJigqc9WgYjan8KuNFO48cmdJ8BOn1OhwyD33KLYNIm5K49GZGmUk3EwJHO32kvbacLPaGhvb6HBaBkRALCjVzSSCZqBZ3PHw3tAGKkuVZApEAi5okXzR/1DQWjzSUPrw3g9wJHoc/QqCGJIv0Lsabaq3nAh3v/SM2/BmQMZoKRlJhCYGaWigSTOGOxEIS6Grv6ECitoH0w/CX3XW9uAQhJmnd9TjpoWBrXBNCohEmGdFYa5QwRUo2YGZf/YrIOhKXIDJVNok3OpKQ6I+FLvaOGmhuYQrIqtQakuwRKvcF5Jtd4BF/BEU6aiKO6VhqTAxGmSY0XY5QxjhDeRJP11NAuX0KNE2izaEkYI6xAMlwQ3IXzpjfrjVNWnVRrt0U8/zx2p40yOBQVL5uZXhJIBX4MBMCRUaxKOGNarKDvwKy5Kc91GuVazQdhbu8ibFAzCaGUMIYEf6YSL7T/Z5d4PHFeU9aI34JimCaJL4iktx3jw5kozHrNrEZ5JbIzjGa7JX1NUhcpijUmOTzM99o0huhsyOJzpxDMqnxSKkGQ9xRDxzODslheOweLSaItfoSCYOER80uvssoULRRgVn1ejTY3PQZAsQGZNzwUXI7fJlmf6TBZjCFo8j8ZW//P+Jx+Uc8PgSQ0/0exelUnKHFtxS3exqHEchfFca4JUsAmSCS0cGUvMVmSuSq14hyjUvikZmyYFfNpmoHlINIscnxIxSGR8ohkX/DTnUcg0UNDHM2yMUWsBhVm1mij7FMchQbkLF5FIhRs+HvxnMXUGKM+OMR2t/7bWf8MW4/Rjtjqc7C3QvrIuRkluGLqN01a1x2fwwEg0Pe6xRSyxWaPfLAkoJWpoKy5JcfwxvLJJHWJUNRIA4q8yxcsrSJ/ppsRMJh8MicgIxtpB87EhiaE5J+wcd7a0adik8VWwmH1ITJ5o6eD+HRYZRIk2SK0KhHUc7IkD7u/b4TPFqnD4XYYn4mxCGnpgUWSfzaz8JJEqG4zG0jKxvMEpV6/nQYF3Jps01au4CQrDQfPRKbRWKPB6AIlLMtetwwgFEDIMeYG+x7hhRI9ktnoOgcMttn7CCSwBVIB1Jry7ykQcod/QpkdthJY2+yORHPQ/A6GC8ex0caPY8InyT8ufdmF3hEwx/96wzdtgv0GA4jqVDsX2f+7ky8eyMwgqElIRhTHIrJgNKp7Nd8pFh0f+TkkcsUrUh77a5mxr5bA6aESfo5ZLEIjgoq2HBHyfY5eyMBENsFSEcx3XH+PtPqtQIaZ+LUbBvtphlTqoMecIysZ6rVYZRRrzXpav7//1cAxBA+SYREZQyTxbd06e7oy3ZBPBNodjmNedvMHHPlLM4w4owadTuc0JhcRxg1u6o1IPpaHFq0xH8r+E1cdo/tEqTfxVUMFnmmvgYWPSeHIjInPDJ8OosMwOy6s5LtTU2/jguIvnGs+49wySga2TWS+YKtIBiZEPlh71/icSH+86ZmgcdEkuZaD1DWQThj1lcBzc0jucNIzs/XqW0G+utRrLXMwx5iFxTmqNXMIw7J/yzkpYrX2kTFDnPEGweFStOts3ukNF3uUXYEQ/UBm6FJnLQsV3oU8UXmdDKeFRsWRy4YeUvRyWCEcBnXKpzMoJFHAkXpSDl4ZO5d7ML9xwc/FWdly+yvL3przVtnMTIoNiSrtY7UzDFviPNQpzHH5o50M6NMzz31aiYyr4brwSEHkal8BUKiN9bKhFf3w8/Jg0W9zShqMXXXXMsNCsnt/DE+Gs57R3KJ3aOX6mVmkGV1MpE0hylm7N01nbWGGyMi7f04Hpf2Sr0GQxt+vINNxgDHr1/u6VCCIdmxnFQkNhwBUGO7jaWyhblUd3t8hso0R35EVGl49HXiaGkm89aIJEcvoyIdF3ySyXuHUQ8O6dvH9gWbfiaVu8cCc2ixOg2FopIXzJFRKDLrTDw/XJNJZHpqS5bLF8kKqH0u5Ot14sgKIHfAH1G4I56YfXa11PHD3NGQL/s/vHYWFVFzR7SdfZIvMr6T1KId+GCG/gkbGiOX1gNIwIz9o0bTbRTt8cEQk0Sv/lnhniHszCBpabLHrp6mkLzS/NKrdHNJ8QeLJFR9zV222OIxazQLqbwxp5ujw1jlehYwakpVrpGlvR/C40JsivvhJvNGrJAine5Y9Xm8o16umQxgJHUk/cyHVSNy+6QYV3G541MGySKEMVK587zHMzGAHMNYpGKf1XWKjqTYm0/DoZH9IwEBJB1NVOvcR840jjtnJpAkdxzprX1RW0hHsnkkFDL7J0P5YuaZPuOThMIaBR41GwKjdB/53PvR/ri8On/EE8Mdhw9CpX6L428PORE/t/MechedDAMqyxMhMI8hNXwLSVdDBMV21gORoEj2iSaLjJPHKtKkEsZIU+Ms+ofr7K1JVGpJJEKjhs/ZGuvrzDkYThcgk8UIC+Ua+rKVIc7fC1loQGC7VJEsika3Rx8U7+aOQBknj5I7I6Kp2YV6/Rdx55IrRQxDUbaB+D8JBGoJEDPY/8Kwj39J3bSQGHS7UnaaAaMjp/zLIyPODixB0y0gbmOGK4obj2vWR6js+FoGFhLLzIMjASP1a1NsbDWRPT2zdlWofMtseM8rHAew+Xi85RC2b3qucLofoREFkTSerSlx7LjHtH5kb3UZfiyhDFt2nQ+Xqa7I9FSTmYxfr1CS6aEfF7cIkMJiCeT1J6TZJbR59eT5mR/V+4iK4BpEXVyDnY67itRpnb5SgdwzPr/3WmFTybay4tHlI5lwWirWRgo9rXGNvsM9TnsP+3165iM8kgKv4Jr42qnsFnFozHRPzs7cq9F8oftxmZ2RrDhIYk0Hgjw6WwiMRiVSGXHlsZPip9L1oUQz346Lb0x59eR6YdAYixOckKa5KyRZFeWIQGEaLWIvA6+J4z47Yz0+v4fEnFZAMUlzTYdfsz3Viqvpx5iecWOPZH2yZO02enxudOFixzvOLsYLu0IzB/cI5Rme66jCpQuyLqigQBNEgiO7S1MFXjFEKzST8aFJ3KRLNCjFkQRkH9pgKUA+lMeX5BEUt47HcJdVwZ5Ymv0mwmQxWEgqj3uYrTMLPT5DrZBH8uFUsLd6oTpIWJyJV1OR6tnHubpeiKpYxgFFpHhNv1n6R0A8dZwRWfvCRxaM2NzuTjJnsDmwUWWHSAB8SSLlMoB9DDvzPZit42wPaKqpwlcojm4MQD4pnunYOlblxQlwpmbdQQ6PtlN8RsXiLfmgjT2K4n4fAGOGb7qIbeZUtw6NmUAGIncY/QXFgbD14Eh7j73VUhFtZnw/rod11AbdQ/oPBAw1msn+8P5g7PaKLb6uWa7xijphSKPZ1GlWCCWmyWRPHdjztryt3nDTb9M16nENkM/sNwPKLhPiF5HYmFrP7rHHWIaNusYSxdFPamsMLxrfgyG/PIghKW62SRwHiW4ET/E1L+HM68SwaByZqWvcYufDacSdttwJsfu7kfcYzoSDxEMOk5iWFzQ4pn8ASalhU7ZmaKERVBhr9hpjh7Z8ObZwSlPFdhJjsktpBMgn8Ui+J3VF1QHnNILzTC/kvWmuLs/svpF3RrBXKn9rmQZbkQx9FWzP4gTK9PWUZ3ioXnezGfZcv645Go5tuS0FD0kunF2nw02fPCRALt+PEl+/YIhnjtel5C4mueypD0e0IJn37BHWdMqn1bWITWANgOUhYVSAfN68ggk2e8Sp0VSzWWtwU/eoV/hcr9uT+rVMc9nqjb1zhQ9LRgzzwNY23OHyY28azf3oxtyGSX7meZ2Htc4r+GvSOJ5HuhzIxhGtCcgsFdqypooq0Gj1uhLiS20GKKXhjFlXkj3dkjvpRwmvTYhpBshkU2rZj+YRBCOsZp+esmrWbNyY7nWWPqmvMXZlwVGsczMFGuFu3KHQfsp1AFMvdH2nI9cZBMVM9iCS8gkUHcYsYmd4nV+PC5AGosfXE9JU/lGoDCwHRLTMFxJf++ENkFKbYTmGpqHwfNde+MSqzySCWNn+ZLGrEOZ6ZIcGyKfwyH/WVEbeEYWDTCr76P4njkHksZliyoTYwXELsJeeCnvzrBYg+YYExeZRmQTCZDIx9EfyjwZi+Ma+FID7AGzd5Lyujty7EzR09YDip0LQLGsECGdo4aV55B0gUWQfAdItRpjMwJqvR7bpHVMNkIQ0RNid6SnRb8jH81hAAiLpHnwjukJpnq2MjcLoYR07kBSZ7CPy+9Ijnm/UCU3gEDc5QBaCGcug5cYUJG/ay23nH9m1TISdE4bGZJ3SuMgt5/MpO3wAMV69PZxRLsRMRtY6rMBbXT5TLNQWcfyjExkrrEheHJ79uHv1+lCkyW9G4plJQqIEyAfzmOmdRDHHXOsr0qS85IqiSPeGszTvOHuUtvYgNfAKlOkgiWa0eI00hOdRV2Ak+TgNZywJsuMS8Vs5SD4es5/CdrtwRQWq77QHSw1o1uJM372n8zN4xthgNOfjQM6wK1Z5ZNU8V/F4V6JCyLtCCJcC5KPPayR9Yh7d7OAQVdnHf3WHI+fKNRYR90gNO/M9dVkFswrg+D7co1xyFjDyxA/9foxWM9/hHYdCtn1iQ2M15H4ER/uxl2a+j6WnYjAkqNnEUITHTDpKi8/4xihe7x1nezYccdMhjU7RkHv0FQmfnuRSCmtTt/gElCFlBciH8thEEs8guEkHshyjqQlpeM88ptHrmtsS2UDkdkKDYcHJg2skwqabQi4Q97dK12j1knV9uJs5qM3warrn5jpTkH1FxeA4I689ysVGJQ5qt8ucoVYLg0gCbVyiidwIUEz2gQ2Kd9I9aBe5LwXVF1SQfmSBYS32CuRTzmsoBMkJp/nnpVbIQp3vs9+mXm0nrpGT+zxcCIK+w7iiRpN37l0TPjhEs3+CxSkYbrHMJHvcBo4IG8lCVqEmL/DJiuGWD+ehRDPBDGq/4QwBwk48ojYceRPL9Vp7TOV6IpaBRd9CYAY2UizE4COlNJP2Z7yOoXT1oPfw5msC+dD7HzmmXXxT2R7nbv94ZA2GGmpD4yXKxgyU92dnmky47NO684/HOwEIqVH6DQmQe6PP1iOuXRX0QLqAI/G1ndo8U8CunM84SUCsBYxtGkfoLBJ3JJlUsI32mc2nI3eH54Wk5+ukIqhmC4T+a8uEq3BVStULMfApApAP7jf7MbOuUS2kaFMzNRNmr3K8RLydY/3YG83WxnBMUYjte5r3q8PtdTpFJOdYVgUS0cZg6Evm0QnMNsigkup1wOhsiock65MU7tFMpcLNAGEiySoiJcDWOuElysZVTqrnBCVxDMrXlcOpzqDxiguJsTD/DeSb/0NQ+3HtRaHTMSaTPUDDoxAqjeyXE1sia1MaW2cYE0+oPrblNoCoW2P+LBG2NEB+mx0wplc8FA3J8lDDZp9NuabzypRpqMgQG5HrUlL4ciT3WE2QMvJKwbD/WhwKGrU+U/odY4bSHo7tIRrimHdouUtqioUYW4mhph8VyIfXC40+JO80w0+yiWt89KpmlX1WgR+DIqbv25M7SbEwOBcCcEybNjG1wAiI4Q8Bc/KPZ98YKZ/r31dYLqdgQ6pnmTF0vdYK56z+5Kau3NOo5lePc2HhMeF0PUIqPJPh4iCHQ38JaBb3KDlILpOyRSYck7nwFmnyMSwn3zNu8gzkY/t7MrQOL5nTM0nl/ftHz0lIia6lhq0hzbSH/8Yromqa6704yAFzJrnOM4a4SAPPbDvIqRpOdE0cY6b7H33hF1GUaYAR8ylimqtjnJ8ZXeMdOyV+rs+8zAD2eh8pBolUjxPY1+OeWs5mgibSPfvt4Wts0ySixi0C530P+YS/F1eBTT2d59FqjF7AR2QdMJ55RNWj5UKGr+cbkvHCjK5xlpfyDJticoYWAFJ4JIohA+kyflJvgKzWs5zAjoz4SF0fvrWFS/uZYYgNGBHQXAUWq1joz2CoHRXhKOe0loGF7jlzjcgFkC3QyOqvyMlA5qvy9S9t57rlVg1DYV6D0AxDGOYCBaZds8iCvP97IX2RtO0jh9BOqmNLTvkDqxvJuvo6IO8eb4nHaL2Oo+ZHaaK9zDWCvbxAqmuhYVKFudMLr35ENdZIUlKGjDcDi/DeXqjX4uK4eV4hK8M5VfRx5dAY13MfFFL4wrGZCyoMkSjKCoPD4NsZZ8YchnJrkNO4Zk4HDdzjmwmLTW/hNL0HPhN3R2ZKCYqSog/EII3jZreJAA2Kz8/GrgPyxxvhkdatbJxJZKquRy+8XmkuHHHZKs4q4tNGAnyCJxyhqDUznjnsgKPG2SPOHYZQK6d4CUEEcnh/po0inbBo5NyXgc9EuthgESSCx0SiS50hvRenvDWmGzFW9xx8E3qUfw1vAyriBUMV95iINUUgY2wPYk7RzC3YivbYzwr6OL8Ayf9lsv94Px7vz261xkgZ49pYWNSDcULkpQyN2KV04arlVbgEgPzg+ig7TcF4f34mF1BUUFw6MujeYbl5UXNIFqoJm+pHyKUmNodfIxVZg81s9fJwCir0QFcfuKeXPnLqHkAcu2hU/IilPrD2mx4aTkN6JnpcTcrBFh8DPmhIg2OoxobEjsjrgPz+qyB40En9CsR52AZLxccx27UChvClctR4Cn6MgJS5Xj06XJMp2PbV26642AtSj6EUJKuNf8TBhnN/7G/GVTeXoxE4psCb0f1RE3JVF77SjayEZe/ikm8tXCYW+x2SMfaZxz5rxpCNsjy8TSLt5jpuj9uSM+GyAxKT/a0N9svQzBW6MbAYboxJRR17YLzO6ndlL6lmUwDITrM3Y4yZABjsFSX2ODb/+oUNdwdbr84sApA8P4N2dHVZL3TlXIC5/pH1VKFwIZLj51SNXgbpAjiqxbA1YKMXTerm2HLXmTncq9tVLQsy1kjqcjeZa3gSQAw5JbAh/ejq8bpTc38LPEIa45NTm6MacvaqYbO3IwUp2ap8rr/5QaaQDzPtC4ut1ExH5ZSw7vN7gKLC4cpfR+frHIBEI6rdlRCPnbg9qlsh3782IYs9kQbkMjSlAo/IKT2DIByehRQuRdNAqf1kq43BW68rMyrYaldYoJFro9f49DQ2mGxwRD0CyNspyMN/4nFo42KcPQwFaaT0DJvV1OM8F5fDsgJy+2LcPDrcFoxzejKgsgcfu3+9gWOWQOaUiupTcGHEvdFZFvgYGmEQA3JVj/tHODKRvoY0Hbc/yp5FPlKQLQZ5iCofPRjXHRowyA+Vm7GatcZWs6IqHN5nAmCsjWUxruw06Lxgrc/8u9vfIDseHX3GnA+KUS006lhQd1cjBXrWJWe9AVvvu+qAuVahD3rRyeUQfKSYwlfK9R3y5V63yESh8zhvyykQWZALMqMod5rhQ3WPbpDIAYmZMASB3vIK9UkAIJFurpj/uB5IirnOqnDU5EXi8RnFHwf9GFJEuMf3GH7MwxqRAPKaU/PTO7AofyaGUsiBiYNRAZAts825AxIcXn4Nqcd7REwCAJBVFUnSMFsWXAJEEeBsj19zUkshDa/xaSgpS50zQNKO1e2KxU4RaJS1xsN2IfUoQbowguGf2Sp9TIFPDSwjxgMM1znsfFwYP1vOta6RGtisbgX2CouvYazTVJtMGIau7FDMbXRFQ/64QtkX0L1BTz2FnPM5Q82ANMZOnseenbEPZtR9axApf0Y1ZnwORaLh/rE4s1YutpIzTpptP5GDLlqws2XB9jwGMob35MDmqPVhg0U87MgXDu51eDSw9sQrHDQOecLlcNLIYA+V4W1CLplrDkCyZpy1VGGAUmlCts6igKOz3tQ1AlEHQ2KoyO++XdLwkPOkyolR30J1KujHosqsj03ZvPG6qqno9biORn4S+mHxxuv6OaQzFI1VkgZhq0d8AobGFXmss9xrg6Fqw11k6SPqcfsE9hgSb3BMO52VZ4HENRj9iwLxXDMxnCKeGl7Ma24NNOlfryt8FPJJaqUUOgmMiMDllbDP7+8CJPPD0Y7pZaubKxsUQhhf57Fty1rHYvfGQuPSkGjG7tOofSZmNmOoba9nAoDFZT0uehE/BqlW1zaUNEpxiYlDYbLn8KOe/Mgqn/7G6+Ph17qM7fYP+Nes9mIcHx62ro8XX6Ch/1oeNuZ72YcNDiMx026PcmaM59MKYNLFxTi4rLVSh98mS3OIfCE7VWMExqnFVZ24scQe52at48Sn43LinkmRIuHIcGPgQ8PC3SYKjj9zPgFDzs1e681hk3l/ZG9qw3OKT1VUnB2aJ0A5j5RSvjBQOKLx4+tg4zjuHoAjiw2TT4MzIyDCw8+ujgUOjrzDpCA7pUbMXuxsxG7vxdG4ABZzgI/MNmz2rJFlsK9pyPdExV+qzRUeOy3zz2Gz4QjkxYpcOGtbAamHkHIbH032pzwyWYpQeCpIABm7eTNBNduspbCzi6bNbNYBn8YQGK8jRd1jXiHrzeE/aoA4Pk15NDWg4nG/VSt4pa8PQLFFe6Y3aJS91lwAaA8uq6KCT04NPwuNRCETil014lbH867xNNJcACk+o1FnUHlFQ/759XDkPSQoZU6mAH0wJ07SjxDnfnlUvwKr0JiHy+8W6hVN38ZoVIhgT3sxro3vWY9srvBjvRfXR5wZ8tLFrqg4p5zd08Y2T6Nx/QfAHOAYFo6DrdfD44oOoSBH97rPfnRubJuVkaIkFh4vFxqLCnFfHZEox+jnMjGEHpNdiD+yOPJ9d8XJ/mKSvRawY4WExomkkjqJUiHG+cJ4ik2sp0d8dJekp6saae5atKdPBOjvc0EBR9X3sCfS6zP417YDjm63E4441dhqOwQIh4lSD4Naqb88Ti72VSSuaDiLIh/AyOIgPPJxUFWPul4RQ/QRyZSKQGIb3FzVuCZHM62oj3jzaHzJZN8akAe99wFDMUaPYT63oFZXkeC4pMlSc+gXyHn6Iy6MY1GBnsoW0l24KqcoppeQlvMfIxoOCYqSIh7pMiYt6bKrR7pnACZILJfm4wfR5AFwNMlVErsd1Y8g0o4qpeAg0uPXKMfDhMS56xUUxlIFZOrIVVUucASQ616uHvXxHVHIb2Syw16r7BEQhnsNpW1uY/earY57Y0UhObcsTVeRf7Pm/Aymm4VDMz+vwEZolFQPh8uZMc4FUklC2ESgUPWPfpKxbtVm2eJqJKdmr783GByy81n0B5EA5Vjj0wmXhksjiHTZSBWQ5dhcuES+pqhiMz4QeYUAIovTN3Bq1O+KR+0yDurlGmvBJVduDSCU2EZ72nOaIg0CYLPYeX30LRMdQhU9rJSjmXbiICyyNw428fC01UAT4jCHe/ItpHBqxtjjblGhNRru1JEal3LgUC8hQa3jleAjEfEoNau+hTbhDCiCSj2ADW+N1y7quWEXoqWxnn9f1ZBkDg9fqx8DgNFxndDMV9lVHL4IhbcObDFbKyo8ttFmQwNNuTPGN+qxAbOlrdtEe3I0L3M5Bay8a8AHLBXv8YYFrpDKz9iXJpuM4VxL8esmm8ERbVKEjhQi2Xr7et1Eg7GO9+ISkuv+mSjsYRgAe9Gw8FoVkDmowgnRwz1dQc5W+z8B+fQO/Yj7gjCKN69hysqolUYWvD+ugJSptt2w6DzOmkrBLTKnSsFyZEq10diaSS0Lvjop4BPjH8HjmoRKmgwDiAw5A4v9AZon1YajJ/v9sfDoe4HIQ+hI36oNr/ijGhb41Dpz8YUFPWEIJRw5LF5kj8qzRGSnruyN1wENeetinxdcmCE9YyuUYw62FyoV71lpS5AnZLb6cEhgbK51kVLXGtks+id4Rh/74wqcku75bEWaUDZb77uyCTyaCDcm3p9h1YQKplKYVAFF2mxnD+uiQf1VFu2mK6ShsZ5DEqnhNbqwEa3ysScMcWei59Vp8mJ0UJznVUcWv6G1k82CrgDy7ivwWNY6959j4zViE4hkLaaRwqo6nGMz1SyOSRoGMGUPP0GZwqbCp89rNlhmJYUulO2N17hDSjlGEHJOF7IVeox0YbR1JRxjdI/JzRApDp+XcAw8KtsG7Qk72nY5PWHIqfnYUwOXsfaEoRMBH+lGFqyNfkQ5+kY92poT2I363VGAvJ1XAx6rmKeqw5Fn8y3gKX19eU6FZptdfPajNV9Xfka2GxwqDrkd4AMSiwKAOja6tx2uDHzVPRMTU3IUgMlqwTZuDDgWA3/Kyxhx7PHw5IVDGW1w+FhDcQORywpxvn261m0oaelGDfHBkVFPFwIkxgaDUCawkWtfRgf97wUXIG/VwaB4eMCxOmjsBFeL4f97pUuONaKXnQmQwiOFj7LbAqNSMyBShWYJzX+4PqrMp0PxPAAyR0CGV9MShiSxHYwwcBn14XbMCKQmNguJwaDPUzhcGZpEIzzpbQccHZF2UPYa3jBplhpUVi3FasgZWASWc3GPfqAb8a6RstrQ+F5XxyRHGLtpyJvY7Bf8lyJgiKAoV7WPHEbVqHO32QVHQfJOBT7sZbzHSBHIuDvycZZ67AMBtJtDUzjEzw4wIkTkrqNXAcF8M+VoFA/PERVRIA5Xg+GuFcWUkea4oZiZIifGVxssZRAkXbivKp/VdNyhvXCsNlukDKOby5auijC4fi5cMyMkR2nIm3VlH3K+GddEeP1yyIUwPncYivEbEMqrCcnhyjMLcyobJEaixqWeY1fEp6PReHNkRKhGNCSHe5ltjnO7q6I9LEdii4Y/8dFGMz7PxflxeeeCZORGFXnunjmUvV73vEb7TFps/9bz9oKjE8vLNmretW9jfOjE/CBkrw9X/lNglJf9fhWp+CP5mGqfgYE4PYDNz6u9XOezaBsTV0BcpLqePGKuFQwPp2aajstjw7w3PBnq5tCAxLN+ZEYFJ1+wmWrYHojUVPsZjs5QkYAQPrS97rd3rTMKe9AHOD6fPhwIQhoHkHJlEFD41Sb13oci4iLyhCHKXq9LKsqb0fDw6/GeCYvs4gDyNjW6LxUKx3DTrBD6sVqwJ/9amrHlDOfBj5y6flznZ/Ctp6APPoxHHrHW8GayIbVgiwRHVr6pOc8DQCpBU/P2AGJEe4zNKWyqcYHjEPIZSEoRYVyWuqHx7exo81CX3BlOIlX52BYIO/2a/a6BxtzJW/xRitFIb2teBKQiPcHEv7vRaJ8DeBwIrGXVmR00nHlGYiew2OspegBypSClG31HLBweMLxDikhghzpsDxh2UJ5H20eoBzFT1PYkswXlox+cZLCpEOf22NpdHzbpXgSnhkfbx9PbyQt2p1kp3cNGOcYL2LkVf5yT17t5VAqy9yqk0R68ajCpn6KVO+OfqAOy06cv8q8deqAQHKImsw1bbYaiZrFVGc6WgmyAlIIEmmq2DgUJz36Fel+hNdFUo4JqcZEdlnjWYa4B49iCrYfivLhHhY+6RxYSFQ/nm2f36Ca577X+F/SjLdun4wdvNQSGrE23ayUMbVFUcXlaCkvtrkHSk6Koxo34o0I+frputJ0jZkBeo5cvyV/D2VhrRXvmYfYcpCsv68mVqZZ2LK6AD7Ky13zMqLiLET69tgcQxiHg2DQlnTPMN8ucYfOtsdQ0KvjZjlnp84Sf3Z5lB43Uh9f9EZa0Sx0CGzvzZjgaGA2Np+fj21F9ruKCY6jHiInLm1ljkn5XOyl3HetXXR3hsdOfbo2GRVLyJpAhuoZ8xzWyz6eIayREHUVSpq0h5JLmafbrCeJQqEdbWOi8Pvqpugsrhx2xHtsXH2Xnu5DEzqe5gCJ8WW5GagYwpmYMx8ZhaHJ0r22H97Ke/DhXxEg/ioNHt9ZHl2+n54+RKjSxsNiVKkRNrp0ZOF51eDS6ObJ61hBhIAybfbXlVRdhuPJOukPeAJHfx1vssNSVALOcmNwSHPSr9ysspzYDQT6krfm1YYXC+Yg7As2VvebyWN1dSRxjq9vVBBQ2uiEye7nApBEwJD/jPyd7DSPqmEmajsnPGTA+f80rhQDi2wmjfTxZbFwzxBflPVRAanwPbNGDnapRJrt1XwuSEYGU5e5o7MWc/PvXYa0h3zNy6vGHuV1hHHFmS2lCts5wWe8ZkeBwPRNAM+1FgcQEYoLwHOrh1DyZGkda+jGYsCiKQLhy2I2y+9oZJ6w1Prax+QpZ/TNPkZ3pAyAf5cwgOKzcGUB5fDNcnnaox1CNqxc1VeDDJyQilaABjnu979qJqCOTKbDWvqBrUZ9BJXL+CkBCP/yHr/35To511fZkzIcwpGLiQ6zH6ILxlsWWwRYehyc/jC+H2juBzzMcbblcxMKBZgDSFl/CUWlCfGuUJFBs/YUFSIh0YWhJ45kodKmWV3wZFkxg5BdOtppE+ZptA44n+wyNJ4OjAfKDNCOidCOcb3y1EKGD3vvYlYvN7g7Na+RoxlpcjtfoGa7kTKPT/wEk+FJp5Ho8rgy2lt69NrFu59IBdaje69480+rD4dmlMDQZpmrkj6LNlTRN65tJ8HFiad7ZZgRkBCBZywYaV4vGoarzwZNxHbl48yO6Z1idDvJEObWyGAj32pgpyOPz8UO1vLJ7VYVShfCPcFnq2NhpAye2WkoSNjz3gfzAVACQCSGQgqBoSHw6E+ksQF6ju2UW8emX0o6aBsCv1IiVnzEJ6y90LbsWQKagKEAGZysSTkUu3L90auLpGWDZK8S5Pirgs7bWmb82hhz9GVgNEK+rY4DRz2cXuwp88u1rP9Bj2KYC5Pieh/iblHJkTxrS19EYNtvEa8bCewUkm+JwSIDsT9Ds9vBpFCnYnNRjFIcDzRGIHEQNlsrDr3XkUYC8DsnfHzfG+l5wrKYZ2BmRKoYc68Kv+thAsZX3AD+NyO2VuKIoN3MrHfPs+RQHp/oRQNpqGOSXYo9GCUXn/onaeFxbOcPnKbtnZocGgw0qRxsdQoBUK73yhosUjTs1xzen4/G1Ho4TGHNU8x42Xh5nez04MgG+PMNauyuHjIdXz+t1my0nrac/v0xDAre7+z8eA4xPL3ftHwNHduS0E4tQ2m2w2aPjMtas1bPsguI6S5P8kwoqcpJPKxEHj/8g+GBQHV6qKjce/nACksi5nKJeoElbfT6RMhwwCRhJzjyBQvZixNlDhuwCjZ1O6WWbejw6ve1yphRMqjF4ts+AxqYfyc6gIOeBAJpqL0DqPc1phs8aks8DV3nPmk4A8gsJ+Oi6GN2FUIZ6ztFIkyygqFGkzUzrZ6LQDxACJCLutARC2OBgQ/Rfn2+QsG6sHYJwExdfjCM3Ew00UA+I48YQ7gGH5GoiScNib+ZJUSU+NLsWKDWx+VEzHRYBEm6OCJOmIg2WRrtWGy6fBlhmdfg6KH6+P+6zowtav8melT2sUo78XpNuHs5htwOkqK6NauqKsgo1z0AqO5ObIyjOcXAFHnvLK0xwnJ9D+sSZBekG+WkbEudTTTii/BgFIFWQyxBx5QonOKIXo3umQpAaCNDdmSiBLHdmBKNeG1bYLhdb5FB0QBoaT5jt474NBSgFiUcDIl0KjHNMvEp75kbXstrhV+ebSPwoEEo2ICL1X9Cl6O2798BRJ00jlZq0c4R32PJhLr/yKjzq0DuxO1V3oZMe1TQCi3Zc9bpGxEdYBJ9J97pCqmkmhVya3+D5jqYL7LQdum8dLYaK9Szc7MeYkrsbWgwXd/83LLYD0dXj0fH4lgWQs2stZCrkiOyUlY9z87WECnKx2NW0wF6P7pmYqt7X9AYg30XAMN1ql2ywOCNRLEmnwqF+dP9abyEhZLNjAcmAIyfQyARIFfhwZ2TrQU2WJvn0jtfI0chSFyTVYggkbecA8UjTNP0YRhswQmp5nR/Bfvyo0Mjy3mVAJEtjZPA08uIKuddppiHe5+KQ5nrVg40zY3I7zH7V1MXlEWpzezopEa+1tNem6d8JSGy0ctjcMDXxUVvEHywHSs2Dm1cmO801TMoRo22IrJ+sGCWF0d4krdnZPaNwJLyIyyPg4waZeITPr7ySo8GtqRqfeLrQ2AaUVWwmS90nNvPgx0HFMHxJwJCADw7NCY8GBbkTGKeSM3bkC7WDyZ2J95BUQCEVCXsdhwJE7DH9axPwiyTvLMHZQUkS9H2AVL9rFuNytM8OTCRVy0x7whAuQ82Rc9XlplcNEDmKNEE8TmMdxQ+RMswpkN2rSfWIiEPXj3ADnplvWerkCE3woW9BHdgxGUDFPTnCp0rONqZaaIz3PiqP3SPiXpALII8Z8Tn+ZVfIBsZovza4acYZTs2sGal+NB4vLDQoSjNmA7aJsYGm1eT2zAxM+fgGRvvA5Fc7NXKrUzO6dBxycTROZYWS1VeKcge9eKHZNS127ISj8AkaAWZ0Xlc8XNrxHxgoZHfVCEWyMI316n1XNXT9FpjkgS7INKTzNrE5B+9JJTY4GhnzKeL70Chdj3DXAoi2jIx5ZPxf6s50u64ahsJ9jAJhhlDmqdwAJYGW938n5E/Dto98SMuY6vpITv91rb0ka94oR7j9DqPsexsNgCRtGOEeDt/6erwi4JPqUea6aUgNAJj/PtDVDEfSn38HkF9LuidTTJNIlR3kt0WixA6SwiFXLkIh2681UQqq+nD77IyLo1F92HCcmC0adalw+AJE4RKFyPsxvWr72akH5ODvc4vcdbQs8Nc5Kq/tcx/gnAhAgsqLacjLm/uYj9YWCpL7DdiOwMxic9vFfIDdm3xZIn5/OBwhGHbiFTKiBo/+FhaBoP/pEk0YdZCOyebIILYTcs9daynKFY8/lbkOGIbZ5muWmoAPIu2zxAzMaFTg2L0aC7ftCqBRKzWzoAJwNg/bPrDYwo8Z7DF5bZwZpG+2pgVUI+zZCPhQWGGIvAxYPlnQSBycfld+KsgVNpdqM7fTiUIOVwXEr/SCzJoKLsY4vfxRd8RpxvBpyeHV/N035LuKi7utji7sKsrto3IlhET51h2MrhuRPTXT2wsx2NlDY/cW7pEfk5Kvq8ls5ppre+Bq5tI8+0pha8XClL8exFB7dV/vNKMdQyMK0tjuwfUMbogkhY2GvADLNw8Tm3tRBdrS2EJZazYN7lH2cApAwjHcmm8GCYennozKRPbpa7BoHzHVvw5IdGPNsieDgwCOKjhTo+FuFY2yhfxxPmsPDmvFZvJpomMBf6aXP8LCXJuoLsPuXwcaiYdPQR5JjacIU10OthTkNLI5Uamp4etUeylIrWM3UI7Izzbegzvjx+XlcnW01njWduZ6XC4NkbH62hgYbM9HKPxqE9yu+EGaUnEGSIFSpL9oUcuH5F93agYMFesZktZreH3NWOvvvqZLaNzNlMpr0DSYAv0IIYCkVizsCPQ5XwPjqjiLUQAQerKUo9wZ8MiHnhyH0RTV96p9ccaBYZ7uYwNJzLUhEVSmitxpSIKPvCHH89HwaO0LS0mFMwC5KkZkkHYh2ZnKHoOJpCFrDfZLPR1TnhXkgsL6L1kvxl8BJBjMm78aJUBnoW8TiOwLFipjqLO0FSr0c4iH84CcJ4h7IUW0z8iZQTHmA3IO9HATOGdbnYrSvrWx0P5FkAynJvcOZ5n4uGKyVy97GOycI8Xp+UKYHQz2oKt9fOSG+sfSkBcMtkw0HA1JOQWX0JG7ZgWv8wn/2tkuGA4LtbiuROLG2XbQyGafFeXeEOF/QgL0rwAy2q25mTAO9ozbXXlrDVA5Txbmr+z1sWWBD1wi5c6oATuqIbNxBrsNIhelmP0K3MJWcw7mOuvN5hWvLYv9ZarIyF2DSVWcQSG0UVPhcPk1hUY4u9gLj8Y/WPpnno3fUCng8VlW+Zj8ZjNG3G11asieNazHo8m1tgdWBA49d23Xpe/aBOzeufaC4o68K+hGcci/lCtMB5tiCq5GOSa3cMkJ2akX48KlIOGBzdWPabNIfTyF3bDU4/qOXGv1FXLx+zFb+Ck/I6AYSwyFR6WwvTy85odHzNEvoRf7jFwikNvt1zwd02CDRwAJfbHGeTwCmSWQ9nbEaF++0dRmeTO5mF2xR0SfcOYpGjkxnK4hWYcUwR6+QuSeBETBcWuzjW6ewcf3FzSkVnRlKYVPqRgfBnvpup7TM3lfB0rJaMMOJP+699D4HJ8MQ3IqMQOnGpeQ45zGRimKN+8aw7yAECHpLjYlZ05psQ2GMUncI+Ec9hdKSYJHTtvHbjSgyHfNtyASs0aGjWQh3/CxrzYdXcai59VZUO959Z1ILRi+HW+GlkyN2GTFwiEND4TX17vKcdFuPCl/80oaMiOOh6YFzLXqfXpShn87pyrIbV6M6ABEFfmoPDxbC006JDeetvQiskXEU0+SvU44clvIm109URiTzhjdE7Nx7SKiFNdTNIqHi0DhUIyByARi6ci3lxE+NwR7wscOm/3NVOLzhSI9ADLxaD/+aOs0TVawp7kzdsOL0ZBcDfAx+RLT7P+04/WZ0dMnEb0CjyZfDZBJ+DFusDNjGMs/BEEjLgpEbt3rVgMZiKxLU47Ab/g0vByBZJht1COmWhpyttkw9XGdVORqaPPJ8pnAJEgkOB6buWr4IywHnFX1I6LGpij6iLyO/AwMSCZ9cJVwRKGgIVEp+NfUVEzxR8AYZT4w9SkshG+NM2MiXBmZakQSSBwsg+JJZ/0zEqeOTCvstAMs/5JTozik5vno5Qgrl4YjUy0IIufeGcFS3QrcTyogQ6gLO3PY5AulHtXremydETqh3DOMzXbP2mV+8q3dnUk4GqOVCwbVCHEE2WsQ2fIzikAaw4+BL5D86M2nPqKC1z9Nr54yHIB88nbPFpLFXsopXEsKjHB6uoqAYYhG1fF6JfV4DkpMNWhEnPnYnpM3cRP+GfzRq2RlciBF4TID4vBZFeaff+LKKFnYa3I1yV41FT8di868w1CFuTg1dhTxUbvrcf8MxvtAUz8XZ+0sbGa76h9Bo/1owTaaZ5thswFkpq61aEGEUiRjOKQzTLeUpGMSQDoYn+Jqf7YuMBRHN7rN5mpnsw4J7QgqVfrIWat7jLKsAhAmN8m5x7VGcu0x1ZvxH4pK42c3Ro9eMQSpEh/Hpd9i48eHbaaUy/NmVy69mUuy7zBUioaIT+Sw8aw1t3nWjhXzIYetUPieyrs+HeETmrF0I82uRpmfEWGlBcbx5zYcjhyILBwip+3XX1wNzcjzMSogL+YAfAP4+syUWGV40uxaoUd0pF0VEFeTYWQMOSARkl+NhHWaG6/hnZiQ5QWd/jQmMs4b8lUNtTbGRaOCTPa7xVqOBhHdhcfJPVtA9gbDbq5Vj+v4jMz1yWJNpa5FmxSN3o5tOkURJT5oyJxHiqLEVtuJQtycB2C8rDWyZWecwOT4KzCJKCX5xWdXqBJ0o31Prt5Wd+HBozGCVZ0P11U7lmqUuTY69HJls0LOyVW4h9+JdtQCk/PWGU6+QQiMR0j10SunaPBcjBujUcEYQyALcevkZm6nCUOOf+sLUomafasrlwSjsWh5PYHhvIjdbx2OGYCU0VZUHNIWdmdTx+sn1OJyi0auxKQv6Mrumc1QKRhQHJ524LDRRzDTZa57vnnT0Cg4to2aKuvxGxc513gxQBIcnjQYXjnPwXsaHK7JpA2Ni28t97r3p0XIB+4BgwgevDwgUYWQy6yhAIv2Z7nVzp3OnWs9IkW96XUhjdzjlsMAsjAc7bhMEA/hmNTLkfumuAe2NnGl6dbLUQUVWY2Lf81kqXnhMF9sMHT1CDtEH93NTs8aAV+h+AHyI05tZR9CtOaw5/XXJrhIOyLa1J4eCweG2voB6vZmug/7PR9pqSC/fxFQ5ffyb8ivw1RrohR3Y64HEUabEsi8Ij8+hh9Pq8RhfQUN4tvFy9ZwM40PFx4LiDLYfIfJuBHqORSG9wLxACNM70jg6fNItUwTSx1OdUV9Wo6manz8A5LSkYY6pCEQNMZkM0Qnll+/Hbc+rhkgCpFVHy4oyp0ZB80IBuF9pBTXXtejuPg5PYW5Z0Ze/hVMtiOw0tdRbpZluCrwkWpEnk4DSCPdF2lKAMTgmtgsVBISN45vnYnrPj3cVyyQxG4vx6TYfZ2j9qKza1+RG2B8Lx1stWCrnSsqzeyr/kLXjPVpGgAS/YinbZTQFCJ9dSFgvIZv5zXz8XBsQ864Co8uQSJ9r6rKbS2vfOHNwJy4nZEG/sZtj0Uew56PB4942K/4hgSQNYTULsEV+15X0Qibu9y1Mb4NILm0hcOgsPwYu9eMM/4Be42Aeklufz0qiU0lxThGqSGzcUHW2j4t6Yr2whyXIkBOA1MUEg8wNot9HX5N1kBuCUgaGS5X5bjAkn0fgcNpDGQbcVYpbDfSxY16MJyLxkndv5J9ysucdRfiV0eXGpMEb9CQ4/dqcUh41vrknIqlokfBcEiXtiwOvp25BxbXJ6T2xMF8rWaGw+kvrPBj96oJ9giaZyuwVd8zfnUOxWZ2sNYxHxcwwvV6NNVYEyBlq7svQ/gRNWknbXYZbCHRn47Ms+eCftwi0sM9GtuDgJXtprIHtwY4KlXYLfZVTN0zialuA3zONhiqjmKXw6ZaiSpx4vtRJcKhWOTyChpSI0hj+Qyn+hbm0se4Fe97h/laJBwJHLcj7VXf85MBkpHNVZDLr5tsJWiQ7foph1u6MEeTDQeN1UWDzXZTrcpwLUMyidHO0c2qzRUc01obc7oGjPCDf837cRobzr13K5CbgaQUQWdSaUdja6tC8FZVEdsVBEItHj6NPYbYt0y6hqTuXYOyUoDLlx1Y6ijM9yOGezD/S+W4cEgZxBmIydsqTc6sHrt+TMlnv/CzEZtiCvnT5dPwF2zdN6wJucLfGu8Bi4DQ/oi6Cs9dRyx8tdf2yaHZdhYG8XhMuhYeJzSGSyOPpu9YyAAkEyDVaRjENeGIfz1UZZZAznvZ136FyM0AyFCP+XUCgFyUNoQ1euZKEjSSDzUoPqvk08toSIPP4OldI+HU5yLVtxA4hHXSsxGxH2nfg4/fTr5MvCA5GGvXj7BW2mMfDFJtRYs/xpsRf+ZsZRxejNdA5pYF0GifFmBzarurXTTlbN/vujoxXJqCxFhvN8UJkQNzA5Qqp+CDqdbMDxDUK1JTKg4TxBOA9uMk9QZDOCyAuG3pUuyRegrw6E/Ip7TyUt/56CVfjlHMU/+EVXYHRxW4ut3Tgs1v2z6jXUg9DCmLjeT1aOTedTUsNGpdrp1I0GQCWwQ0eTkWKqMet3waO8vIZvIz5AyPNeIckdIzqjbjxlmfkMbKWm+nNaeKVNyxUwTBTailMC4zFKOJy8Tg1akgv4Y/Bcd1Sgqn4VDvRw422z60YmlHA+T4Xjbsg6k2AoU+KkVDSXX6c3Hv0qwo1K3V4oqi0kxV4kAwa85WONKq4KQR4qeUU3wAZA9AKknjO9n5YunwbnaPsVioKRAiEd8JkpOSlD8j4uGIxMv2iLioV+TWdi6j2ViXwbbjDs0gJQ0Ry35XasPtWiiUihQ2N/nC/nysv9TCO5zqJ+hFTf/Fo7lcusneAxLGFwjUsg+HoRTleYNhGmi9H53LVK9HMNS6uMM8qVKPazVFtMpw02oFWC9/jKl7HuNZy3wQGGkYDV0+bi8cGvQjIg2268fwZfg4YLHNpoBlegaZJEiCR1SjFmC3cXuYanyawGKKTc9rtBnq8cjpa7CB5bLz455NcSm04akBMnsMTQJFu1VjuQls9n2AXFd8jBOluI7FuZwifBjOvtoMngWQJaF1ExI3pwRjMA3wocFQcJx9mpgdHsBEKvTYGroiYbjGeVT/WF+U9oBEblSc2R+HARVox2XncKdodw0sDtnoA+KOJgKD44NBfQSk4xAUcu3zmnNVHOU9dfjNBBS1o0vq8WQdO0yQTDqZTLQ2ltuHNDSaMA4gX34kwJB41rDx9eFm569HgTBgKTS2MKTo2+bbgEm1GOoBSSVu9HEJjkj75NxUvOc9HwggQKqDhk8bkSI1Y38UFAGi3ROKmOq4ZUnu4Mfxj9HQhQCQsIVYMzzwFzkaPGwj0Hl8Pb6NnGspBMd16UemZ/R2XDyab+TR8JQsLDYrvZ8KIAxus9e5NqJqKjQd/WJflBzfC0j1zlDwaBwtqYpH+5zds+9DJT37mjMYX+93xb/OZCFoBI4efLS7HJga/SgnW0a7Lf7Asy4Q2o+z5ApDhG4M5n+ByS8P78do6BIIGxyvjRHvSTOtgjPlsN2hUf46SDcRjdfQ2np9KBEHjXZVuwK/7YwKGENJ5WOf14fD/XeCSNEN6nFtLH96IeBzudxfoPt1Sa5upfkru1yDFP3eGmy1XteH6Bpy9WZithnXsNealpKh8GUdu8p6VhByOTQXhjvjS2g0cW+hfD3aQVP6NFIuallQ/zUXVeT2FA1EJS7oFAS5FRpxru2nILgWYSOjxdV43TUupVGNJFXmWqnrtoSGVKFdMzXD775HpPDI3zsX+7yxPGZcXvZhH2HQPhQjAk8GZkeBnjVbiJQ478HuyULB0WQBEtNcKcOsfQxQ4mnLXPcOw0EmW80Zz8ap+TqpQ9LgSEyco4lSjJIan/0mRFbKEC4k8kfGw9GJh/RMc2lQjrDKzgQU7Yiq9ZpuhV78CAyRbq/rElhsFbmMxy1/Rlka2FYzCpHqe11J6Rmfu3GDSwPF09FsNdeXeENqAUgUiINE/pyKcTUMMv/9dAKknS0i+ezH5ZikMZJ7zUQAqirkyUyFj8bKpdH88B4NJ+74RlrqIK4cEerRAz6q8aHZVXhUH43rRX7t8QjnwoxcfifxcA7447clwx3xnjLXXUOqArKm5Eof7oeljA8KKKIaORtSMBzGgVJKP9KjZnRoLPf5lnZoomxvyB6AJP6ISH2prDWH7/7YY9upKRxqEunRXiP4GWXzTO5Cokpc3Vz1YyoAWNQonwbH8rLB5CHgI+3IMTgiwKJ9kOY/RvGj/QCjMKm4+FpXQRuNfGtlsCcszoFH4ylFaa6FRU1K8U+UrVyTge4VFVcR7QGTDCU9gJA/BMSGSIGwkfcDzY3lz1SWOxh1FWjKU0BKLypdE6hUsEdWG5KObBhdSns4AFJcuZl9QYWdpNyn2bPXANKkPJymHlWU6wPEJxh2Cj8mlmDDqAvHZNs5jEuhhwbHuo2niFJczjXqMYvOxKA009f8pCARmm7m4u3Qk4VA1YcLiKYZGSS+xMO5HityI0tTFRVC4t6t5ihNyG+/Na41lguHvBzdap9W+4C+tNke26nhpIMcmmvqGnSerFgo5kekBmxpSClIuArEa2KKehU2JAdb8XC4KJfP4M30iE+R+9M+yUf5axI0kF1V/eg/tc70bi7oOjxttV83a13yAzvyaky25IyWfoDENjg8UoaxgAZefgynFUBGEBxYOilZeG6yoWp3beTVj3amxnIShwZInGtCkOBRb8i9d53ZwdCP8NmxDiHSfembqY4F2H6oPadnr7mAyijHHeIQBy8mB1sI3Dwes/6RFQugca8g7RtQHMwNdiRoEpFaxk68xy13T81AQqQi4tjqvCsgDhztlwpR3gy8IElGpkrOJjaHfDgksbO+p+0v5LuyY5+RAj2rnjynBsSro3bEXvfGctjFPWy7vFympqp6aghkuTABygbMtk0TASZ734I0ZCd8mKzG1eTwaF1YpwHInZ5nP+7npYzjiFzDPXX5EpZ5awLjQBGKURWioRWNCYpVAikChYTEuQqDXUFGjgb0ybn2T9s0AeTSPsO1ddEAxSqr6NMfgaOekYDx/oXsaaq5xV/nL0jD4tpYzodeBI327/Ztvex5GmndOCCPfw3wKQ7JfbuhCwZPhAqKYm0ewE+tTjxn2fuVkE8lZ0RyZkR9/wxqEVUJBp23eA/utfG01zGIFCRKQUpFZo1PRnkaHlUono5M87IJQPINGBqt/gyc1IwdR6QWscNahQ8HDKZS1E14jH4FXo9hrlXkcx57RKjN8JTwq42psbxekYFIw+QFN/vRWXZG99yAVKpRZeIJw4Mfw7VnDHfNhZmaESY1sPknJOSG2rmJdZi9kKll2OqeafuGMdLDux4cQB6Kw+Vkq89QA8RjQsVCFEHS16V84XYrEgHxUI/bgQD+bIz8dc8Vyl7T7GrXwqP2xh1WstvRaFzomMGmUyFAqQGQCGMdh4eu1zgi7hV9vMFQm+SeY3w4KMgL7oxxvkf7yp55XVz1J+TtML0exG6ijy3i09C45maaRyN0RhxSurHtHFbeMOc2I7rdngdKGVPwsY8RJ9KDRyPyMWcLFDHXSs2cJGfsi7R1qzbrieyo8MGj2VCMIdVedq5Qez8OkqGWfuwLh2FprHsC+zxjqOoePoQITKoL+0azVnNglqFxfCjKriFVRIEIQJpQwwyf/4TK+Jce71nnpgiNi7nmJyxKwIk81pZhkthn7a4Z9OkjU3K5a42mGHBMq93AmBPOTGKrw2YDSGWwo7UwY5Aoxh55VNRHE+1buwJQTO96+e3z2PRzqe6xIzF+cmQg3RoFGAdzLIrtXWuFH5t6hD0LA22SWVJUhw92yQcjyCwCkY9OUzRoR1WcBTDRjIfGQo6ouzagsZPU4vqAFA45MCNjHn9EHOBYwZ6fFehRf9eSvjaZmevB/bhYHRr7cbLNEEiSoFnNtRbQ2GdkvO+/tpPWWuqx93NFZyFm+/h2VPc1z0j2X2uB4cGVgQFFDTfTpcORERVNL27p6fPvX9zd3d7++uuvv/32GPrtN/vj9vbu7sX3zy+FTwPf8GeI8QBGb+yq3LWdQRREIk8BiedS/TPEIgGi3aDE5Jw+PJuMKxd7F+3x04vDMc800KQro5ejyRmSOc9eJhogdgKQtfcaDJalbglsj4enmx3DUlYk8uUKw7DU+11xCUqwKBwiBUcIM10ZbD4/Gk9R9eFK0EhF6vWYqBQAwWPckdruWoA0OYfDF4Q+ef7i7vbXx/fSr7d3L368+BuyZltis7OS4gIcA4YAEasNILu9rvHMJhR7lJGeeQJyj0gZbc6+usexqddjRMN/GohMz9rwmD1dfccCjsxiqQFlC4fLvybgE9A8BMNlryNJYzzj4Tg1IoKPgDA3YPNJP6qewmSV5G4Qqew1Pa/A0WjbgO2hHmOuFoVDYVEj7dmy4GpyY6OTlTcDGLeQfPp9h+L9sPzhF231NhUp/XgBj56iwVgLkM1Ur5U+/nacWgv1lIS1dPYyc8/PDo7r5uEtgUQwmAU+vB5JYm8bDP2iEORuxSswjIJc4zMgJQ2HjDdbqymyWcE+9RdiqtuOhb2KzI7Xa1He1dTlMOTw8bfS1wFImJ6Odj0W+QQg4SASYXIzHJcv4FdY5PC7/NCw+AqofPH8SW5Z4NEI5x4utnvZUAckaFwNN4gEeYua1B9dM7adw32COHiEcdEsUpg6FrRVkwLIJK4KiKfVRuw6DVMjxvtRsUc33y2BTbxHhbjcWvnjQOPgNaJi01roogpzZbJh8IAiptoQuYZ7YJDstQogZ3Pt16XhlXB4ZgkR2tQVYEQQh5yrHmHQ5cUtz8S/Q78ZKA2SeDRekAsc0Yx4N0bwDkjDGVIz9gyQ4dQIluXUBEg7rfu5TvIzQPGEACCkfcNDMdZy9sPwHo/1dBymdw0Ln8YVpPTjyrOUIodUgMVcGrd415D3KkBNQWKmueFb49gIieJR+HgNSywKiW2ovWbtIQRHEblCA2c8G+FZBdn3xXk5rnYhJf14h2b8J+jXux+p8DG6qCCX2gqstjRkV4scFmkGLBUK5wfJswnTvY1AbvqvQSIc0Sg040+evp5Xz7yTLYYcWet4QKqrS4js5noIZQjhAqYqxJ0nGDHZ84QKDUwxqdJH41AvOPN6iu2ACkXEwWWkDPcEHBXvcb5rLUTYF+pxTyryKROt8eGGxqYa/66i/OGCjozYuDsz3Ip+AZCJQwkcakCIfy3ULWOlgviX8xm5CxrTSAuKstebuI+RezF2r94ZRMJRhvrn7s4Ijp4nNKnMdWpJrhMe4WBSiLQ/NJ9CU3xoL1SukF+fbwYes+ixF1OkjvR+riXYY3J9P7L8WsNxNZW0Q1LNXNKLkkpd28GPnj2ZfxyNwuSPSmNfTGK0x00aclWNdeX4p34u1fhwdlPtp90zbeBeITLFbjvXois1JDfUJNhU+/WapREeuW19GlCodKEdkVfj2k9jSPmivmeIGY7py8waccXjdWVoKMj903A4QypAZI3HBYx94B4qUrs0uSUSC4xZU5FwPHe0sdNU42aT4c2LjaX+52z3c5oMhUEuAuRxI5IqH9GNbq+n+eEaBYnYzX8sDdnz130SJJiMeM/4CZJ4MvyApoI9nXhCCoU93gNpAuRmJ5Iw6RYbwSSp9K5NyMUOcUwV9qaFNNZRIR5HaUK4ES2vp+NSpCVrgLhR963h1OSa0E6FEyCGIIldFvvH28f/Mt3+ECkaD43bRfSLAFkXJuNmd5fb7kDmOEHc4EjBUZfuzIBDhR35u7VgZ6SHG4tnBktn+wBELf1QeXjDY5SHU40LFIdolMuvqfBBQVbCsI03868lZezPhGIepj+ualFXvRyjwbAmNncsYqkdkn0cAIJAD4y7O9MIv60WGxTS7FptM/Y9RTn+6/Tb3XMvraBc3JEoQCaRmEFka1d2vQLKdTDufnazasKXLHYvf9x0K2h4ONCjBtLjj5zdrg/g523YfOtIewTqEUBSlQsYl8BPM9uaH46CNA05PoGx7LVWK0hJtgdkpAlh9rUZ4p6bqaHNAFJvR6TX9kQhBUZbpT2rk/0mH6712xol5dQMttvpmAkQMZ673x//V3T7YyhIqHvZAFGVFXDst8ak+FeYhHUChzNrTg3CKeRSR8GnBkO+cYiJL2BcbwlHLm0ju30+BjIQ2Yj0tWcNa9Te+LwUd67viR/2Ovchwe1+qKYgGj6ACQYVhpzGSZVHAwyhrMtt/rX3z6jDcMVj9LuCxcGx13JsDhlD5j+CxxyP+xxb/d/R7fftBfkLgMzII2AMNFYd+AhAQqdlZv39GCDspHH2XUVqnJRJJbGjDBLIJSAPFbkUVBj3vxpFBSQOtpLXvaoiEoWRv4ahHn2EOAx6Xz5NhMSBJMhcXo8gkk/vxp7B1hMysQjbmewhFPVJa93HAdDSNS7CoC4TMW8vq83+YzgKkgBR/FEvhfT0jFEa6mamZ41ZJLW43YYUWAzBSSLgSI7GBPfs5XJUzvXh60Ap6UaOs4WyNHx8ma1JMK4tr0DSKNZ0RbFZDgWQeoQjFQbvZjtyM5Ge6UAEjDUIgApxLnwnAUi1XXPdxXtip+b4MjlTxF35mWykwb++/NdwlOF2klNTwR6VVsDnACQ80CksxjmSDDWnp6+5rY7M6lvbgRhIGp7NljRHSvW4DZRgEMqWV+TgbZsmIZ85X+jhR+OFSeY/YqH5o7nYQiMRcWBYcchOFX7k8QgdQFnLXaOqwmGoN+RMlFLwgKzU9eTMNP2YrVz/Dxz3kHwUU3sSkHg0oDJKIoXEZMLhluTTNHNdTOrRDbWiPtSdweIFaUQEkm8mFOT4JgguZeI0uXoVZK2/Fq37uVxLaj4F5pprKUf5NFVOgexeTSaw05FRCaTIC3vUiV21Zl0/4lwbGlVIcZIxjG3D/obkKiBuRojn0Mcnd4//V7p9vrwhq5sLqfrHHADJe3KuMeOyJTCYbYYNjOnM5HdSkZteNXP2otasK0apxJRKGfYJkCSz5VLD+ZaZe26ylZ9xzTgpR8y1XGsN8OETDX0YAlBOCezDRKnx4/XYOl25aUGXCsThfWwzVlpZ7HBpVE4hAouEH51ekJP534ggUAGS1GHCscKPbNZsswAAZd5PDTV3/jjZiaSys906djDp3BEJ203JzU4uedlGzbvm8zAkJrt+UElfrbBEfHCyBUagOE2nUHVPT9BQ2DM8axVTLEyA/CBzM0Lilr4IN8Z524akFLZj72030zozXQ1E1v7CH399/ADo1xfAMXPZSmS/ywcSTdglR0kpm42YG2sESWitfuwVFbBVNfIBRI1+HH/LmSFF0+vNyl6fl1TYj2h4z1r3XeyqDZ8XvRoDjTWSlJqKMNOI5s6kvX6/6cWkTNAMs515QvgZHOFTJFy4LO/aOwzjDSkFKdJUXJSknWe3jx8IDbv9Cyb767LZ2ctFjU9gsYe/T10Z+CSOwZ7WSRMBnryUpvT6MgQ/EDmrRiPNac4veYs/SjE6MnsLdrQrEPDJDmxwSI3PkSrmCAax3YLi1O5KvGcQdz6pRw7s8Gzs+WsvxJU30+ebwfyHeS7eZu6FaryKior/31qvdvuXMNlVIW5fVJuRKwSGbTDFAk2RIpBNO7bJ9vMAccV7/GcHPALOdX44rYXHNyTkUoQjU0Z78qqHBJrKXRvzYSn2RTdXNizM8XDUo1lr45PRlpwxmWAEg4g2uZl63OvCo96Q7m5rG3u2ciH9GdlhyavRAz7pzHC2KWxuBsrLg1GPYbfxt9GQivVgnlt7IX+0maTdoREed/vi4pOpnokWmui8HsAElqRopBzbRfjrLQtZjRvxR4V8xk2q0fd9eEmF/OvhzgBLFYmnxTauogq0ZTPX5tEY/ManBkN+B4cmrLZjUVmaPhLAk4bL27H7NCAyU9d7a53EhIoXvz9+aHRH2IdK3KgzK6sNJGH+g51Pxm372BHzYFytL+zdhYHGcYAjBlvZ6767sO13jfOWvGu4f2p3VSmkKFQk7dflYDMvZVliCK82V8HRL0t+Rks/QkUe09eAEWutijOg2Gbkvs3nIR/7waCUajC0g2ttnzIzxYTE2If05IGpx3xJUlwRJWeaHg44odWJ4TuBpKop4EKi7j3ao8S173eVq03iWpBUBSQfHo3GpHDWaHgJA2HZ7D6+h1xh6MgK9eDLfEIQUoR2DDR2xQj5ICm4LDT8aKwBpTAZ6nHVjEDRmH1qVZCWbAkaEtigUVBs9pqaCmPfP6DX40y/vTANmWns8GbU1QUWSyLu2TvMJ+pTKtYgJAlD/aHSx/SuqTw70rqly+4nDjYHdiyo4KqJzTmdQhqS/IywmJz260+yEretZIcN0sKPWkbTUAkaMwapERUI6G2FIPGvB99mZxyHaEgZ664b4VfezXX3+MFS5LIx1ChL145DHLMzfA2Gktv9CrgxIU51JIabZ2O2dIHEAGVMkvq5HBv7tN+1D+8Bhd4/k3nrkym5seMDOGqePXLVjl/F6EcM9vmCBd6Ng9lRbQ9nsdlUh6vntXW+VjcXWESsm+JWjwZfBsut/AzfSQ/NzYOIPZ4B0hfQAESO+hSMllj4+YYuZWf4p/tHSgmLuoDFt6L3mlhkTG4WaR972u7u0OR2rrkWl2uLPgJJ3GzNDuf5SHvhNGsPAbVJKcJi1UBGg6Fc7ICk8BhsLsiFryObqX9EQwJBKOtyW0gchWiXdGi6RxMG2y4/PFBznRqytg2r0kcrDBFJ7drGNp9v5zqhaeeHk+TA5koVgoSZ4CaLrfHhSCrO8HBkqCWHXsxkoWbt2ccL0g9qUTlD/t641soYIjN/zcdpCz/ovtYI8X29mYfDq+gRQHbSGmx0Yy8Ph2Iy7gM31wHIxCLDSGWfd7HHriIlhEdBsurN4r5DJCu6BEnMtv25xMOjMtx+eDaqxYUclFKPURwONGcgcoGqEJdsITdejqhIoBhF4gIjqrFmSp020YBFkxEaLz9baISw2p6e6UUV2OpQktk7I+UoEhTtZMJQVIoyEzPseH2Q3vUMSLfT4+PVOGesZ8/mvKCCX1prxBqCVPyRT3kZL+wBfTH50b5lVLNd0YrGMdSZndFdWLSL4U+p64yHR6CnPR/5UJAUP3rQsWLhij/GsjgcmiBBcYqFI67tJkNdm4cPVT6aUzF4Xx2HxaZTgSyN8jPwmRhGSgmkyfNw+De13/VBPx9DQxKGjOk9kOtDgTNpP/qx/uikvYUIqACpQbnjj3g/ohkHn5OFEm9Mq5GW0kc4OAxpZLzi4Q2S5AoB5OBVH+6AVInPV6Ug8WsWzYjKXOI9aEQ4R661mq8J9CjSo4ejno/8TJKhsbtKw+H8XbrRkKgNNAr5NEcmQPn8QT8f6w3JAXv5fJRGlF+zTxXaDybvegtKTtFPWjk8rURKZ6YvoClsFhQFwxZ+jMoeTilH/l61I/aaz8M9GlChelyHI0lDoVGtr0cdSQONgj1BXDItY0ftM+c7kfzxCKkgd/t8VJwHQJ4POTPxw+OHT488fy3daFfV4AqK+8k9XJUy3CWw90pSwITwYCimQEc2RDoQt42u/KvUolnqCocr9niUsQ3J1w7XLAC+T4IDR23VRGgIZKcaj6tpKfpAZKARSY8hgPwzl6YiPKBSurJi4bVfQUNT2lwA1UC+ePwaEHHInJjiuFTJGbfzGp85zBP2e6se24bXzFp7doY/iUDGgldZ7BmT/IxWTK7LhuFAEWrjzUSlFj0ayecZQ9i8XkElZ9jp7URSUtcxTkpjm+Grf+2Y3AxLkW7k4RgDcpWe0QU4Br2Z/rXMNaKuV9rJ/sDdazk1tCzwVY2P6isW273tVZDJFvVKyP2+OBhQjAz2+KvtRCo4aqfmikcRaZnxHWLhKqeA8X701gXiPXy42ZScaVoK0n6LWvyqB8TDn0Zyaw2Gmba2S0GR32EUKfFH7PO4ymYHcafwERldXRppL7FoRxOvBx4NkDQXVnk4TMHw+5YNn6FRw5odkfv4I0D0K/qxb/sAhYlMFVAsYwGERCYBINchkC3kE+0z9sU4AJLYgz7ZbfxwQKqcgr+WCeKHerP6VpeGkrPsLUQ4IWuQfVbkTonCkiIvqCD26GyfwK7ZuA893DM7NbGFRl423314VMKwj6hAKSJWLHbdCBDtZ0IJmiD86lCLkaDpUCw8ZgP2EI5FmGpylS6kvzDKwzXZbIhWbAYCVVAhIHJRBjuAqepHkfCYr0dhcN2HlCvZca7Vft0oRz8azzyhAGm3JI0Qf23waBqSbhq9HE9rcM/ekI1yFgA82bGEIuwzFx8GoCmQXCDgyMQ94xXu4fAtaMSdkXqUuZ41JCg0DhRBo6dn1EYjxQgo96s+uGKr1bBQVeFwPuExeAbBa8ZZ82WAIphcZto39zq3vOrteD5G/PXRjwZI8jNgDeOtbi7dT2ofNbC547InZ34Sp9E1tCOPR7/GiNxdujBLzdLjhm0I2L3B1/fFqSTXDu/I8LA5aumaayoIPmKqz/e8XtunGLiJ5NrqaqLCPFxb9nruMHT4VYJm8EaMp3AgZvbaqFQlVPmZB5+emQGpEooP5zauHhPvzrUdededNI7UkaiuBTUWQtlgiPEeBNfjMe00gqOiM4dhaUk8arUpyGALkfKrY/81KUPN2psy2FUc3nq5dPHycI+H8+vTUmqhpgk51n1yM3FwyFGI5LYLQYI/fpwQx3j4AOTrhEcAGSD8cG1WeMmG1w7Id+TW9Ij4Oh2gYMmYCvs1UiUFl3C41wBkcs03k5O9o8/DchNwRBwUJIlCrPbUfy1Mrh6NNyuczQNQSByxn2bPiLP6vigdydFNaPSOBQ0Ph8F7CeTrEu+Z45DyrU0s6cO9c52iTHUIBR7z7OGoWQDDXuPKEBm3b31Aaqa9Y7A/H6Ec3+M33GtBkj/BYYySIlMThhpYEniEJxkEEQQhMdl80o9hrGEmBMeQBxVZw5qTc0SORCNlZeRer1CEZ58rpNAj92M4/PXCo4d9gGEc2J/N2tO7kXPSZtjKH4XK0I6BSZybAiFSU0j5FHi0L5no00PSUD7NlgYCsdkJRaof4eHRAMZQi345ejMwA+LgwBIIgscWfBxsyLUqPHwa4TFYwq/NfhQis5Zi8FUtxlVwZBbpa5GfWUx25guN2uAetR2u9RS6NWfGGLwPpyj3OpI0FQn3CRXcGunhuIBShGYs/9okpKjPYR4AeCyPxijiPfMb8n032SaqDXs3DoDynnBpVBquxKEMNgFxQpDpZHNZ5kkBSc0DSGG/fQQS/ClDo4y2BgKMy/ePXy96lFMB4FxUEbkN9QiNu/rHeUQu337FAkCUR+PuDN+y/xo4/rxOAlBLtlwZ+6m+Z58sVBEkGUMnD4vTtLAGwmPBggy1XRogmY9bQOSDt2ozMEjJmbwZ/liJ5utyabo7g60GkLB6QxrtN9CYfP74NSMC46AxTpsEeY/pbtSrHwVKNXZVvIcKSEKRGkcKFlseGwyGmBtejXG8+3oKOyIFRuy1pkCaIFnIbw33JAsggsXeRHPNx1MygHgyCnKO+mih5qA01SFrbvOgCZaFRyy1X8GcNsb19ddDXD19+PVmG5OtaoqZQGmndcfCbsBZnIbHdKmRXlCRQfG3kIdZUrBQiHJq7N59GlbQaFIKhBQaY0GXxlPQOFPTe0SEwo3BCT1W3rCN77GPnq5EIUf0QfgzoO9a1WZc7PSRpFhqje4J0QsqylwLjrt+hScPvh53A0gt/uhFuVx3QR9YX6upYQB22zUsxMlGhSztqS3YoA8stsozoTDucmP8rlpcOw2PX4LGwQBkBSEZUtEmQNqnlR9+7OsdNBT6FAyx2S1fSLeC/Q4jU5aFmkZR4DP7MrpDNR4XMAJFGeqGytF//ToFIKUhA3q9oWuLRhh8Y61P/Ws8ayZLGc/9roPSnVEsXDTVmRVfrlhqY9wqgT14fnAsdY7GzQniKEYtwZ7bZ3Bn1GJ4ut8VKM4edney8bPRiBpPEUzk7VxaYMjXFn4Mimh4Hn67HmzP0LwuBT4rIDVUr4/GrT8FSEXFm0cTTGBsdbgpsdk5y166cY0/ro0zbVazxgDkFuzKW++jPUwEcJvtmUJjvCKzr2tuV4DvFKMG2mvl8NRl2LoWwpeBHJS9GNffjs5lohE9gc1STUGwD8cVKv8g70xybSliIMoy6AUM6JEAIToxY/97wu+4icyKLAEzbuGbZef7fxqy0/2rOdiTqVHoUfYaeVaQqqrYn5CqfYSL/Cn5QbLehORLupSeQfQD0ogNr6kPIc0jFREHXyadcYLwbehaUDg8P41/RHI1UP4464ab70SkB5FhR3Vh86fwyA8wfiYg1sXTM+z70Ng9g2R7NbEh7uUcmgTkqhrvUjRqdJ1guGvHCT8KfLr9ACP6uGZqKkuT/YWK98ihgZTMRkJKFgYmC4kCI2Lf8AogZ1ZKCNSiaFzrYD3Gx70ZdOLkaXqgPfbaqQf3oBthViDeQciw0duOLmFSaGQWaUiZaW6Ac50GUOvYX8+hAZDzfIRv64eT3F5rLqkQqS5s92TE5GR/QCdNbTA8r/zwSI/Z7GSjGTUo1zRkmuoQ7dDkso81/DhXsJjH3o5wzHWSfJk48q5LgkE+L8aFcnJPsGnqSiA6IN9Pc71FwhcaSILJD1+mY+EASJFc7dvhFMoanqfaW/q6Qo6JxCkNz0uIQ3qmynGvNWZA0odU0M6l7TM+zR57XTsMSz3yMW4ProKKJE2n8PxMR3u2XUiY7LqOvUYwQ1wbFowajkiCPrcLkbr9urPW1mpYxprpFMF/ffc1CZNtbvVtG3YJH5jC1bcYsulDSFyhSeljCAuBUyHOGmy1Gp4rcnsaKfK44BUkMjOF26DxG+3mUsIwh9qvzjVCpJHN2Gr1c1mwB1KGUM9HiAm56qPRbtd0r+sqOBL/DkE8PIsehcTmBMKDwz788iUfkGWytahL3FUj3xr4OXdywfV0LFCGqpzumdrFHtzLcQuFmlRxSwE+IKkebO2M49eAREWiIHuuPWiUxd6MtdZqxkHu3QrkrgOHcGVm/O1YHjbgsyHiNa25d7xWN9cb92qzmm2GsX67gT8h8mvL0AS9UMuCAbJRKIfGCfTVFeJf9nC4YGnrXWcLtlI0H7h21F4FXBrbFecjzmru3n36mrbCWsceAgoxJWcYbGUKq8UQBE7C0BYs5CcHW7BcKIPhPW+Pw9UNtja83hXj4s0U9CqFbXMqBpG54PXDFyvxOcQhreyMm83cw6Exg73U4QqPEjCgiU4kiZ2Q5Eg78iUmG4vckXxKFnaWBja+NWfbroAfAweMnZy5bsHOcHiAMW5qVXCi6gxL7U2G+xLDYMHxq53UZFjlPYIivISaXROA1sklLIoHIn/5780P/xeAnETN3Tj7Zg1FmLe8evr6bU5zcF6Pqj+r0bhA0rbFUYqrWopmXnUGDINf9yqUVABShRT1hgSRl2Qhi+KQmOlt77CI2biYa43GvSHwiNlGL/bXAjemx9kHn9wMTBc9IunF3rsVuDcStUvztXpoHJBah30mmWrfxi6hcjMfRqqQT/rUNCzY63FPGCJ1hEPdOP1kdPXIrBQMdsg21GovjJ8i4unTjHsNJD1HkxW5vCBlqPeB9kFYbC6cttky3L6FBk8GfnGuCYXXXPt+PSY/bIxT0OcVZviITEP+fef13Xou2ODSll/vnV09A7IBSc/raUIFtFjs08xmEjT1foSHhCGgwKFGpmTIh7xMRSAXUto69aPIXOx2ZeRaS26oVBQcZtQpGhQkhOX2iDhM269TeCwyHJmJib+shw0gPYvtkR6Z60MHTR0vf+zcTPDKy7RvPXObBUZEakcEB1JfF9S1j3m1VcNcxrPWhArgSA4b/kWjUt7MJAq1wHDvwO789VbVo0ZDdRYCxrHWTkQeycvMlmEr8YEI81T+egy1inyaNM0e/fiKNT7mZd8tvhYcoZS7oVbjggNSQwFCwtSwsOdo3qbjAkzE8miELWicJ+TUmwmQFgzPaE+cqcoFjIyBjJPEZFw0Y1yVoDllsW3uI9I7DONoeyHfjki9Irvg0S02lHBkj6GQ6NNS4pfibRn7q4bEC5BaAWKkFGF9R9LjESG/mtij8jTwIEAZ3yVVyDfOtOx0/S33Oni2zlTu+hzvWcpyqYJU1yuKEbZWQPa+D4v1NLHgtYf4VEXF2ZOJ1Ayx8RWJPqKiAMgnGO4VZ8Gn5mwr7vFV7LU1Lm7fv2YOW4CszPVt9aN3K3iGxmt6Vmog1voZEFld2NqmuepKhXqERxGxRy7a+eHlZqhILVio2WbEH4GlwEhvYU9t9pWaAiT+9bouzsfaf4ahBpk3sx9JW4fIYgpIOKyrel3fWOYMe7Fmx31sHClg/PD9Fw5Byqk5WW31FsqpQYgw2PfN16UfYUwiBYWksLdys0Yk4AOOc/gtXnW3ciHRkHyWwCbwmJ5MwREBIoHk0MR7ND7cpkm1sabFcHa88kk3joxb4lEdrzsgNQzgM0HQ22fg6EYMNnRrrJPCYr+2RwMgrVvB35F3gFTF2cnJ/gGupgUQGZz34980vA4S93G5mgcgLMY5TvABkrPxAwWZAyr4Go21kl1VZiVgcmcQWocE25UjiASI3e6qujPTkUHKE65BcX9B0rFQcXEIaR3YqMrYOPyqRT4CpGohz92uVQTpNrsDPnu7K5+iPphqKCRhHnwZW/mx9XNJN+5YLAHLmI8gCW9rXUFIuTKY6qmngDJjPQPOBEeEZQvjB3npoxBZs3Grw7CPk3pdrTxc10AhWCQavkd7YJzOX1eZT9x/fvfF6Z3bugorMvNZzdy8wqd3u46GREFW7LGYtdBoqhkfNO6N4uHgLkM/cdFq9s2dgXoJTbAaAonY50BWmjAvk55xRPJ+lFJ0qg0LcdSoYDUVZaw7eV3xcKWxmykaXuXhCoUjvOcV9RgvyNctqtiavOL79xvZETsUzWrDqpMrpN6OR3vdF2+gkWpsu63mwpPFBoQTeqyNcYBxVCR2OtVj3BV53BUlWASP5lrzl5Qjsru6pBpP+6+DugMbXJ5XIr3PsJRWjUgbB/C9LhRVfP/Hu69OaMiGo1lrtS14hkZbuk4uNuHw8mtwY4LjzfgGGlLYeNZyYpxwaOBcppFmTxl25WPV46IfgaR8mW8KjnFQjMAS/LVb4/NSEo6fenEPKFTvTFb3aN/weDa7vW4F2UB00h6aHnImWtMzKT6kCPLVBu/dviFvtyzIheHmG+M4IgPlD0snNra6anycVNDDRfSBIuLa+7G9Gf2Pzs6gJdVEgzcTR7Mp4kNPJvhODTQsQuosTY+nsPrwz2YC5DJQquU2QfxNMM2eH8RVsMzgYzvYkJ6Q5mF/SDkFFZDh0bz+C7LLzyCHY/1O/oxrRt/T1YMf43R+pslD4kFrF9fNEmwWasanTOFxK3tFetZ8ISls8FhgBI7V8yr9qOEAZAnLZtNgGJeijkUqHM4v7m6m+UPJmepVgK1QRFwLK0Ahv5CIC31YNT6BxfheuCzXUoeitbmwYOmkt6OuoLBqw7HXmS5UsEe+9TK9R8lq7mtTl9WafVK3FY/HDE3OTFlmAqAgwaTVVMw2TQ5QtA1djb9i0MgKPNZEAB+P6+0zrPzIgI/WIiV1SXgOJC0wasmCzSJFO2Kv43z4cpOlzoB0Bxs06gTzjewIW36tP6pYPNuvkRkR5wDFej7ukXFr5tL08Jr9qFD4iktw2OnC6i4EkGDRpknBqX6Exre26sc82u3qswA0rTl49V8LmHyQtGNIDPZ5WgrT9hDZgt3q0XtoJlnI3OZX7lu4mGwnhR6v4XDN2nuTUo9EH8HglIr3QnaKzbhuAXGlDRuJ3MxQy7cOIiQOJo+zmslcd0gcKC5NC8pgf9pvyNGQzUXzdsxLmejTMnYNA4BmiA/HdCRq0tEI10akvK1DxGG2vxBEsocmzk/vPoAKkD7aDOJutLVgw9RB83ZgS8FZrufyXGFuvw6hN+TcrL8QvzpkQZFLCBuYkpBcx9qXrVb6miYF2l17SMW2VlOEh90wBJKchqZasNfNChBXa+r6iGRh0BoHt+XX7dJYqMeI52NwPJqX7cR2QAqPB1g2B4DCo03Hpd2V092uMy03TpD2Kyjag2g2jjW/om24GX3Y6r82b4bsdRBMLdhxV4IGpql7gNFM9uARMYNSuPnox0AltnobIgVARSyeUfQxzmk7lyacralCbzCEVHIW4vsQL57FVgvDtfFamlEXZWa49G4kS1+TLiz9yNc1PmrqKpcmjvCo2Y9urltFjrG2BHaNaw5JwKcBmaP21KywKsgNh7BtXVxjMSjLKZZFNBbt6ZlSnwmTvsOQj+k9wJGP6wJG9KOi4u3RQPyhx+OHXDMank72q5f57BXjKgoXBPcXJGjkYkXitQ2JNa/cuv81qFIzXCArEpc+5OYEFqk52+vDxaDun6l5AMFnfrgwCR4rf00LjSYCeLMrYNSCBYV8pB3hyygAuHKHBcgSdGF3LS7sMD4cRM7+Qg3f24hAOCjsGOTLzvJxQIom7thW+24Pu+0cXtexVya7d8+gLKvWR3CEs2yhULjPqNjbFbDWwaUXjbLxusdJxa9yM2OsRdmsEPJNwA4D7bsCEvjpF4QYKJK7Do5QUNxUJLa6C3PbXMN3NGaFuKrD+dko0mbx4dEAyJccvmfkgFQJZF+cLmCUW423rZlS6c4EjxMyzoxq1qsx+QJNpPIzvV5hfTZaE803aazHuw42vYXfXfAYPyI++YC0alwteGWKzzqMFOobfdfBU2qivTd2VUHFrKCJzxOH8mqAppTiepvoY3AkJbnQA7KGBUh3aI6jmpfLfYm4PBlND1cwvEdSBEtSY6HIR5JysNWC5L7fNVu5uoMGPDItpXa8qsuQ3Ez615MtXPchyV7TstDrr+XWBLf5FEQhu3/Gxu6JsNj1S/KVw/DeieRY7NT1ki/sytxf3n0GFSD33Vx8lsKGCpH7sGYFHguSrR0rDCkHW/Za/gzShtmPyYYLftw4/EAkPyLjaEilDQOS+8jmttVxkz9jRNKQ3mtYQdEGiANDruDvPC/lo6qn6Fh48HZsDI/jyGCwBUn+zadUZFQcSL5+Ya4Bsmmca+lI+TLSkfZ+FBYhTDQ/zLUmkVZxD392XqZgaQXivfED+I2OtPcjHQvI6lqo8wZG4Cj92PNIQeO+i70lCjH4DBJfi87sAZkujUXDC6LfcgBkmWoRfwiLs46dU8TFsPghSEyz3XnsF2/tOmvIloqL+9PRm7DLn+4umnFiQkxBhc1rLva7xvicd7KDwPcajSGOBT7ZeM3HT0uwy7+Wg53rkOJaQFTUZw33RKkZqFyHP57XvGKxE31C5vp6bFiOa73Bcp+QWzlsDTfbcKl0IXa7gEhQ/Blp7ASkgCgfxmemKGN4GpGLO9OxHkLghUqNyDVS2tpJGxZmHZIGVAw4BUeCPRMGV49hSFpf0Ym9lJ0EDSCcUbmXhi5uQLIbCz0YPtcK8Sjg4xObOTPajO+AyN6zAPkwAGEStQjDXCcyn2KxLxpSoceblgVvV0BMo0KWhqdijH+03kJtwO6d7MUktd4VSIJBeTJcdzyy9EPDmksvgk6bIA4Ct5XDCFEOx42L9rsWKAXM3BM3uwuDpCCFxeRdHa5ZALCjwS4HeyKQnCt1B3arR+j7Z2RpGpCa1gwPcVNu5gEfls5wfps9XXKvacK+QBK1WDc1K9hCTZi8GTUZ1l+VuRa1q41yxMEO1WgJGmy1GhbScstiz9FEe6Wvl8fjfHsproQaXguHyMTijYLcuq4R7eIoc13dXPGxqEux8deeVnEAJB9HlttSM2axyV+DShq74qSW5D+tfaY8moBj8A6Ki+ovTbIXKsdij3oUDsleI1pBwgOQwaz8ERebU5D0CRUgMl0Zzt3MFF6Qej9ysfrcCTtOUUV8QzZxj/BjnrvkNYAkBBkc7fiE5tcdkAr2cEHKi+HC5/kZwBgMKBYaKyvDW/LYsaASnxDyrXc8apYUTrYMNyxlmWpekXF4P9LOFcz2u/YHDi15PQa7IuGfatWwE+Zas/YUDxccVeGz79M8l/lQZwYYFX7kwm2wiKHGnWEIZKUMgx5SV5GABIFjsePe0keSCoxL9zWkiaRBXPItmXDUKNKe2TzjAJou5ppXJBCsDprzJJ/v1M+Fa03YMThoJIW9DSVlXrNKw3WgGgWAfsyGhfzl8R5s6imCw4akJ0HiR8U1yt5SNF8DSFh42Z2+VmMX4rJlAT8Gjlvz4vOlroCc8RTcrqs0EXy7N6ObOhYowgWPHe9ZE9g1bg9/BmmDe6oDG45jkzGfQWGL5d1IUW4t50KSvi5z/d2kClnKHpf8xmSLq9iM3zwef7R2BSKPb2wfHs65EgN8aoD4vbEmfU3JWQLx7F3PeDNGQaquIug5PjYmu+op+O4nnNXZSRpSqrKnkVp5D5+aaYRBXUSBupqYUvY6jlXjwuM0GINygeH14VgXApDIstxmr3soAOhzm/0Z4x/VgS0Y+mTcCfqolMLWsoNC9GPQuDDIw0D7bp/BUI/FDvaQQp8EpCI+MJFryvXhyCzSAaKmP8JJ0XC83kzDH63dFcVIcQ93VKRNptgrfkjQgEaFHzHZAqRM9rLBUJnsbdmwBu5teUL+VPQRjdhF4sFs1h6Q5KI2Ljk3e/1jse7oKjpBsgtywaSqzkJ++e5zCA2pNCFCpH5XXWSqJyb+A65NdV/3M1LzUmCK8QQhptHw2O0a3+zUVACysPgNXzYsgEZ5171lIVGoDxjOPHsrgOwSyFo3DC69nCJThdX3uhb2eIFPn+u0FAs/9gwfLUS6acIOYkiuIpDFXnqmuAOSIE+y+USlGW2rJoLIeFc+hoD1lNxlQoUsdaKPqynIcWW6xgfszV7Nor5gr9XtChQDh7jYu3rEk8Fid+xRnoyHfKBSkHwrHMe1BpDtW2O4vZkrGFzFPfXJte72wvSuTUFakU8610G8JVM8p/JMgPQVNEE2nCKum35Uz0zjMLsV8l/tBSk2dbkJTivvQcAEQF0LjvRe97TmuO/NroPKT/sdKUAmGFt28roLz3oUqRCpDE2PTWmdCPMMTWCQu9wZpI1sDkAuq9l7hA+EFKVzTdiHfKH8Gf58TtBn3pAQgBQafcGrIj7T7Qoe4dSGMxMg74NESYx05wwRSOFxm0paqWvfyf5NNdFQbxZHDV1780wiUtsLtygPl3auq3MGPhMgPfxYPjbdNEpgH1eyf6R97KAQy30w2r1wuPBolrpO14e3Q1MHek5hRQJSWZoLSSdyHSMNFpOp45XcdYbFK97jg/ZaSEGKJjcTH+2Fl+WudRP1JIBZP0P2+jJrr3OGGfOZhKFHe5CfVzz8XN2Ti+K4zNphyKLhE3gMDXnfPgMcCfVMOxfMKnzKk4kfjnYDUsHIZ3R3NSBbNxaTsRbbXo8/NGsb/Rtvx2l4beXoMR/M8/CrekQtculxpN1eCKkNWx4Nj0ecbG56Ow4oyRUmHttK+964yV7HkVcNu9SHwzoervrw/fkYTMPDvTpceOR733q5gvvIlOqc4Sjq86zmhQakz+8RFlVTYfHwMtRQWmw866S5qGXBVyIZERTvhq73xp/xKT4Y6lKSnAqHy8EeRO4vSM1tPszILXPNz4miHvhAcTPYSNCIN4Na9NejWhV000xSbl6RWxuHq9MQILZ8ULvhqiG9+1UzfGynJkz+dRwSMzCCPltB7ja7Zxtl7zTGmsJczfAZUv0jRMznkzHXwVblWGObKQ+n4/Vu90wzXJlgai5U9HHfsgAm71YswCYxo3IKU5Bqd12bFXznR/rWKYRC6ctHTFARIM/Px/ykHGEizHVJrr3qA1DadIr3+Dz0KFx+AteGVxXhergH0sYP/OvcP7MWVFTxLVeQWRPOuG4uDaKMNijkbCZbnYUAMbiZ6zbY/LjgxtynDcHjrhlNO/JRTJFRH+lG0VP6XwVI23+tEh/bFxd0yRmmO0Ora3wXPLa91hjIfSiAb9Ik1hMXFVLYLmxej13dEwSv7Vwh9wGQXXKWQKzbbquzw1DNCoqJQ0oWtnYEkMMLioKkFtCca3FhtS6uYuGDTFuIROt1LWVHbi/IpyWyAaQnsVVOYeoREPZcCj7AyB1LDSZ3SAJF9XLVz5eyk8BGRyp/vVc/atyeWmhqOgVccMzqnroE7fPDzWIH4NSAncTNZ5yJ+hEpSPIDhDwhMdcllb1ukW51NRoGO+/7iJ+GVEgIj98/zKcJQN5MJFX9475ME1HRcPgH1YMt5XjQkN7D5SsMM0vTEOSzuXsdeyy9CDADhQlKrHbrR40Qj6/AuFvrhCIXFUAeY5Czjv3afL3RPiJXTYZwLg3HkLWUXTXhSJsHEAebzfNRTnZB82m1kADyEH4Eioit/1ojpbiDQ2DYfzO82UI+DJZiQ1c/JW1eCgxE9uCUQSJSaGyB2QaPCczrvD0EF4AIJk099jAAADjMqCdUEIbsvkIvqBiqeooWsJ1KM7ZutPoeEVZaYFSGBuL6pMqK0ZB8H1u9GWLL0ShToyHi3dilFQtQYLCKH2d5oQ9s3nsW8Ggu4Z7rmDNCkDLZcWqj5h5+BI/BJlt43BoXBIfaZJt2VB2k2rkg3WW1p5kLeUO9rzAuAiNyiJ7rjPYAybHWk6J5Yp4mAOnpQsDI7TzAh0ckV3QiPwb4xF+7f62Je9rFfksdfcRUL4YbPgsM+TEWAOopFVSc6QX5abCM+YDIdq1TKBg+5T2QCnJFCcOcvDcF4XHErOqsKis0JJdvX/AaAi0pPM5F/Vxgsmw3ulG+DBx6yhS+BZAbybkOYYsVhpaOrio6o+lVYCyBY+1ovNhssBgSKittCpK8TPAMPjYYCYfHuZTkTspQxWbXHYa5massttxqyxfC+smIONb31CkstqnmE72fUfAqy0VJynCvpIVx1WHY+Rk9JB/qZAuQMtP5h3VgqxK3AQkc8azTXocUCZDA8xzu6UFS6MYaBKlojxHjANCIfbDW8W3+9Rf414xtHige+wvpecWP4bvBI80zoSPbYOvTq5FwD6SIODRSNF0zAJJbHJlslVNgqdupDhY0r8dnJg4Xp0ZQhB3p2mDInwnItb1wzxWWN9Mj93xmc78gV9WI9Hau6uhCdPhxdWc+nQz27FfQZABPz/AJgl4AWSWQCcj7lyNWmu7ryhZ6PFw2m5djDzkrLPo8KXDYKwwzCDnvyJUeljhMDSlM8rWi9D3YVIcHLQ2v1cwFt41IkCof65g7g52uwHi/H0N4vAdABhaT3q5Z+fgmsqOLg5qUjUbWVROb42Cutcrw1ERDc+EW8hlm3kz3KwDJPl5tlkvZVzMd0gk0Zp24Io8y10+N+mwmmwM7VUBqSu6gkf7CiUMq0LMD0+b4zE2xxyDgaMHwmUZaG4eD5vk440h7I9Js+6DERxFIyPsV8GeCTfjRt7viygRDV2pMrgUgq8IHBiCT+qrkNagEjRxzZ6qSghMo3Gy1ezTPi/oUID/eYallH/wShNwqca221w/OBCalGWHIEptLQ3NhJrHV6pqfaOw1YfFuWFCR+DfoRU53vY6dRuzbhjX/Ea14nkzBLWRBEGlXnBnmnHkrF/c9bZhQTAYWXS+CxiCQqVnidYIeHPURICuBPXBUnlAOjdoWljk+zATwWXuJSt/D7vb67etqM5SkOzMV6MnFwzOhIo76FQBhGuw3qVozPqERRnsh7a4ZhTRMagwpr0eupR2LDQUGa4i4LRoeQGofUuAvJG9HmFGP3AOIej7e0aMavACkJWk8d83uGZA5/gyXWmH4MXEfq8ftWgqEI1Jjzt5+M03KlmAT6kmPBlYDm1GRIdZkYeauIbzsPUejnGGOkuIiOMYRaT1X+tgqesyrJwzXxdcpfbwZofDun7GJANsS7K7CncqKlb5/PiB5PgqR1lxYhlr5mW2aFFw0mRmKc6UgHZfqNIRVoyvHSioCj0tyJn0aBpwFF6mViwvCZkrR0gUSbTrFbrRB5b5dAXJEZs/C7TxSYJiEZvSBpPrjw+qeKVJpz2KwnxsXl4bs5mvE7s2gHBX1wZVJYNreYXwaePoz0pLWel2y/BrB0OspAoqtGrXDsFpft2Izvo7xwPwJOdOaq9wMNrBUeoZmrtnxetvMpUG52oh0plymSclZ/nQsZZgTKtYoOLLFg+Pi775zDT7CbVJKvxyXET7A8NLRpVDPKMeQbbStoCJo7LTHeuTMvIGwGZgcOCoezgk4qg2bGKQBEjBqQsXA0MI9cGhzY/YiSJSjYuKK9hjVAsPZqGk1kJjqGde8RcNBoTxt6KFx8dCQstfc/kFQPKDGC7K6FfjUqlDc+ly5zzULHzN9LWcGpgdkB3qqOJyqXGbjzraP+EQJSM3vGYO9L7/Gm6klXRy+IfnX6Mg9NeMb2VGMfPEbLHIpJE68B8u9h8HhPp+CpgVDn9GXH3755QMB6ePsRXo6sjgO+425xp8JvhVUCJOX2KNb7K8mjY2SFBA5HhFPSAYLUY1cZA73nlcA6XZa/oy2dN1VPuJUcwWE6WJzG25TxBOOWtHlKexgmh/OOXTQaAG2Qj11W3TksxM1ALIXX+dV1DHIONk2gwhJ4SN+jZya9Kzl0QQtq7Cd0I+54FXFPddp9vEFwQeSqMUy1XGTg93vRyVnTg2v8YPVyzHo2GEImyH2524u5LoqTiZb6rE4To0S1+ehAPDyZ2SiwWTd/weAXPbPWPXjFousZM20v6Ij93APRZBICOCVtIKKstwQ9lrmmk8pmlrBTndhuti9ml0NXcFo6fKyHp9pXxka5Wd8BGQAEFAq9gghNG3vI7VzbSrRS3yyY4GZUijHcw2kHGs1LTQ5Gr98KiAbkTsY5V+zTLOcahX5kC3c2q/3CvH2awyTstXUh0+bgns1nS2kChIfG2Sq/boNNpP2vuhnI8wByQsyeXkzwNEmQPKArOUziIqFOwFIMKl4z92QM7YNQ92wYBWQaa+rh0bVuJlAdCwiv3xcKvuaqdmarwFkUP0bQJyyR6SMtSY3Y6GL+bK4BKNm7sVVIPSFSD2seeI+3cyleDiHFYbryMfrIB+cGKooCoxSjuZjV4kPKtFdbHV0sZAdBqUAnJvBppYCRIJCOTTtbmv2Yw5/nFqfBKNKzsypeV5tRQCyCnIrEGmrNLHVHYDkl89GjfExwonJi6GyZ5F+ZdN7VH6mijOMNqvjIKBJr6sekAAS/RgMKOZxa83pVR8tnIg9xgeBwWuusJg6XlXgcwqJvzEIHObNiWxhNnatyRnpxxv6891nUQCyHWwu0o6q71nyhGm4udG1sMJwj0L6DhpRgC8V5ZInnKuo3Jm3b7ZpEu3hA5WgsdsMNW/PNw4zbo/iR3irx3MLDdtdBcWUtlST4WYV+rmfCPA+I0nbTKsSN7mwmCEfZgIUBL3O56Qh330YVWDc+q+3crO1PLzWu74BdNeJugcV5xNpG1Iv/ZB7rftisIP1qL1ZYZho3AI+ayR8ZgFYTUWvQ9LI5vVAWYxLsAexp2h0k3JENZaAXerNAoE5PrzHSqmuQoicTgUtjJNiPJVXfAmL87jqMwLjQbYz7lLe0ynD6aHZvGtJKiqg0Y+7uZaKrOnhph01KaVaXbVruHchLe51Tw9nUVdD0d3szwn2bPNIi/ImB7t6XEPKwRYvNOLJhACEs274kJtZJog3CqUidzy+MdXhAsQbAopcnqghVVUhDxvsTXpG6OzRUidAyrO2ULiuWtK11IVfS3JZhgQSKX4MgTeTs3uCrSFImIalIOLzklxElpzh0nhUXO0zgHLar40oDk9Ieu66cAkGZyIpdT6QLenq6kc4VFW5sOS3aZpHmmxwCCAXRPZUgI76oCLbsaYP+7TdlRAk+BMw4zJI5AOMGGxBci+qyEnNNfcRNsnrb2yAOJcgnpA+DEANC8H5AUM5NAibUbFHHndUAsSS95EeCI+Gu0acuTMz34eTppnUzJ1+nMuXj3NqfKD9qEKQGICsET4ZDufncGRWs9pd+Zov+etOz4SQxQ6y+GPuHAaVvfWjx1OgJoXF5MDR3o7lXDOuWba6AGk14pT2dApb7QqGxolASj/KrREis1mBu4I95mF/P3Dsjeyy2IDyFo6PbKkBkOVo23QKlKUmp6Ajbf8MWjFZCDPWtoPmk0pfQz4CskM9VY3beKTTFVCqoCKhqJB4sEGl0EijqwrPACPHrDW2mlNV4fBRk11tBhJxr4NrX9wAU70zfGGyvR6XS8cfsc05GwAEoiP5OX2pS2LzeYB0B5t4+LwkUZC8G0OSoNlUpIaGQ8Bx4uL6VHI205oRyDUUrp4uwJikri4lZ3pSSkchladREhtzrSYF1OQtkSlU/HHRjy1FgUcN2nOzTW4GNILMMdbC5LZUMzAIJOcBCeMP0TlV88jUoTRjqMONpnXmA82Tgj6+IFLqsvDnGRpZazzsNyH1KEG6cNZ9QD3MXk/IwGJLzSBVDptrUXW5pp+9BsPnKjxiq9diMwn5M+lld8VZkFX3BNbyolqzuh3HU1QAEtYK0samGCLDpQl6JCDxsQVLcKlersIhgj+7HFcDpTQ5PE32PtdeiJR7/Z4/HbVQUza7+7lAIh72PlMqM9gdCz/nsCnFBZmUnPW4ZtuItFaHA0S+rblQF0AYzJu61oB4ZWkKh+5ek7MOweNxFg4Dx/t6CkRfApHPA+ReIV7etRQkdWZtqEnQeMer9nOduxVWjtkWGA2O3zC+p+z2QJKCM7kyGkqqDmyDIvYaGGrNMNSwtAaa9q+9wmfP0DT5vBQvEJeWbAnJYJOYwa2Rdtxm5N5HfZ5ZoDsakqQ1hACMWGpgmINJbYKPxqUMDA94HCx+0lU+mnBmRDdX+de41nGmxXCjgCAqUkvZjbDYwbftXMc+bHBYiZnl9egjU/IBicluTenjH2sju0fCPeSDogymLGEJPocgmjHEYwG5ejQ/KCaeAUh5NRWGNBW59dCoHtcMtvKFiUJ3rhXyCa5xUujIRKVqfDLwGCcu+4ZXLoqGZ8AHSCrwaNQacTYOh4StZjqIi7DYltsaDONcCim42AOyVyyAysIfsIQjBccdmXGg5zV5LQ2G6VnXbteQl1BP8CsgGWZfaLyNP/J0RF4i4QZIeq/BYRBKMXjtoOEASDUYQvtwM43vSQKHU/lYYXGustbasTDrhm1ALjwburqIwibkfm3mulUkx0eSBm/taBhEVbozA4M+fDYgsdH7vRfHAcNApmCoS7JZ8HqemIIb04Mg9+nhcJlqYuHlVnPePmCoF6Sw+CaVoUGIeiwFnJAPmExU2jx71KTtiztVnN3unhEqUyVisgXCk4qEoR013sxx6GYbFjzYX92d2Y7tRAxFwywGIYSYBwkQYgYxHPo2XF4Q//9POMt2dlV2Ajxy4lOxq/t5yy7Pl+vLtvpHUAjrSVIoRnTkvIOm+64RXf7IH/vwI6JjPepYECbLVufGOG37QEt2I03vwIZKNaphIQVnUpD9hIT88UhyJjjx8B6Sy6+OAj7xi4NzrYh4ftax8LEqzU6fj4ARmnq5zgkMwoFjystNrtgNbB5WvMJqJbvaXZWg+V2jmvngtsOQwvCqyWXSGQQad/oRo63yx3ZoeD6K1IAdJ6HYcLSdmjWOVGNyLXNdFrvi4EnTSqQUH29vSDwaqEdV7LSjFmpKO7q9JtITH29IWWtuJ7BU/hoWHFQ+vnctWgYrDevJKfyCcGew11aOS60Z6Gz0eb1Zt7qygqZ962T7ZteuDA9o9iMyjppeNaEiKGt8FIDks/2F+DQ2wQfeVLoxCBjKxT7odw0qGIp0JzPTTg2QVOmjx3sIQGKtP+geVwQfwuGoN6Scmof3rkUAUl51HEGRwwifOGcT9+BW+jgaaygBmMdmVEhHohgDnB0N10wpBR9z0BmYPO8vpLvw449uf/75+Pj458NXH3zu+evPk3V3IR9KUUyA7DZDMKloj8w2gFw/+mfiaJw9Pyt+LFvdEUifH+6qURmadrQvl8xeAomWLERFki5ky8Ls0HDkZPtMex8JgI6cctdaOCz9uJ5+QWZ1eEHx2115OKqxGl/dYvfD8YOHx8df1l9QiMeHHz876OYCkNhofUYbDvGzG4wIEYU9QTDMtT0jkZjqHEraeBxrII8JxTinDYNDF0vVAMiy1eAQCiQG60WvbrA7gT1UnDXfLRum17VYIRBuw0iZRkrNWZeIr4jsbE0jsmvEOW2ohUmpx48eg34pBipDfvV5Wm7px5y1F9Ji4eNM+5qOy2XaQQOTwe5ojyI9kG1k73Jc8oVAMegcjdKN0pUNyMtFxpdJOYbdtqIKtCPhSPW6qhebo04uQ2Rv1eylSLLbzZUmBH/cNDJljPV8qoiPlsXB9oD84E/AmEAMnie+jxKMwiM6UXisiLgAOcxp7oYFLf3wDA0WW7Okkrl33fpR/YVwez5avVkjEbpkZBwNybjmUpQJRg0H0LQU2/mhjR9CoSBZ6wu7ClJRHquBJOCzfRX0AY9z7BGWzTMc87F7HsDDIwQgYVyB5J/fCZC5kZ00zb4aV390eqbAGGQZbK1EotBHqesDqmhP5q6DSTcaHI8j4mBSTvblApFLAbHXxXVJbrYqhDRATgPO+gtyiw1Pgw0Ii/nyGaSi4RhrurrU1yVcQu1Tt4SVY/1x+DENSGDYgMzvA+nHFYzr1XIzNsaHIvEO9XhcXKPNigmB3vIa1M0KIRTmQZ4Hw+VdS0NeMO7TgfFE47hbE0waGMtGc2tABnNCJ+LLBAFIke7qodG8ZjUYrrLT17LbKwrrk1Cs55t+NraChPMlfVQV4upT4CuLfTwvhcejPqC5i/hQkos706i0YXttsRFVbuaA9Ox1etV6S0Lg83pxn2XrolFI/MOaZJ9ZbKMacgYk7fFoPk2vduVoqSZcAfGMQYLIlSogHreddszlCjLY3l/4zWar6wIkJ/qoGhZC0PCqgjNpyg6HB4uLcoYgcu5WkMWuCT7gUHBU2AcsgkSfaQ87J1CoQp+RrhX3WYTECoorT5NJbD7TkGajDyZA5vYZblKNbrBJ0BB+bIvdG9kRs4oMFHa8B0LOeASKoLGM9QRIrHYAseCoz211Bx6BIvyw3IzJPYARBVmAbMMN55aedYjKzSA4+Z072EjEnDq8opu9/LQ5M2OdeGevs5lmHiilNmxIJWdC5ScgEvWIR6NAj5WKZ6tCiErTrKReBbk1WUgRslBoChKL/Y2wODwigw2w/PWXx49xaTDcg3vNXd6Muq87b20FkGrA3orNOPWXV1JAtZK9YuEhRMcx8XxDcpIu7GYv5Gh+62APlNNStqFSUo2CpIoqjmYBAMlKXK8fVhspro3DPTtcfdjVZDga6/gIhqfNnlUkH7mZDwqE/FZqnVhfQ/Lxs6m7EFa+tVeHU3PGI/KQOlFI83VhkQMwnQg/9igfPSKP/WpIaIxjCvJi5RXLT0OxmU57Mi2VKQSOShaePiJxrYMXFkPAbMOCpknpUFSBsz2GILHV2mHoKUPpx5KzakT8yvnlKyy2ktfAUf2u7VuDSKBo/YUzkS78IPhYAQnjk8UGiymlHPlLZD5NwtOheMVs9hIByFyLpPgjgGwsIsBhbUOCBvdaHa8ilZzFpdIzTq0TFRUv7xo3O48aXkOsOCwn+6iFpvwZeCpJ045g8tdQkR/3RHvZ6rj5zOYtEI6EkLaSvQ23b3cd17IT8NGIXHevHZByY8Qmul3Kq1kya6g0YcUeazKpFfjUAhoB8XBZnFoMFfM5auniJ1SG4MqMXGWvKaXgATkGHpWomfDIN/gy0o+NR/iNkaQoRSHS8tfB1PMKEzC1u7CDPLnxA2brhlWOGzxbFubtro5JGWqYkAgsr+rVLGhEdXXB0r+WegSE3Vmozhnh1LbQVLBnK8n1eSl8AcCqNVOZeC4vbJK5BpAV8wlu9EFpR8NgSKFxM9rh1yh7Xcx6XjVzz620CiC59WwKRFNetd2VJkPZaF8bd5wzlIZMgM4K8lq5mmXI0nSoh0ckt6OCCgXGRygiurankth4NNtg3BS7hCFYhLZ5pPTPTDOlymTbQICROt5T8OtLc9GvZbQ/Qj0mQ3AZwQgUyc/UngUz15zaNwwbhoifbUWqIsixmEI3c2oUBW80zvR0ReSlFsKmU6P2mWx4ZT7uFAzHVuPQ6MEIRvcF4lXcE0dT94If7cBeD4gML1uedUByTmIDQ/iMQ+6KP2KmIWnHGYqwQuSvf44DAbzf9WM10PAdpgux2BWHLKfa27mUL+QSJxF4vul1ejzWd/6GvN0u9YhcekMXgZ4VkNKNph4VclQm26M+stgtG4v81YAk4MMDkhvmWkuHNVFqqMktUDo2lZ9RHLyELiAxKPhKH48ZQ76po6trIJW8NsrhuOQMy7MOKkTO3jW/efUHJHFCWzGuYfGqj8hlyNNUsys+9jzA53dBUpHH8yQN0Z73bZZUYxE4UpPbox+R/YK0lZo5/lGzUvJDCI8AUvDTH0XgcJVgcrXZPRrA3pDsn4mzeTHas7ADpNZzFfxApY/GBZOtKP+luVCONR/nHIxPbqEjr/SIXGoTEiQsTrPNdGsbzcV2Gfbua1q7qDjbDDVSgtBjW2yUI1+OEB+sdc0241dFPg5H+dey1Z7BBo/bL+hhWvfBReoxAcnW4eP4o/pnPpAr422GP047aJjlIzyWX3PuzpTFlpY8otu1IpFLz6dAfsjwntmj6emPwbkUMo9XdHFySO5koxGa2FyFjxT6AEnACCrlY//QX02ABI9ursGjCikKirO9htCMoofUjbCmVI05i7QG7smd8Yyh9iE1Ds9zM/Rfm8E26jpcCNEeDcxfkFdrY1jKVncwnNekz6cI1krRNaMIMDIMoNPXcq7nplfi4jk0palKzuZ5Upr4yElg7t+P4K6+ugV3lyYAKVg+2gaaBmSWVRQuNSwlhew135i7Pu4vlIIM4916UYu6HJGihGAJc7DB49Pb7asnV0pnL+oyRDUy4mznX2u5K/wsP/N1L1cAlyqmECghMIgb0xYbU807UvZa8wCAJcA8nnDW70cOkOzqcJgACRb7BDteqlmwnBd91FNyF37EXgfTOs28hZgQWQU+8qltY9wxIBX0sfDjLc7KnjwNPN5uv7x3GVqq47WXalo57jjvkXy2kBnkPdgV8FHHK2IX7cFgA0aNtaccF/q2oKi+hXo7toApHj4gcmo09IhPHFFjsN2aHNtTGWxUJN8xBfJQkSrKPe5Y0BrsEj615xiOCvOUjtwhckVih32ulD1ceDiSJ6TYjLj4rB8BIXet0+Q3Uw+UmrM0nD3h0XAKi7wg4wBGX8muIbkeD1clxUrFkWa0d2QNhvjX6uuCvAiyYEggPG4hguZhFap/BIUZgtQOQx+N69kZlYmfe9dhrhOaT59eJ/CzMPVxG7aXdnuaJMWHlkRMaz/cp4kPrZjkYR+IyGPPA6hZe6Bye0OiHnteytjvKu0oew0C931dM5VqbMldeEQ9CpU4NI3Hpu9su2uwlQuBCE5pRURIbVeAhTjNzswRSE4TV70fAeNKq/G+TgnakvlrKnEx25ad+V1OtYKQsN38cBglZmap8w/52L2OnbMtV9B+BRgH8KlpAcZF+lGlj3wgkksZa8XDkU2PNt8M11qbNLnsdrJ/Ix2ZE870bEQeGmxYVz7Czqy2rDNYzJ/TLZ+QT1ZNuT4hn1zIZi+8G7VLMy4IK/SB+dq4ucOQjUiam9IkLGrfB0DEYKMfmW6mdoWsfMSb8fQ1svPXrRKFw0dPGAqOoj8bj6oPZ7wZt8Ti4UZNoIfJJoOt9+OBf42tBoHjfApIlyNQIkw3NoHFdGri+mRVkpex2akhCfTM85p5NbIPad6wqXHi3kNTRbk+zl7RnsRgEBzi4QhrKiCuJ+emHKZnvvhmZ6b1jjyOic/0MAKylnOBxZxPMQGSr+EIkytdfyC9A7uejW2xhUP+cjC6soT6Lo8GLXlb5dMnAcrLNMMurOiqUjORRkB2FWQDzzYZfgJPP6b04zRBvMXcRdMMcx2UenKKQYJG1YcH2+tHlT8qO2Nk7nXRjwdbuuKzVyNCy6/xZsAkUXFpSDfWoDGDj9KQstunbraqe44NdmISz+ZpnLiGkrxKbBynRtXhnGm9Qn8TFo897PjA4lH48fuOhtPMpYrcLU2zbcDmwCh/hMm9Vgs2eBx/nA2bcq1hTt8phR0whMeHf61n4256CojkBandMysh5gx29xgiVW1WAlTaIKkS0ojwurvZjnMLikuwq8TGF1I0Z/P2BMs59rjLX1eIBwe7h5oZdWshEfGtCrL3u3KFtJa9Y+E+dg/92KT6cNhIhcYjRD5OAUhNgASETV5wBijntyPcuxU0Q3xYsAAJnec1kHxwmGAYwZ5QiSsWKwgZsfH44zJFkUtVPs4LFpS5Xr/CZALxtH0Gk41+VAgSJgVZOKw6nzXgUy3Y0zYkXOtunVF5D8RV8XDViMOsDhIkio301dxfWOHH0pD1c0jm5HDqzoY6MyO0IyJ4FeTOQPSd7FN3oabuecbwVkBMXt/DVdya8LKJ+syTKRjX3DSO3DvcF9f7Ffoc+thlrjcjraGkONoixR/1ZuzOBe+/nhUj0lRkHKNfPp7ThZppX6rRoLhJFOR+A40X5JZa5MKtiOtpFFLvRmC5fz1WKDyCPXnHyX6y0lVCkQsG+6wiV/7LqCR93B7tCpju440fvXCYA2UPjWbZC4qVNtTWwjjeXwgMx4AjyDQwysk2H3skdRiOW9mLzxqyxtpTV9E2+9RooydtNK57MQLisPTDdWSY68Llk1CUq4jf0zDZgcmr1I0vCofDpBa3uty4WeTRGroaiwhYiFaMCDzqFZqlIm2a/ezQlBujJ6T3z0hDSjsihcNTl0YKEr2IqQ421eSOzkxyzThrt+YYjR/xfpw8GtSkjLVTwZCb4OiODMrxq6fxjsRYB8vfk2u4NQulFT5Oqi6KOeYFcrudEUhO47AvPdosIBis9WNSyMlYawAkpNpHjuWvLYeNEB4FSaObjbMXBguE+ddsr6cKSLfY/XSk1bXXsc/72M8nnFV1uFvqOQAJLMNmh5Uug12QfPjjr/cuQAuRHk/P4MlMK17bYPOBQg77C6Uktxm5lqPBcuNhJxK7n6sh2bXhOQ9A69h9nlQDcXatPUEDII9dbPW5to6kzAcQHg8k1TT7obnwcAV2HKiWdBUewWZdz2ZA9ik6wiUasnwbQuIrJgONT24PD5dwaxbg2KQdNKBOSPRYD18O78kUjeLhO8rAIwIgyqWZys3QjlzApPSjjDekfgXYNBhABBCRR/TBtFshJF62+9aZv94S2OXQVNPCoTujMQCAbx7VrD8gB6W2fjihGTNd+HQ9gct0Z1pLPlwiW7PYgNyK9ux3abq9prJnq35UqGcux4XXLABYHIp8BMZGYfN5jv0ofj601+cV4sdh8ejv2g2UamjG9XD3NbgkIB5XTco16uw1OrLRKPYvpPCj9byiD/MSYKRMPA11sjTbl4j8LCMYI9yDHHcXwlTe42tomLkHIi0/owhkDwWAq+CsA5B0uVL6WDuwxyiPxcP35RSlJYVEuGHRQ5DfTa41KKzsjBElkN3S1QU+LVQBGb+gbKNJew2da8Y50tOW26ixSBA8OBhEQQZ7uD3w5yUS2ourR047MxzYBMaaB5C5wmBb6hplaQ/IOF3dw+Qeqh+tpKIBCQsBczwO5pnrBkyr8IG5Q6MRFTUAEv963og0ujMoxL61TyPylGHFwre1XKeruZDz0xHhCRp41lTgWz8Ns41WXA+IfHi4XeEVGZkapx4hPiYMfcQZVrrAyJmVI1dcmfgUekRU0pCJAN1ZWLpxn5jhr1k/cqxPwax1jak4crAFSJlqedlqo2mi/HHTkBrR3ELr4ralH71TEwE3Ugo7qPihO7NFH2ER8UE7wvL1GF5N0JMnF+itWWy1ApjDzRYYLVvISs2eSipr7SWQGejRCzK+XMSOaPpUGew4XR0O8/ijSMNxJ+0IU3+h4xEkAkhKzeKT1S6mHdj5cIyDi61gDxeBEixChUYVh//Lii49HnWzBkPSMk/WNHa41tHb1RmaBwAZJ26XcLSXfYdh0xAI16UbucBkz21O3bgfZy+XZos8wio3M0Hyh4ZlFT7qQAjZ67FNgVtdoC3OI2vt70ds9ODSxE8QRLTp1oAzxXo2IB6OgGTlsMbjni93naSmpfC5uUY7ZvHjCkmoXpDwUJFxLuBoL41FzajQ+J4pUeMruoJoMkwUynYrY0iTYXvWCPiuGhcu5QgqQ7i9Tl0om13Xw4j4Md32PQsoRqHP5wFw5FcjZLLnIZAwLdOs799JlY+6Wc8CjEdjRMWBJM/HcmoesNkXKLFYzGKDy4LkQeWj3GuejMmTvPIsO14bi+jJL3tMxQTGT9GPVPlo5h630V5PboxlDUXn/nWDEaWYDV0hG4w+bq/1Y8Ud4f/g0OTzUa9Gz2I7lUqsC2xP9XZcLfYNw4070woygMgrcqX7d7Rnk83LMcTUje3ze8Dh1l8oIPIN80jV6BqsV7zizYzze7qWQvN73Kfp/AwqUniU1TY4HvrXByMBoDEanjdNAuCiTV0atse9sYh+BIBkr30dktvrRqF043mH4Q0PO37yZjoM+bD+iaIMuv9X5BLwU204YPRJ9scDUxQSLzD6hq5glZfhkJ7h+973xbGDZiUBUaR84bDrQ72GUEd6/t1eg8MqOJuz1/N4CvBY1T3daOj6MfWinGw10XD+dcdrsdMUTVXi8nbM34o+RGNypQLln3de9AMgq64HCRqlHJGiTzRQqiCoFLZXP8IzhU1B7kr71hnUIq9H7tKP5dZ4fbg0YzItoNGEs2P/WgFIzDVmmwofqci4bc41LPdpzhuwVQqpp2PyfjYiPHN9XAI552f88Uh9DxFIHo9xYNwz/hhfyHxL3nnRz2KPR2QlDV0vgsYgkKmlmnUmwlor6kOza0gyNHJouttVza6Ig/fjMCD3KGW4accQ5/pR2xXWD/zBzhd+BPZgGre3LxXXumFYV1L4zGYfCQA/7FWQySYiHhQsoj5lrsFjCHTjSqARuu92r6XgiKjaHjfaMy4BoobjnhMjfJo6Kp4K8vv9SIBuWfBpe0N9zyakH7kqYagWbM/PtDtTlRQCpAI+fNMASFRk/LQsToDs9LU2awK+BmUSf3q1GQxCwCVcT2ZRxfqSBIh8gUJwCAtMJt136XgDMkPhiotbQ5eqw9uBics45czVYz4hrfwxvjldGAxrDclow10/QqcOtqDo9rqoR5FCYJJj7QpEHzHbSs5YiQ9Fj4VK+dYtoLM9XRpT0dKqH2nqWn9rrOe2cuDI4c5Jex3fFfyapWColgUND3cP+xMgCQ5VI95Nr7aga6gOrxWvrOgSFour+/pw4N4Ho3ONnOhxBGKJc3uNetwmVIBDFKWIP77JhcPMs9e7kcNFeOTHBVXIkZPdwkkmW02vHu8pv/ppAZTQT521AjIum2Lsy537NcuwmguZP519ypCMYRtrn9cslyaVZAgsdVb4SEEKkUyTKjqel6KFSM18/YxcmnM89ix7cNgjAUCkh8PJzeQp99r3KzQitTSubDbUsfET6n6F84FSlTFM6xxXbuXLrD51PR5bOXJLuueZ48vYRoOPPbrY3u/acynkYR/uMOwCn45C8qPabFpBAwUk24uRd2P915rdw3dUIe4JbLfXgO+zttRFXDmiQF6XU6x0FhLXcLNyalZpdF4iHtyp4bimCcvJfio3pji4DOo8duPxj/v2a1YvG6tN7lBG+qj+sap74vOMzE43BiDBoRKGMOC45WgSjmRnukKcj6vmh08LsFty9YThuX6cp/iAyV3AR9qR03gEi1Z1NobEQWNvQwpmGRpDo5eHe/Ax1SIONjNTgudMAMKQqEisNnc+CEzecb5mqRy2XpINzONxUnzzZi6DZyMyBCCEA0SU5NTyKrVYePR97CsJkJz+r5Sj6s24Gh617yObCz8TDI0Cd0AS13rcfQ04TUGyU1MLuoRE7iJP1EBxczi2S0POsGM+wLKSNIFEeTN7uudg5PJMh33GcQCI2cGGlz8TvF2Zw5VxiFaPzAHgKPrYFWckCgGl7LT5M5BC4fDjJsPj/LVShVr5EWQRnylDg/igOrrmtyN/anp4h8MVDIf+pQJy7MI+z89U93UEfAKK6p9JEx16MpE5Y/GPP+7Z035peR2FSMNr5w8P93NB6xNyU5E2j/TbDvest3w79sA9LPa4FImAePwyYQgaXU9qP5cij81FcmR0E92ULlTMhySNudcW9AF9HfMx0rhmsGl9CscdC/0LOivwuZUIKov9BH+7qiqeEA9f7yhHvJsNjbA79rTfWl4DgpB6ZwCn2evaYtjVuAbM7HWlY4FgT/OQLL+ed7z2G3JEIPbb9mm2sUae7/uAHI9KGJaLje2ewj1z/zVKkYhPL1g4L4Ak2MPRHiSu/77BUHWPhwVnNBgCxmhXaPcagz141Pma5AcSwSK3e/W031ieL1vdKJSxxoIDRax1LdRsu92DcufemYQlM3zSaCccs95MpHpcRSBF3FX/uCnIYHC+5uhFw6PpR+Wuu48rucV7wGFwrPTx9pl5hWG3GKqDxlSkE2g8jYiDxKEyF63I4csyyGzG3rsz2GzOfRrtt5cXVCCuufZH2cJgERcfkzNAcsBjF1RUOW53GG6l4TB1LGQLDUHIAuJRfY/lCc2d8amkxwMqCD6mQwMg1c/lIch8PWoGpLioKs4Sl6APYFqmRuRa8gyQTNvDTAetM0nV8fqwMlKG8cUxrwZNGewuYz8vLMsz4+Qei/hUoVniMX4Kgs972dGNgBEQCpEUQAqMmlEBDucHZAvlCyEz154qbHkef0z1SD2uJodjtn3JAl62LDVsj8eAIOnCgB1/aB+Swc/QqPE9TmrDbo+mX46JSRyaShgSfTSXpu32L3c4WuWlZVmejSS2HOzDSvFaz1UglGKcTTZ2ev1QkMHjV70zlp75lGYFBJDU61F41KCU/o6Lw8/z1xXsGdcNE4Bsq+1LDGuI1Cq1LU6JmhmRiLbY9nY8RKa8bAXFjyec1Ux74LilsAEm7gyPR8GwvkHEucNn5MsByFc/AYDyaZy+hqlf4WCATy13Teq+BSb3rHCcHBqQmDBcJbfj+biaAcDNkzMIleUe4rHS1wR7FH7Mk2J2aOLbBqZojM+eGLOHbz3PqeCS0hUkf3isRzccmaw1i0vmrtcOw3ZosNUrK7rVTThsNXmnsZ93l1SRUAjzr3k8wqH3hcO5LLfWsce3ykRlUJaHW0UuMXHNkuK282egyVI3Hg2U/6Wfq4aQlpCl9uEUcWnd6O4MSGyZtlpLDI2EQvg8kFQK0omx4cjbhseHrseNK7CkInd8M6YUKP+4v2dkKMigF4mNA0V3ZvqrFM3QPjMP8MFWd8KQHzcQaSVnGOv4tGDB9rvOyws5Tl7l4/1cekBW2dmwFkkke11JGi3SNHemSyALiz/2p2n2K7O8zDDR/nQkaTZf48pkiTipQjhPx4BhMeVohMl+PsrT/vO+EPnSiwv0SutGbzFsOFJ3xhNS7rURtloDfOIAROufyXkpX5YXU996t/ij8oT9D0/NnONRJWdoyGGMjwApSf46vqmagnOgIUleI8Giq0gnoOjNCrbiVUU+kbtGLa6kkoqEIXg01xo5/ufxruLj7wBHjLbsdF3AIcU9PQQStYiO5CciDk7euirEC5jZzMWfQ+yx0zNtrw/iPShFGFxA9ByNl5x5vIfZuNM00jLflsDmslb5yFjDbV5KfB0Tn6ogz0lxHrUvOOVUXHYOox0rOfOACEkC+zDQk/oRQz2GI++qfByDDT33Wve8QkjtiwOSg3NtAXFM9grE5PkBRSy2CLe6W2iGcM+Bfw34BEooL4Ki2+vj+GOBUpU98e04mrHLHzs/o6aFQ5dG+129kMLH4wLDPmc+9lMCPfGBx/awEahHsoXcQwZzAo96Tt6Tq/3Gc4sQ+ebh9PAeIQ5rBamxKXpA9suxS8RzbSFODYNyu7xHi12rGBfZfN73ASZb2A5sC/kc2usaa4YYJ0nB+GSuOUwkFRj57fMzaa41Nhy2Sm4Oy5aTYjzRj3m4VvyRU/HwShTe9gD0sDjqMb6geyn8AY9C5LNyrzVOioGkabDBYMHRJ9ozp7lWGar6MXBYO7rYygVXLLzR6PPs63TFoyB5vjLO+7kakuzSVOa6tSTXEY84Nbud13E/npCrAp8tBJmEdEyaQxPSCY867TYTcqvoDCB20lpt2Ah/NXLyl+JOcogvC4/l2Tzj+5BIzPQamiDf09W+9cqw2FmP212v8U1+dYCyleT5PFLlZzTbLLhv/DBrbfa6s9g1w8dij4JjxSC7qsLH2YNEeP6Uty6hi1SjTwUQKo0YjItHkxU+2UDDC7KjjwBTDa+y0Yk+TgOzb3eR1X7pncXoxWc/8XXseNb9gpSp5lqALJNNKLwWD9fOYax2I7Ii4ghrnHH/emoxdM2o6xkepyjk2DkTwqiXvK5y6L4+ez9q1F5yGW6RhXzMk7FkYdY/5nIFTe+BlLO2dKHikNKNEAY7+J///wD5y8R7jF599hmhMX7sGuYJ2fjrp6T1z6Aqu/m6cPi97RxO5QhpuStM/Qpa8SrPJo4B0wZUWH9hVz+iHc2vlp4sNyYD4nFgZ+uQKgopPJ6+HYVAW67gYFy1YRXkDruQCo4EINtK00BjbozuDUjwCfu/p2xeevnd5ZReeP6115/JoGOlsOc6M4RUJS9H5u6tRwvjvrQA5KfY7CqpGBe8ejw8WIMQhrCno7zs4/rHnte8SuVo5GTD5oKKXu2awJSrPa2L+wgWIr6EotvrxiKs7kDyHJRgMPH4lWop8sNiP3RZxVyOi3UWH8y11OSf/9sA+UtvvfH2C8tEfwMnPys/LWVn9wAAAABJRU5ErkJggg==);

			.gocom_btn {
				background: linear-gradient(90deg, #FDCA1A 0%, #F7B21F 100%);
			}
		}

		&:nth-child(3) {
			margin-top: 18rpx;
			background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAApAAAAFoCAMAAADXQjuLAAAA+VBMVEUAAAD/89L++OD/88z/+eP/+eb/++j85qD+89D85aD98c7/9+D//O3/++j+8c/967f98M795aD75aD646L85aD//O3++OT98c/989X98tL/+uj/++v+9+D+9t398M3/+eb/++n99Nf/+OL+9dr/+ub+99//+eT98tD99dv+9Nn978b98dL88Mv//Ov+9tv978n+9dj97sj98Mz98c798Mj/+OH+9d399tz/+ur+9Nb/9+H+99788Mr978v+8cr+89b978X+9Nr+89X98c398cj+89T+89L/+ej+8sz97cf97sr+89j86a785qP97sP96rT856j97b/97LqvXamGAAAAFHRSTlMAGJcGgeiwpFjq6Tfs069409OIN7bMPaMAAM/zSURBVHjazJvpbmNFEIVDGBCCYfmTyUYcjENsJ9hjJcGLiGJ5QuJI8/7vw/lqcae5vmximJzbdaodIX59qurqe2en1levPv/69Xzvb2mk+AAajWzx/z/eY2mnrcXxMUGSj+ynnko/oOMf2Mzn/JpbHIWhI4m956I1drY+Ojs6Ozs9W5+lTlO+e3N+enp++kY6j3V9f//E86TAJNz/ePV0f3V/dXX3dHV3p83dlXQnYdv0m62b31I3N7/pkZTIRYuT2cnJ+GQ8ng2m0/F4OhgMxopZbzYb9Hq9MTYY9Aa9lUI2mQyHK5mWdsNJtzuUusOudl3y4r02C4VseaB1cKAkJ1IPlT8eKh0ePhy6HrHQ5aXisN/vX15eyvqX+wpMq7+/v9/f73z53TfffrXTqk9effZxOBxVe3eRpq0SSxYwwqFnLBEtEouOoVymJSARO5iERLyptRg8OhWA2gk9VvKIB46weC4MT9+cyoWjfj2CHyuBDBqVkHCEwyeSx5/yCIW3N0pGIgsVLDcanojHKUDOptOZkByMpz2tnvgby7Qw24jJSWgIjpDYnSiEovgTmgt2MmkJkobj4hmL794pKioPHxTCcbv6ovHwMoEUg+z2+wLScUx9+eqT7Tjuzvc+uoCQZA8yFLWUg0OC1URRCAIkyRwAXZTC+ZFx6AmRiKARP4u66AhmuMgUR7F4KhYFJlzC4/lDlEepLpKEHKM8guNflUeMSqjAlX3H5g9AqjgKyJk4nI2NSD2OIDjy2FKg4WplldGYVMLEoQMZCxiXwlA0EhRJQ1B/U0akhFL1EB6VGroESDA0HAl2YpG1jyAy1dndguQXr/c+no6bJdLhhLqEMPkjYWSi1hwUFQZkaO4MQiY4liKJpU7VqS2zOQ0UCa1NAOWZQNQjGgk0gUJTYIg5lJDIhgIJhkR7haQ8Al5C6GCaSLXuTqbicKx2LSKVAVJ89sazINEfaTBRchZ7sEgIzq4DKRJBkUxh7B5YFoSsbjcprMsjFv1aScJq9bWyXYMj5VGrLo9ZJb/YqfXp7t4H0+ifFshj79T+WPNOHMsOwWrFotVJWvPxBkZqIs8POABiODl5dBJp1jTtdZTFTWCI/bkdH+UgmefIsbHI4nElkPRrZa+OMrxV4vEucARAMobzy7epazBU00YD1kydOssiYsNO7MkmwxUcBo+wiHVZ6P1yAZjCUUk8Hiy6ItCPkAvqY8Xlgx45BfIxmKzrI1VRPGorIo1FhVardj+tePx876VolAGMSqi0a1MmW6Vf87jmxFwhF3TzTTHM2shKsT1zHL1GRr/GWMniOSYCtROKPC5tfnISs2OXdHcVKMoKi8blFhjdY57BDUoezHbP9TjT2fFkOjUcdXQcTAWkCBSX/pgSyhUgwiMCQ9yq4xAOoTEOj7CoOGhTNmyByJPFsWRr15msQqokMtVgCWBuUp1vPn2RPBqOzqBEzx75yoOjB44KjpFUIR1JiMx2ncURGJWSyPDgcE2W5DnQ4PxIwSJQ+iyDheoZJnZM1xJT9kbQ2KoyWN8CYSmHJKzSxWI2BkQ7Pmq+7mk7oEj2tHcgScPBSmP2IMYZTM5Ak6URMG26NiLFY44zqaUNNO+iLCprB4wRLYLFPjTizNVJIVHr2v0Zkbt7L0SjkplmgkLLUlrM2XWBxJ3AQiMAonlhMDGsdUbEdU8OMmQ3fmSN1HStRb8OGi09bkYZc5aCDJGIEqklyVuBZHmFxDykBoxvsd5UKI5nxFjFkisf5Z7xOLZZZgWTk4liJSSHLq59FHloTHF61AOWqo5LI1Gbd4w1WmblBPmIIW58GiwqwNGPjkkkT8DYRFJMdvZ3N/PM3osRtXGjzXSdozUmb4heTZqrPmIbHpWO5qQmiMAa5RGpUx/JS7cuHJLZkMWfwEwQba7BJwmk56Txyk04giErSmT7DSTXPQlkbrI64kV3duUzE5XCULXRWIRDXCqXkACoJ+ZqbMKNj88z/GWh82MON+rX+iUatUXVNMMKEO13W2kUk0pY3Pg4iwzY5KbgsXMdk80nr/dehI5HBUt+HpezI45ih+F1y04058ElUAaMyp4Kl6QQOOJMM67TtGCSBHzA6K06s0xMnvg04yb3uHIan7BSGrGt5VEhA0An0RREpsr2bZ8CScsmBN5MQb8eyNBAEouasIeTlTMJirhfhnvrZu/lcYkdAGZM2GWSQdGriUd4PETmtS7jBOndGufgKBeO2bhrXbN4vvzEG/bx35qPR/8pfNtYFH+YHslaNhG1Mccaz80aieWbGXeQNPC0LRWxyePaPA6PJicwHWmsFpJCL/s1LBKk8q5GPCaTV1oUxpDvbKDZziMP9N2W+YUk+a6hhaZqBpqBSqOKZNTEZ8O1GnZwOIBI8QeAJBtpPIAxzo/smKgPAFMSlDWNGDzmfJ16rHEsV+Ix0JiaIKIO0enQs69VI3etQELBB9A/hngUxhKPDiILI6CT9McZe26VUZLzJJAG4Zx8RKCcaYqg8ChuHtcGI1s5CZfeYEwztGxUzpDhD0ahP3FydCs8gqKv7bqxGiknMKeSHD+LLhRq2CeMMXYXPtU4gxixEUSuQJI07OXbQgFKTQTMEA16AYkLBbePi6XPM+BY34NXWyuOLfePfTfjcT8nGzbb+/W1W0dI/kyJfLX3QsRMTZeOq57q7SCBhRLJcnKkaxeJQC+LOdDUVs8zaz9IkoAQDC3km5YNgAo69vPCGD9/fDMWhhWSViDjSvwuaCTadHsj8/mlejHDvqELrafZ7ISzo2okkSCGrVbyCa8LlQabl4VeJe1ZJJHGo0w6sG4d0jTDHiaJIiexEFkjyanRcESCkbvHJJHUGGcU8o5W577zSkB+tvfRRcdmUQRxG2X4Y7DYpJE6CZBYsJjtGmPRrymPXhdTNZBn5qfKlMk4MsrSCeTHR2cRL03btiIyOJTJyVcSjbt06zbZ4dE8tGnaud2mBe9muPjpaa5JDvUjdjHODJhmWJhPNHlyDAjNuHoEwRiwiXh7vVRoVdOMX4e3HiDhMJYAlDuTLaJXg6Uj+aW+7/nvP6IY/fv/jl7tg3ViZ2vEMkVyEMvLwiyQz4YZL5IA6c27tOumjLs1NGaQEP36zIYZPz66zquh5sfo2aAoh0arjFpFd+269YGGVQ3WZEv1fc+FLa+OU7Vsrn/s6pFOjUnUR7Z6f633M6uYsRV5Iy5XvGea6WKB56ZZs2t062Qyu3ZTnB1p0UqAmOMMaTuNHS1LwlG6/urjd+wRi2qYjHJWhEo17wIkT676wkceVuqj92pnMJKt+qOzs7VsbU6HLpeQslw20IhFPWSviEEiCVEif6VClgNkDNgFx3Yi4RAkNc/cZcfGzIlmu1bqg+OYKbun+jibZbNO5z5caA614NBDDFoCS7sNB8Jl9O3lgf+KO8hy9Qh+FZPlDU3z8Mh0HXIg+wpwbBEoaik6pm93Xs5LGsiMlCNMmWc84WmsctPjIJYTJNRlbWSjxFNdQKYzXwPfRjnX4E6kCmXBL1Ekb2pm38rjhkgJ+8t31wTSLho0ci5hsYFjaMGAbbfhU/K0N9tcQq7woUYaPn7sOYEyHA7h0hh8bwljnNFAA4sLOrUBmVt4ZJcwujd1ScjsBpxlYb1aqY1GVUhQ3O8Ekd/sfE1p+lf0/McDDRj6JJMDNoHY5bb+sziTxdtC/ULQCXxw6QM2vzCPovVp3PaQbM4uSFY8ntm3j+d4KFt2YXOS1+FyOvbdkyN513YBmUDeytEthp6N1m26uJrZBaR92UOJBEXcN4LRphk/QCq6mN8/li/OuNvp2gOSDNniUN4VjIVGJzISlRImy3jdUAw01rC9Om6/8xGHMrVrL4+ye5j8bud1g7T/E8VmiQQ3g5I0SjTNCpjy6hVNMinJg0YwRPWVOKqHbMXmM0jClDBqKZQdPkkWwwyxYfKX+CYSCgFSkcM1MLbwqAcr31J41qqG7YYOpjMdHXtq28q9Wfk+nCUUV7wvHMAgQBYi8/0MISOTYBISIXLhLwpT/EoeqYwW4NiojnaA1FNd9CiAkcAbVALkPiQS90w1L+Cr3OO4gvSLnyQRq8fqbRJ/yWNONTCZH57J2WI1kGst/yi3atZlxLagNkpvsmXXOBKY6ccFRApHOfc9z86P/rRf+Nzc0q43jbowSK6uH99m3x77a+wpn5zxXUUUSII7H7HY45uKySoqY6mOC4XOj+rYC+/cjDSKpTzeYFM6n4807+oPfABym0RhfABZvn9kK2+faQSkwSgajcifdxqt8/+UphcelkulkdpIhscyaW+Td2klIAwe2dnhsf62B6tx3LRqGUTKEBjKyXkhLgLzc4qgkI0p8cS+95fZEq+wyxmS2oi3nCDj5XVWSVSXxkhvzeToUcOMnh634eDYU7YpG61WK9jMbx9lAg8m8wX2wmJoX/cs/FszmraSbh69X8v8C5+iB4B8bINROIpGueMo846thfDmFSQ0CkkvkPCoErnzIbvzX/9Psi7mv+PKO/F6oqZebimW+WG4tvNyfIwKSeSIXYbsWkbhkQNYRmz2TmJWSGMQJYXp3PiYuBxfxA1kAVHPn4vBGhbzBAl+PKU6VvXx4oZH4t8rgKNVRu2UFGY83ImvxCIF0pmM3EUkuw1H7GBRG3t9rb2WNhENJAuRj8kiOGqWcSjLNKMEh3hTNllrWWgh4QiQH1HHz4qkt2oLymNhEQAzhcAwujXPnA0KLGEPJ2wRNYjm1EaZIioiZivzecBIFEsi9cSCS0qkX/YQ8IgpSW0DDa1aLOLEs1kGt1zN129td/Gg8tibbT7G7YVJ+GRiG4UdHLH8vqcUyKUMabJeesWkWPqUrTIZBBJY6BAkUYUkEoGyw01x9Gg/ORKMNYEjXILjBwJyZPaPLiEjwDGAjCMknpfkjUtxuMy7x9Kv7TtxNmZkLMUuvsjldWFe85AKj5L69OYlzWawZsUPIlIWysnTVbykSbWPM8DoLTuqY4PBLJX1pThc/k7c2e3GWQNhmKvgR1kqsimESClEoduyC2UVhSaVev/3w/vMryyvAwc0mc+e8VY9fDTjGY+dW12jIZWJu66EabzkxR2FcPOPuEZyGj6TvqzQXZBHG0bnHhdpp4WzdwTLSq0/QiFjbqfAPcoakhapofKJ80IkwvU9CgFIUHgRSQrRWEMvvg7ZZmZJj8jKe82cSAVsCuL88tJPh2pMCSTWFlISXY+Mkp+I11Z0RCEFYKxjsXW93V4WjvjFJnHFZF9ZCPxyEXrk0YDku5FnfAeOHBXq6/bHO9FIUg2RiCHZu0jpuuxKzAZJLD1nls/44bU0BiYLSrEoB7mu9FCD9I6KFENvcafrlQbOkeGH2DW/epG6I5mLJgMgz1DuF0f+4LHozGX7Rhk+q/QElECIZjiAp/JrTFTD+dI9hvBv1QXpjRUBn9uEdNuR25H8xc5oIkynXrc/RjGcsWwzg8TeRZqD/EbksW0kZGPj8FoCkbSH/3wVGHZBXMPk8+er88+gebQPIi1KC0jEzVj4EYkoySK/xkcSqSNiZ2ePWJRZ1HrihEZKgkI8qXkZacgDSPOUXe9pN8lsGlt+t5lNFbAoy9d1n259ZAzVx+gSf0yv+No1AoYyHp8BEupSKq1JNINFDX0P6R4BEfVfDmn+7GidW8kJTWhkSv5WmGb/+C62jpoFJe0Ud/hJr4j3+xRSmKMWfV0hw7fxuM/WHrQzmUc0AInQU7G+P+MwMlibb1zJq8yuewt5XyH7S/Y+rt2q4QeIfH5o3YUejHG5iNh4RlOJIoLhYIYFq0hmppqPlx9fS81nhbXsNyoAEuhiIlkCylBtlp/brzckNSlPbR9RICeVZ9YSDJMxpdiR0Lz91i4Ysnt094ji9gwcso28ouBDpHZzbvEaixF/DFRIvk9xDoWTfEwd6fUsndFgYTHvKUTUnrgUftbj4+E6ZADypeTMlUBkVP/t4BD5MdGYrlEqofTWHo/XGa6xjEGg0WAkqcFTBorMWFunGZVwsuyi0LXDmAyyQMcmkqBtxZ5/7adAeYmnr3TZWupk1FbJR1AKyEvddiXFhkS2j/llsedniuLuIM8zZOsnP4jYPonYQEmMtoSGcQRJnwiLfjLlqdNCorUVfiRx3bVuz6BOJTWwyDAW20Nev9geEhTT2EFhHRz2iwAttfYkBmUBGw5D3AtW+A6JxdwA+braxLMFsifyNVDK+LbRzZTQRC7DZMHcjzdeUYv6o3QmMmsafw0Djpr6b8DHtVcyGkm5SA0Kjzca+MhsqAiRi9zTAQmOUkimMnjIYPFc0wdSXHp+jV7sH2Ex47Vs4MhoqUrPK9fGogOpweT37ct4yLPCsZ0jrpHfVXL0mW6zcTQeK2QjfUxT/WY5Tx5fJ4196Ro7vOGTfjJoZJUaHBHnsmTrsrt018i4XTvIutEFkMyBxolL5xEkb2iDJLnmlbMUyj34yOh/jDd84LDaKwRfX6A5soBILcCRuwsS1PBaSv16QE8sMsmvjUX/WJp/XHtGEQmZmcqkfbmQDXRmIRD/aKYuLRSS2PaQsFhFcWa4x+7LpeSTvWczh53MkGDD4mMAGFQyMfTjSgnHIb9O4Sdq2ECitiE/3vcB9tNHNMPJdZoq+nSwRiWTH3WIbem1Sx7RkM1wYSFvdZ1jzp1JGX/bDOeYWOoDQ1bykDLQWNId4vF2D1N6jtrOoAQ9lHtQM5GMV9LpIYnVg1x/9QUj85rIqvd4WiPpO6+LboqCsvaOGbAxNEQColbd/JhcYhtJy2haHETZjtUaYBkP77VbRGEigm+tVRwmJQHkYbv9/lPQuD6e4UvHONyjYZwSYEQ90CFOQpNH2MGkpzM38o++fwTEroVzUBMvVOyP4SA1++6MeBwvuzIQtFi0I8OVEKNTvBZ+Gsl2jUJSH+NeC5nGcQjZz95lAYgy0wF2CJSuSuIIPjK7zroREiwLxzlYS9nisbxiPk/RQMKjdKXXHbmZ8Y/tGm0VSB40f1mfZEOjNfhAJDKd0cwSJ9h4yN9EIqPepkgk76iH0x6uE5ph+3jORPYyeMnUR1XBKT6yb8RSCM9yDxwyM5uRWbxuZh0++EcNJIqPl8vrM94BCZIOJKPyGZPJQ37hFKfzaiQrkGdx8ZWvoWRdGLa1O4ZOJCR6iMZNOo5j52Ovreyoye5Rv/CK5RhZxUVXwQWRYhItKR6HmqNhmhHbfeRBP2DysP9rjWN4SM4L55pjcjkXxG1+klcERX8nRYNuHxYRuP2Ipg4L/fr1jfVPlBy7S1zrIUprzCIaGbNcakAjw7eOgJmvPy7KkIbhUA0nnemqz60D+eb/OpmeYV0jeeYkWno9PdAsPfT3DM2PxGxgRMfDuEFk9PYsMuxHCj1Mkuz0jAlmY0nbmRHZSY2b8YEAbGwdAdT0wfOazf5fHiV9W6/uFZOoOcVGVU38/sIebzYnGSC61iB5uQDFi7zymlkNXz8GgOQtbCv47ON4BouMfeLAuGASie0jwzwjYDqNjPn1Hi/2JIwBZEdriGQP+bwCjc04PDKr/GizqJzFj2GMTSJ03i9klf24UIlOKpmP2QMJjEgdGAaWGi6+dUS6mQeJxTZADGNIQqK04yi92e5XDT7xdfbiw5aLzaNitkF5q+za/GPdVIhyjyanM/FeMwMVJ9i+kdwfu+Osn92DxGNj2Il1rwBxdWdB/GVSkzewtVqe0EChF3zyUhcsYo1EJjIC+ea5Lta88cDNNABlWWmNYKeExhyjVx/HZ84wMFjukYmptdOor5yiL1in6KxQigW7yPF9ivGCV8g2rQTlPG40drvDfv2ED1G7Tmaq3SwVs/NroYhmB3lPvcf2j3FjoeuPLO1RgAu8IjPfTJHda+G5jbAERNrBSWlYikfZOVY3jDwEgBlIrKDNMPkmgATGhdh9LjQ4puQe8lYe8tbrkM/A3yJdiiZImGQkhaiJyR9C4RwDR2a3mDWELifPZx7lHzXcMYZhoJJFf7ynC+GsEkTUtpnEdjZDsIbIzWG3Pexunmir+HM8nUkvOeXVv8YC+XThBch3cpBA2R0+JNhC0XrOHEiIPM+Q7X4RFasoOvq7UlOvGQ2QdpELNfY+MhtHC9Qgad7Ro/WTOMYjPsTtYnEQqPSyz/N2oEVmTeEnJVGM0atxBxmDmXcWnEop546lWcaIo8RoLPgksXIkqT/S+/i6b2AzUeUex/pj8OiZzFaf9FbucQOROkScxDHEdC8uwnJ945XVpUi08uP7KDxqxpspBOv4ix/oKoQbj7LIMW51HZ1CiGRRf2Nh4LJSbMlwo6uARFt+Hf7RnCOArvofq8VHksm1rQce+W5fpDAOiiCZDWeSMadmyRiKPdEoXiUeMMT6HrJfxZ0PDsGRBwGk2jFG8Pa1KDRQ7QGf8JHzQ7mVXvuaBwIQtMthA5LbjWT3x2/TAxWqh8Mj/CEVqBlzL25aLT7qZMb+3kLsIWXBknAtDJEAMfJrlFXEe9OYQjojJR69HXe/7KegID5dWEC8FxcccwsJjaDYVfG5uydaxJNCFkUi8oHE5vr5gBR7KA0kL2KzrDDtZjymkf3BecychuS6Pyo9aH0Y7El57Qr6hoJPOcyoh9MoHilNv5UyHWRv3TmiKpU54CV3LHYbfbvNjw9zQwX1nvKQzeIUsb21J8+wb97HK+J1+dqBTKPT68IROOHRiESONEAe85GKPUAe7cM98q791CDOR4r91GMpmL6rgG9cwJhIUhgXkPdSQ8NZI/nh9voLecg36/dICdSBop0ZyjqWHbQxi5Yz95NIPLSHDU9pKA7XXbvdDNfIgeFj9OQyUC0/2eO4zuP0IKnPoHEM20AZQLrZCEW5yJ2o3GxuRhwFIy/kZkYTdpVdh6IcLhxhUQ5SKrsq7jRvuPIqsQZIo9ExzL+ItNen4Tjar34OIGN1gdhLr/U8yJ4W3zJ+h4p8Zr19jIvX/rVrvL8f3OO1FoRsPOSz7SDPbKabzNaehG98j5TFSGMI7rGFH1URLxLR9bNjNmlN8IixzxTCIo8Nuz3cdKfa4JcdZ8BoCnPQh1K43glJ5gYZw/bfRO16lgJdTbmze7TcGg/5rcAThnEDu5ty7zBXP1+QXFf3I8VwI9PSmavP8HglVXe7PFafF4sY7CDhHJc+kmlQSqOi7LhuD4dFxlx+bBqvrz/oe/Y6JF4xsBR2RaRmWiZSq4zWvm9khqpKz+q1vRZv78FLVjOFLCYmKEZT7iBZjGRm2RGpkJ3JDNUeJdjkNMBI2MbsjUR7MeUti27DHfKaE0h6tecT2cx7f5aUjaQxWbcVoLGe25OYgsmb/V62Hk1hoiy53puDFIf5HMDc4cP16ynHrg0kI7t7vPC4fjscHJGu9zArrWkvea2QLfm/gDxLu85jHEdNxFd9Zq3JVzKeGZLImGoHSTpDJbz7wgvHWBSJDKnHqEJKDYfYQGhAvrbjGc0YraZEWzXxco8HT65t7ygiYXKjhUEp+f6hDmfSK7Za1cOBkTPsv761+640m8Vt15Q4qLHsGiB9oqNFXAKDLI8Yfwzg6JcVjnk+Y95xlvCOLE41nfVtV6Akw4bKOcUWi2IQRUdFpTNqqdDogO0OUltI8fhMHjJwTGTzVAbdUC6eTBGEqM6tW7jxKjU6w4ITGvPs2h9rBs8qQTIrWAMbVHagTgRTj7I11XtHr0AKRf+MxpR/eDuz3ciKGAzzEqwhbBEQxBLIiG7CJEQB0Ujw/u/D/3k9VvXhJgk+VXZ1RnP3yy6vdfUGSA6qR7oCkjtBnw+lFA/KFnrPAk52NBcaQMnN6JxgNI0IIMOhwWiLhb3Gm3m0GvHQkrgzOo/5FHY6aZtKlDidOM15pCx3r2FurYVJXOxVO8ai2oyvIpDsCj4q+qicoQj2P5rsi7bZ5tIULEesp5HZFZD+kCZivOxqaEw35mxJriOQ/hnDZc8N99WTfGSpAWVXiIPC/pHOtWlGlsuEpOy0HBksNjQACX354x8xP7wKznw5xbGcmLTWJ14yBJBY6WpXgD35DHEgqWUlZ/5tZpJWnjCJMVIxvQeBHAY7NkKLK+R+C00qR7jfHZFakwyJWQSZxprr4yCca/EHv0S+88pJmgZiFVQE+HREjH6F9Y2uEMyTgo9wOHDs4Y++QhR5MNx59ylAEX6E+zypUdcTx9n/+kU2c7H40rcm9EgQUpg0KLrUBxz1ffzjG8diu9XJ12IzCDj64672qmaaapxtw6KWpL34YTg0lnNyXTn2PAAG2bu7rSOJms5gs9gJRSTZwvMDID0z4+99hBAfUOTUcHTtyCGz14BymuvvuDuiHh8Eyf8pMA4MHZpgLw9i8+WZUpA1Pryzhe7T6CMtE+Oa07tpBE4NWROlELDAo4s4uH4EeuKVwzZRR8ehdiVrGoww/BrgiGPjQJz0pUD5wymasNlJnBYicX3HtGb0I9FwqUhtfTW1mQNDSenq2pT3RGshWOT0qC3O+iCbX+/48diAtCfjCpNL8/UpWdf3sL/1LT7HSa0E/KzD0CdATkI1Ir6T3QaVrwvI78eho476GVFIX3xBawa72rlizpl7M4gEZqUM26vpeopPDY6y2WKjsEcr+gu7EnfRjYgZCweGJgGhmDszH39B7JHQo6QpyAFGFt/bu69/a1uNWIB5A7s9PR1Ri6YPBcyaI4XUeuLiqPWkpSYabzAUF/MFGn3mng+m0PIRZ1GR20GfMwEf1kDioO0wKefa2Oz9gA97RHzyl5wY0MgdUtt05N4d8vvX0JGs6OKCdTB8b15KXyBZmxZDH5iSVlr7HNVc3B4fnmDUN56/tpjPTM6wF3+me2cIPerkkJR+RDEq3INM0mngEbq8/PF0m7UUrDVj+ObPq6PcajSigVL7WG+yByappODtwiuBEQ1J4hpz7WiMkLgd7tJmU2s2S3JnbmaMs6/U9bkS8e4vJDsTvsxeiXgnsFlTOWaNj4CJ1cbL5vT6JvuiQckZh2a8YDiIn2Gxg34JLEYKmw+WlrpB6Xtt6YoXsFMvTvEVwqEIKwQiusRnxSQqko0/I8LDjggkyIQ4AERAqZV0+eXhx9MfEYucuvH269PdD5c/sMhbw4XKzhD6wqORF2OoFCyx17FgOc+eYHheGzHVqMWoxZ3ezEjPjFbX5QYZ7yGlzaZdAX5eP1qwx5LXOvYAyIFIMRGoxGqjIG9fHJCtW6e9rnkpgBEcxkZo7VTk5tNcLLbZ6giIV/VZQHFt5sqL4xwdzi9kbnetkV12xp5QLIvNIZKFnpgRGNGQECCEOxUS4UWoycsvL6++uTudbDaV9puvv/7z7kcB8SgsXh+gHwCiURy7xRBMkr4GlVGHWxfIDI2jILuiAvkB8fDfxSs5g9A3He05b2+11lHeo6NFe5BnyCeR9hxID/rMJM2tYRIw3j4oDol+BJKvriEvggmGORQgwAjTN1Xl6DwEhewI8YwRkBnvmSN8msDdX15spoOb69hQClBmp+2DSD13b94fDY8JR4TBUorxCwI+bqaRiUYY36S3by9Fb/U5HfWhF5nPfNBBWvEA5+nreF4Bq23fE8ze6fJ2VzYwzHhPejQ5r9mQKET6gcaunV4FyJu5mvZH+HTgJy+QkouKLOe6O7CjjwYsmsGGmXok5CNU/j+pwwu+qAl3CLLXNPaWIltox/BoCo0e60FAi26ErJ4iFGRSv/RRrTThWc+2wp6aQuBx5AoDhZz8iF6UngSJv4JGZAMy9GMCseCotaWjFCPPFvLcsNlp8Gev0BzGy65IuByab7hBVv7aYemzU+oxTex0NXPdwc1iP8ISht2DDTODXWNToNNpqEd4dCvkBot7rxcCQGujGR3YcOw0WKRpwWI9oR51NA158WpOjQce4dtIeGJxRHzGqR1rFiwaXt2z7gniE4szQZOvF6IfO9CjndLiPaxN6SOcc1A72R0LZ3uBOI4MTQthrCU4wYvaYF++NS6TLVCyxVNBHoXIH3Ti8njUvta6OqANJUFj+9i0X6MpO4ENGs1YY7QhYpCdwPbADwT6sN0SLBPt0Mx2rjUW3tXhxvJphb2JAP7E69rUVSccGm3ujYCRD3o1DVnuC4SKTEdbh0Zgl1bMegp2PULD7dHRKMranl/qybhgBcwekduNCnkYzjbWOiakNCT5PRybKguHp6GGqOz5AhjCh3OdYAzSQZoRJHK41DlV49GkAuDgUojk9oiOrEh4wzDvkYLjlYb3IONJ9vRmREyoAIt+gyw8kpsR12oCj22ttXT+D5fG1COwzOHh1bGAWAHptBn9mILVDQugUMBENXKNfO1MDYjEoclI+GxWYJfRXgm16IaaBRSTAF+71w3GabXrubiEY5yRjMeNmc1LcCfjj1kUXgY7P5Exrw03YI4MdtNwaC6NQWWyjyW4RkJCJG6MdmhHbHY/iIQgW3j9VB2vXB3FYcKhsTueWMiIDzIcbGuhwaNZegwTlLsUBT6sGuQTHa87LjZQDHMNm3TrIR4Lhz+wPW/46rnsntkcAUgQupZRzOEAkcCuMkhY2msYXxb6QC5mSa69YAj2LCSeGzwGr0ozsYztjLkUNZK0bpBhr+HdsOAR8UrOzPujVtJbrTDVDcjGpCAoJhgejvpoV2CIuCCZwcecKKX0DHD0G6SWYTFGAkTw8Z9HMBnPF5paNIdG58e19jEvj/sDcr8NEZ0KUZFrbNdg+9XR63u4PNbUPRiFFNp5aXSbzYJNL/ulH5m78Htjlp2xWz86QNeZze7H5GiKLKVgY6J9VEXFxdnriIpMGgLHstaVq/FUoWrN6FUQT1emGCtOjsfCZAXDI1+ohb1OzagfycGiiUbkpZlr05DTy3aTrefYrzHYLPNorNVVzM32EytaDAFkNNFAEkDSQMmLSDkk1+LgxmtQc3YZVt8Mm+dn5F+fxI1MrB3Y4pSaGQvtCF8H+AiIcXsU9YiK5vgyn3BnBIyoRduIRUO+3CNzPkSKAyzsts4ze43caVi4SGt9gQgyQHYw0tbs5nIuJUmx2V/j5ZlyaaQZvapitF+jE+t3l+TWCB8/dzmFdxjiXEM4OEUGxhnrIfhYHs1Qkgch0g02gR8yhtpmoo8CI6isHkNrvO5p9qwqfRQe8zlNLowQycJIF8KQba7bYAuB8P2AOPEen07hGlJyz1j7c8NgUofwrpN1TxfBR1YAUtjkyMcd8lXpIiAZQ5s9QTOnpOyS22h2ttD4T+C3TzLV6WdXN9c4Eu5xgHq1WT9i6NQXSCS7DXZ0vMK1iPgYGA2N7KIZgXwrP0ZsmOm3fmJeOOGeA5+IokcO0ow+da+eeJWRfiLeo2W6sZ9kB3woyTvkHVP3qHi8CxSSqOm3Z/IKOeOPUKvIpQBSOJSMm2PU40qsiASNBsf0rnWIcE9xgCgW10csdShL0ocA8pXGn6EUM0WT1poFlUOzoxsz/NgR8Rxpf2b245gf3lns7nMNMCJZLk1DpmYMhihE9tyUbTMXp7bZQmJmaNbyHheg0X1r2AyJQxEVB5UHTDbBcHuDBvUIEqGY18xLSNeqNwsSLn3MHuTFj/JlkELjB+bTZMYQXKZfvXOLNFiueEQvZoLGbbb511nhI7lQODN8a74Q9egHTHQYa7YVn0m8hpddzVzdhR1YhI2wj4tiPc1eG26AxIGB2wG7vdaaNR7RkKEV/+r8TI8mZSE3/syAY6vEAGsnsCViGABQxMc+F3jM3eZ6E3sUG2A8EPkxe40jY5U9B0HSy8x6mBR49PKeCj5CHG3544UwMtePdsg8DWW5M9azVZEfRoX4Pn3Nh9H226NP2xtdNEtNbjxguHrYt5GhodAntKMv/eBw/yqpw4saTXGRdZARkZy5GfYafTRTPcjLKTI7ow92nmyymQmSNO1Sj5EA2UODxRYf7sxMZZt6NELGeArPzyhbGDXiiUZkgnKSAPkWchTWAT+GBA1ujPnXEtKL4hEHl/UOSEqiIP0JwzDXokrQZDNXN19b2NE2P7HXicSWUINxP18IGKPgzF8c3p0n5QPOIksjNqrOPEXj9T3e0FW1ua4lH25fJ3VYwUdzYwqaA4D7t0hC4doNReijyM9oLbPNBh4J9kiaN5NYhOevr2BjlP3oWEh92e8shLlGGAFEkc1LiXKK2Fs4spPCiSmHZirJH7DX1FW4jrwmYRgRSIfjE5lrBLHHCIbnNCkYvFsVOEVuBkYZJI1di7FuOLJRlOfdGfBotroHApwfaQ8U8w1DwDhsdR+FP+1bdoZ8ACV4NBV5Q4FuW9eXCz76owqmGO1n9xUGb2oFqQ8KKEapWRnrstYZE181JY6Mt8+QpQnq0A/SCs68YWGWh0OSgUI/lpONDDzCmN0jPE4wtsmegLxMk130dhMQ94yhCA9bGWw0Ip61V0H6UKlo6HoS04qIz+eJSy2L94RyFCJruBnXR7ncoRAJ93DYVj+ecijA+XCPm+xuv46RzaNrYR0DiTBfZq0P12Jn/lpwdEdbp3tzsu9XDfmsYA+7AckyN6Zm+MD5Vv34WXwwasP7tWHjQp84jJUbqhM2WoxoeMTD4aPEBwYSWSPmuO2cYWe7q7YkX0OSj6g41npUVABN4DgxCRyHZgw44ln7iD0CkZA5NZE41DLqroUnuTRmsWOufb/Q1fPN8rlhLbaPqcj0TD3NNdWj6M+9eHglsOsNmv334uyzAeLhY/dgKbYhEhAiv3MqNSlMWi775uFl75AXQ91q8xn8XFnmUXzvTc2Ao/h4FMl0JGIa69Vqy1h7eyHfiPtAnsIW76x168dSlhULT0C2X43F/hnqcPgk0DjAiH89sjN9gSTUI4Z2ZAmR6MhDVD0eUYx81OOKrqwaN/CYT36Emc5HujDU6EfOBbu7Mbl5SRbywALytJRTKBaeBWcAMjoLjRWtXdgGxxwhnrB0OIqRscZEA0Vjnqdx230jSL4gIKvL1VAo3u+yj75Cp+nf9EBSV4wwRAV92H6D3BkgDhj9hMmufGGFecpkk8RGQ3b4G945w6VK3N3rmiqFdkxPhirxX5ec4SY/EzlDlGTFHsWx0lT4XANHbHV0dF0BSUKTOSKXSgorqHiSuWYmgDk12vlQV/gzSArO8GW03Z0pCMKTZgjSyOU6QjyAmR1dPTSFvSYLsy43Z4hbJS47CZ3INdKd6+Re7sPx/kbrnZeF4yyrMHQGOQR7GOQQn432ma1qtCyhx3262RWGWAnIjWc0q9qnplTYTPuJyE4e8qEWxXucfc5rxsXGn6EiF//aoCi2KMrhXwNGdOR0Zw6xyM549tpfvdYGjZsE9pXhUNi7FiI7Z0gG2/QiZ6y2U1Xjsry/8HGZATl9bPZKmGo8bLjIuwuj/pG11j+KY6qHZ81vZER80ImwWiKvrQCQN/cPNzcvdIdsX6YC6tFcGIgcDTMuWatXYzGewKJWVIb72fRk05jY/GnkrzManngs3waGahQf9Y8cETvdMwHI6HfFYGfokYPW+fwMuRkcGleOCwmEphoPSOgAFr3xGpEaEiEk4stk2hCHRltcBCgp7snxFA7FmAYA+10GO4DY1bhwuz+Kae1Mk2LlRPuy1vtvIvEV/uDsLhDHZYG7nfYQj5b5NCZv5NfcvKyG7HtjWG1ke9bbeorVq0Ezdl8hv7k6BjAj2CMe39rQxVe0aVKoDU+3ZcDQziLvvcbB5tB9C5wr5uPT9r4Aj0uJT7CK9rBHpOcIiwpIsaPFw1GJwmX2W9sIcc4R93kCktwg850FH46rrYOk0x0dryIQyf1RwuPh7WF3cyGy5qWcmygV3VzxCo14wHKvABIklsl+U9+M+HhZzycRcfyOz6GJsTaH5ub2VQBphrqUZTW7tjOzP+AMIHqCppAZ4R1gWQGfkq0eo7/Q22f6aS5WqsYgn7jXyITNdkNWIBKlyAEpAPr4HqSoLpIzAIlwiqIerctJBxh3SH2CpmlGe/LjSrBESUYrF7lCnXV5fMp+Ll/sBOMdVrtmpcBBI+lD8DhyNDlBHNr2KpyKQzE4PEUOqJDcQaMB0Yt7eqTUJIw12xXkA5B09Siho+do7u/vb24I+7xQSW6VPXIQIzczSnJFs/O1MWkQFDcMbptnuD8i4zv/oCZYhOygfGEDcfMUNk+7BiDZ5r80i1qzuj5W/3UsyEofxcGiQXEgcqk2k3fdF8epIAnwHMGiNCRbv72uR58vojzeP8PFEZJwB7uT1x0U/8fc6hiTa3fHUJCLL9MRSJQjx5WEPjRkYJFgODvxuJ+j8VoKMV5WYI18IfHwSF6Le88rDEUpLOLYgMoG5HOrLL6fyUOD3bvsntRcNFEZajH1IlIfSxDMIOSIOy4Nr8KchKEPqkn2xSGzywBzdCxoZaAHGsNS2PAgGgwpgUw0As3FYAfhybAuzxKuDAUUB6/I5WBFZ9WG7SbbO16VqwksmskGiSz3aaphIYLiPsmeJ145Dmqj7aYauRI2uhoMcWbIFmrtYNFcme53BYmSWgi/PYppYbCrKFckBNqBjdGWucateaaGjAzhHCReacOKOyJ6dAq0onFEIMFhDcdFjNLHcy9++KtxGXkMQHbvNe41lbltmZGwdnD8Bjk7DHFktDkwmSLMdTg0PRLgSxMzZRgZmjUI6X4MBT7CofiVhI848+rHSmGTKZQUFiGPO7I9CgkEI/zI4ie6kQ7D39GSe9EeiGg4Icizz1+z0JGQdSp0twJ7tdf9fKHDsHsMQznCby3mWGCsri7stW6QaEkdxh3yWY/MdbcC+yLeei2aeUM4rJKFWp6fYVUbDeaZlVDkW+gvfVA/rsBy2R72e+Vdt42Ow3ySPX+0m+0VPjRfE+1ZvGsH4tLyajHxxVhD3vUKFDHbzE0xZFb7jEHRs9dPYaqfxLVsZ79CezT9dKG3F0YD9hiWUtzGPnq5GcedDM14YsFxCCdruCpIdo8P7+brttmoyDDPgBJjjUw8PjwQEpePLVS+hFOTSUKE1/RIsByGCcnC46g2S0I3RoOhR3q6HlfH8dTH8GdimlS/h8QKiei5pAbCpsJlwrJre8BihcIRPmtPNMI9FIxPa60VhGasni4LhbMi4uNIxJ/h8igVCU80Gj2xvYEmK3sw2GBR3N7URGCkw1g7Km3UXtb23HnWcKpIn2af40jPAdLz1u7RgEHnLNikqqbwKshGYg8Ph0XAEek9ryxJj4qbtUY73tzjZb+ITwPi+E+FSbQltHjUiHVAru1+kZ1wePUs6LRAsd+LY1FTkdYaDC6vsludTyawqz4cNkfkVuoaMt0YyRn8GfC4HVDxayWvR324hXvSqYlSn3ZnjgdCPuLX1oONO3NlwMzS8Hz+WjqS4WaqEs8HXuEGRDPagJDlzBxrgCh8coks6tJHvr1w+HRpIuTjZLNIEfsNhjBcGRAJje4ZTHY0cz1IhLn2P2jLVgNPnBp8bHnZFy/68EfPs4fmk0h2ynOrx56RC6umLnDov0HhzrwU48KbdpWYNQidQqYynOGdbleA+lTpGUMk+hEQohM39pq/Lg42xjoNtjYr4UjftQT1ZnZ7dB9bUCQSGQFIlg/dk5LEUl/XLNJM0JhnzSkCkO7KhNmmz1C/x/xHgj3swCLrtOPOeIKmHeydcVKtHOFuq6GhIWu8WY9spvvaFCQ/Io8ttShU3giNIjI1z1GM8/+FqZbwUaQ944wfyKXCJ8RSj2vFuO5mV0jc99rzal4NaxjoajNkEetZR4cPLQkKG4+jUcGzhVXdY1B01hqyiMJH4+bOsJOEwxAWEb82bSksAsV4+RrlmFuutaPQvog9dgLbEPhPP8hueIxpKSBRAslpPD9DIQV2u4KP63sf0dIlZh1dOw7NmxjVHP61tvgafYwHaEw9RkGuAxKXWwh8wJV5kDAF+TeAfOmwOLi0EovN4zOr4W4oirtOFINchIXO5kJng8CgVT7qUMjriSmciT7iz4xoT6dmWPVOXIMR7trRzLYAiVhqwxOPs51LQHRcbn2aI0wfx+OBRkP6ubDa+NXHiPXAENhrxqWgEeXW1JtI4u3IfIOl9pIKRLa8ekluD2we0wBO+x0L4V3Xc+w6hq3m557FFg61AaeBcRlUEU2FoJDIYxaGS4rd22/lZ+51+g5Asl4KkKhFByKGWzs14pSgcz6GxIETxy0qKcwdD70iYcNg481wg9QnUQHI4WN/RUg8YcjuYT6tJpsqHg4eIbs9WhJ7mUfaoZ4QnprxCh/P0bTRhkjOePRRjIZDemiuigiIw62Fhnwhja8ByQw+coNsP8bqzOKnZDRzPVoF5Kyp6Kj4LnnZozgS1gNyv17LKWL0Iya7gcgh6TZMtsDXDTTacIv1WL6QO6VB0Yz2T88DZL4WZ+R+dWhJPjPXuRbq8nCYFZuxvamrM9hLhyErtCOCN9mrIpfdE846Vwgky1CnZ8Ou4scUBsbx3ocFfRyLABPZNDXkW+PhV5doKF7a1dEstfTjEeSRM3RHBnENHnlQ07q65M94ywLMA5CCI+TjUuJtLjFOj3Z5dMvd1AryVCWQ2OsJRLZnrVn6OEM9wmctpYC82IwvZjXPajPstYd7oIBkzLe/f7gFjQKhUCkGJHFqXmTqWeEyC8Z1XOYALA8iwdg5ixSGrAYad2ZireZaKJTUBprhYM+BzXjW9mKcGewZ9RF1ELyPrMAjWOTUd0c8az79QwJzC0f3ryX0tWY8rkFxm5pyJRaZ7Jq1h7n2JkPhUet6jDhjGwONeX8EkDTOWKAHRuwn7o5tsZHpy8w3Fjp/LdHFFH59zIjP/oxcFGT5M/qa8LCBYgyoqAJIzoJgJmhutPFsoJ+eZ7IvWI6/4Vob8mbIJ/86IOmgrNxM1lKwOfR4swWQ5siAR05TN07y94ZTKzpDwFd3JgactbDUoOdozIlBQDolGFns8rAB5ZLD9lskxT3WpyB55BdBHyuEjN7CeBCJ+kcWoXB3ZuDVid0dC0Hqw9Zm9fWxDPafNNLMgVK7d8gc/ighLOr432+yu3J8P5Bov5Nqnj1wBI2GyrxPglMLQEZ6hhsk6+/nBcZrao8DE0D6KdA3kYn0w+YOCY9aMz4WkKSbi4XN3ptOARYRqQyR/cJCCex14w+B5LQ0ZOcMyF/DWiNxZhyJa4pmJgsvU02Swg6D3foxCh+P2GybT3GUBJ74NAy0T/1oyWsG5BIVr85rrDSwRKRf7VHxR87cH9fB4QVJuCdndgn1qBXtMzktRQxCW54Lh7MLhGu5GTFxz13n/dFjPjojPRh+L04im0/0DC8b88wHEk2KJfJKJc4f6yVyRHuqkAIU8mu5PBY8yV27sXZyQE56TwObSc9QIj5vjVBB0bXhSF/zI96/xno7GBcogsZRkQvTtxkoddx4MywgySc0KupDifjsvn7S4myAFLOKCkSEH7usQlB0YOLSeLgnh+4tDyIRhIRFBJIr5OlsfyG6sVqwNynDFY4Ee4LIWy/vu1r+OvpnvIPmIZI1OvATeUPLAphMuhE9W0PyRSsNUsys9ngIm11sjrQHdwXIKvHJPwYUXdTx03py2F5YCGtd3QpdkusONiEfV4+QQ9GPgwqN+ryYAkHHKxEfXwsmy6VBNXrCkJj4cYzdEwIPhkgcGjQlHYZgk+aZoz06XP2FSIl+K04gTLsNKnsQKStBqYXdlns9e2giHA7544V7E/dgYaxdP3o0fL8il2/GwtulcTC6vYbCPsdcqUgY3j8YBMWBJQb77/u/nxmHjM7rACRn73eta2TvpvqRteEBvq7rgeqd150hPmhHZDcqFCYRLBu3p1M52NvSijTiOXGvLTa6MQCpcDjEUABHJVQvfiQUkUHEfKoIsq01p4O+aFu4ErNOhQaiH7IS8kfDowjWNWdgMmrNSBz6enzMIRXp2TQg1yrIRTOGYkxjbex9thlq2F71oxVA5osfVXa2nY6Lua4UIZT8wWx1pArNz5bUFhwx2c+fJwUeA43vjlcL6zwE5E8X+oGbZAfF3ZnhnIiELT4N4ceo8EkgwtpuMxAAxEVgfGStqwCyHe0aT9ERHyQeDYgEkmtAfDZ0WYNhE+eeI87ocBt0pk2BzwH0xQDx0o/CIgFIPnSifwDSA5DpYmckvEalEAsXZTCcneoRc93Bx7OAlGLU7ifj3FzvBsMBolvtHrQX78YFIgEgLrYXUMR0igcxN93esyAkgkfMNsKcGjD5L2lnthtbEUNRPgLxwiQEAsQcJGgCQVcRAsRl5v8/hr28PbQ5fSCAT5Vdnbxuucrz/9SQVo0u6OLa1uLIGhzenvaBAI0mHRzA7nWW/2jVSPV1jvtgj6On4jNkUxiJA0Otv853rZHsiPFBsnGFewLNGqa5GlTAkmzKfAVJckgovgtHRX5ULnHgOMlmhqOhGQXYEZx5tILsRs0iOPSjHY9WjIIh3fZgRqFFAnEejyxOt/N78r7ODrmczi7r16obgCPYMwObXb3swaQjM3x5acf+GtJ9jbNH61MAqa2fETe848r+720q9lNypVNAc/LPVc8F35QdAcQHiiDzJiBrmKZpihZGPaIYkV1BA+ODkJgzCGOxuPboSFpKzXSFo30tnmjMR+TWj5cwaphA005xbbyOjP24SDQq+87GGZ7Ba5hdPqjFdoj/GM2ae9ArrSDXJc15dTgbh/ipgZ3VM0YlV3XryCMJgSByX9emarZXxa6Q/T0W2NmBUWLX1BiKkj1PBYmG/C/d9nrmsC9rjpzHcrk5wHAg6TGvEt212cUK+srfE0y0/eI1gIboDCCcm3pAGRsoNga3YuRvu2BhqhYwrRuNvB61bxW7mu8e4gnIy1e7bYrheMHPw9sReybwd8GguTgdl5cj+lH/j7jMuB3hNVEzUci6Lw8kpowLunTQx5WNxNkzM+MKjMcUcWf31G2NNzyd4SvprMBYw7kqF/cbu8O1kBBz4mCZY4YQeZShQ4cfuwT7gTBNQxIpPP7nKxtLxnjkh6VROLm4loib/VLYEy/UZ1q5ZrV2/YxNmdXeDMl2dAYOA2jLfsmjdzCBcBnZQLK6Stm2ZktRLgKK3pNS8eoxS9wMS+YiRqsUKUjh0tXX83pEMYqRjaudWMSOyTJsU6jGH7vrHqz7h1/xgSIucfez/9tue35EJia5sBH9hNwDsC0cmxEchcxNLqABgGLd0r5KaPIgIOqedj6uwzNl09z9V7dPhgc5wnk+rqciwLw56hUcwuAsANnMCpEtsmaEm3ZermjGsPevhCG2tTXi1opme4ThMOil8D2KgUtbM18GP7aA5Et/+Bo/syCp73Ok6F2B0ik+l0iA9MTXLFh4pPUjgNTuclf0I+d5PkL3bOwYV14rgM3qds1jU3MClA4UblBuBQlLFdnNezpGs92PFTN0TynapVRXAMuvpRm1wic+SEyXjzjPR1cshC3DBpLPbdKwXvjvTSCd/Siy5xHgQQnDYxB7AAkWjcOlHNOeCWw2+dxQTHf46whxfWYQAs5V7fBMm9e7Q25KPxlnnKY+SyYi6XNV1w0H5Kq+ZnUBNmuICYaUXwcSY6KmjlFDc3nT1OHCxzjREcCXtAi2WgEAxDgCyOwB6bsa7/iOzRRRqOCShQMU3T/cJYaudrUtg1kDJk+zcvdMpOV9tPQb0n7xCNGIHEAEkWpSgUFD2lkYM8/zvr67u9uO8acOmQvNGNuacWyWjUKfveeuBorZA7JHK3QuBXyZ1utoOM4lvctn6uEI0U8K5tfjceBHpz+ubqRw3I9aLsPO+/rGdX1sSWpMLosGhpXNjf2qtCFlXfF+ZLezJ9uSoh2ZyC5EQu4iJW4NuUsLeUOiHl20ENMVRkHmHhXpRMii73axQsaw05iJXEj2jeCMhS9r+Ex25cjhg+4I4A57xiRwhNkpTtGCiGtbZOP64Y7rmtN/u7JfrvC1X45wK8YVlmk8+udKyc2K176q9UHOEp/GFJvICLeWtHntjLO/mjNvd4a4voKfFzT997zNGoy4edx0L3RkVdDsqR/jC58wtp2OXdCVuRS2sj+PDyJA44fj5SN4bqebkZBL9Uwk+PiuXl4fu3pMOe+jFOT9rZrXHkKz2uNO1NB5PeI+sM4b7oFHk0dqGpK+qZFWjuIx/rrbkbLjaJePYeiyV9/RFs853sH+PSAdK7QhA8Us9iJ+NwxLIgBg2daSRe0On0pDuORN9yPf92jIJgA5eCR8HROHGak5oCsk7qoFK0e4D19GwBA4Uq9QlsxxCs2KXztyXR6fcT5CKMaYQhPe8Iu2Ho0gMVLEuxMpJP3IOCQubGESr0+TlaPdkB7zOi3tpRjDBylgohyNwY5hh2aMoUhxcZ+OWACV+X5E/FOBITkV44IEkUZibvSkg4MmtCOojG5SEAAEhhw4Q/gf4ex/C8i5swEauFxjFTh6TfhwN93L1J42aSbNx2xmaSL3bQ3PCa+rF8B+RAqMsarp47FV7njDkTDI4jNu7EntYR9aQG71SELFjHcdbw+I/BxURj6uXo4SYVu7mOsj+KOtbMDoKa+fdDNS39j8ZCJSeBz9kLQ+1F/YhK+PGWc9gYaNWrzpfoQyfu3tqlftk2wzbmytazxCSOnF8j9K2Lq2n6fOrsCmzDDTcjMrl8XzEZL4N4D0Ve2NgvSPRh4Kc9/Wm6re1TQeH8Dnhs3b07OsmfKG2xGZ/scGY579cBTHrIlluZ+S3qbBYjwbJbR5PhqRtrN1f++GpLvC0IAcFyRg5L7OglcEhnWUX+MWDyR65wMSxVi9zQBgenuymIt9j6J0xln5Ip1REZe2nY+T3QM3LWPmmJJrf48ouLZtmjPK5HAcPmtWHGCcgcNZgh3d7K87kkaWuKzsuK6B5HMRgLRuRDz1DbktnG5Mkc9JnQ7wWyHsVfOKauympBCI7Lu6WpzNMnFX09oM6hSK3POMtHp8K4E3kxY2N5U0HHtGl8fFtf8RTG6POGsZ2JOQi0ji+UgWrvpKiZMijnkdFdjRVurSuT0SrKzmcsXCNrAFQUBJNZfPMUyzSwzx/ExXe8Ox4zOwa/pu0Mjj0QQUsWfqqj4dQbPyH3dzisqAXI0B0I/l+xEUHwCkGC0B8vkIlyljQv4no8ZMKtFo1GECMwiYhA8LjKaZf+1qBYdkvHei2VaQzjzrCTRiA0dxvR7FhTlg2boQXM4PaLTjDP2o2zpGxDlRnNU+SP48CnLgCAqDmS4stijycMW5r1V3TWCGu7qTfKDo/ugQjfvZi6p7uOPXOQHbpGPmU6SbBySeJfi4ABt267J+PyOGpskUP2u4N8kUIvEDKKuHuCiuajG2iw4fqJ4R9nR4gAzEAKSMbClGfcmfDEig50lxZWXzcWzzGgln36x3NRJ3RRd4DO7A4dBO79Hu2i5ocimgSQ5nQJc+ULc7VPBz3pA+ZuojoKQ3rq0aq8dbzsfVUcrGTLkeS3ZyD8oRL6TaiEPONmMpxUfS8exgWjkI6dHKEWa3D4wru+FIYGba+Az8nq0+PkXn17VX5uN2mzPrxlwbjGKRVpGYNBbzvhYHhKEbXeZqEhatGi31M8EIy/g1GLQxIwE9HZBGZdrXLEl+GIfbGXloR9qCUynJTKWQPFZec9yvyMAdVdgToqkV2hFHuAQOSO2Ky+wahcHh2zZsYNWsGSkGEt1SqtTidTkXIgk0SnSxAod6QLaKJGroIhoWeWc5E8kU/sfoSho3tqjTHiV7JFK18AnT2oOvWWTjFnHc5CY+Z9PYYYVFkXPEb/p8PO4D2Q1yIfLNdloFLZurfY++DmIHIqMhACpRwjc2zh64Q4btGX+6hkwxsWs7fTif1XTtsXFT0NVXNphczexFyN5jY3d54cSwoURlCCc/Yl6jIvcIbBC4q6/hQBA+EWwGdAUEg6+Zw83LHT5gNF2aRcyQALabnGHL2NGDmJwzGM4eky0ZA7MVpOtdq4wG6R4V93aK79LCnU6xH447fG0f5PjBs3ThbOIwSjL2JIjPVHYsGZk1gqOkMYhwtDDMalGAMnpUPKR1XXC8wx8OKMHjv7SyQaMRWFe3sVdaMfmhVsFMERq+lR+uHQ9Ju8OLlctnj/zYgxUKiXuoZg+La+U4h4kXSiJCmmxdhy98ukoNjV4sNCYzHjcwL3h7eD1i1eAR96gPCl5xQs44pJzxiq9nooXm4XXUBwC5tNPExopJYwYzG0SWlb2RKTiKJW1gCof29Fzjke88WBiIbN2I6IFI0AfeYVw7QGPlqKM4z0Z0piRBbLD4HKZtJihq5+Hu6dNgQy1CSC9QB99jhw82t3PNdrIZYJyy1xuG9VAWutKkQitv6RXFnunXvqxNk+PjnRwglpj5CtjW+hy8ti1zgCS7CRBSQwMCg7fDh6lIUc/FI5I6V16MxiJWTXnEOTGaS2GatqydAOkXpG1rTlNGgw/STe0LhS23goQOBdiro32AEnLWGfudE/WIYozruu/qIaDIchauE8NFbioFIPlNsxQyfIqAZIJxAMn35DeksOaYIUeWK7pmpGZZNqwzHySs/ODsbHDWPsjpm3I0svnIgbR6hLMRHcQWcWy/Y2GSNWAUXxOHtZxM8RnkHmcFxpFgsaLYrlVweg/vSH1TY0j2owAJc28zHcPJg7YUMxzTI85EJG2xnjUsTiUXz8irB6T72ee0Ycew39jzFUwcjEbSw88dkF4g0Sqy612PJrbTw4O7JcDu/+j2uFzXgNFVXH1pVzKF/kwHSH1XqY+NSKOR9dQr21VcHb7udLPJL/M+me3a5gzYGx2pxbW91WLlQy6KjFwtu3y6b8+kVGBWewLNXzLOfJzfEy0cB+Rk42LK5IiFm/WFfHNdg8DDiAV3kZJqBIcIYRKTGtEDXllc1DljQWi8qugiDVLQrOxw0h+zTwr+RhrtefBHz0AaPsVcBLALkGdN7QOMZWA7m+I0t0cs3T2Qjn1Xx3BXw9LhmZ5cKB5/4aJmyquwGHNosnpGB16OYJAPWoB8eqim88zsgdwxaxhyWTKd/TjNSLVtv0hMqUKcNqVu/N6gNBZBY+3hb4e/Z/InLHtrpWndWEyRAWy8kDVbAQbVrC4rx01c0764O/fRhHSYUB5xEcqRiGECcqpd5e6hHylr5sXZlFkTh0dSP8PCwqbhXtdfH909mXp267IWA4YzYeE8XljmjB+OsF1cyIf3Uas7PhqQVpHi/H4gXFjuR9vVVo1xSizyPdEP+WGy7LHH2RryWMyVYoDY3ez5xgeJSSMOBHeCuMWOX3+vzJ6agS1WGCwJRK+94Xy7tAtWubhvw/lR7R95PNqcibquruUaLObiq2rX1TFl8ilcOCN+yZEf4Q/PflJi9Xp89BAa0sM9Ly5tbC5s9zcbs9pgfFY9KnYvgDocZ2CfF3QBRqKGPTWu7+szNenuj9+sBj7AsGoVdGOjDgkPzhyaoJpBk6oRb7hAqJRcndLRg4hVb8inzx3O2kI7IVcne8uTEV3s6UU6ExY8mL1dPRuP2wHpB2TS601TPcN2g4qd48PZxrV3+8PhECC06P7hOzP8+lTlXAQMpxPAnsYuQHLAtoYBzAgfuua1e0rBsGbIyDXVw5GlQyKxRKjHiM9IPju0az5g8VbdK9qxH44dMrQ//HS6q9g4Hw3HoemZwvMxPT0VvA5QOjmcN2S+HQOJeMT5YRCWePobsmYgYckYaN01hT3eHi9oHOKCHkoS5pdjpoSDRngvvk1Cn02a7o+7K7q82FPOxTq2lpqHYwWwxyOOSeMMH1Z2OTsLYHvYcLbIRTEWXbyFRutGAfBCn2Z2+8HZfDa0aSPOCENTunyyg/gzEMmaqzsyfMQAouQk+Az1kK5jxz19TsQVu4KlY9gm5BGT068ZOLLXlW2b+jVn33bjPZ1RkwYk+GN7PSdkaDjeed3BYU4/ewIabcz47CjN1o9wY3PbMy7k0mHFsCFUJJAUnzvbUe31fHTIcKzqeTN6wTBoShUiWEgL384cTd2eQjsfkBg17nPmHpBbQcJ2gni8HLc94+a4wLEScanm4umovLPEIZIjMmq6HhOHFaKZYcOgUNJ+cKdAYmrzdhzf49TRLGqtyGHk++yZsuB2KWwRvzYgM0wY6Y98sY70KQa2UOf342rYrJ8P0aIijBlx49Isk80EzLm2RWJPqMuG93WNQD+ehK53QwDWBLLb2RM4NCp3S3t+DH1vjpXdHvEBZYi30wFpPMJXLRcsiT+ulApo2kCSgHsSwA48LhXZQzVNu23z50Ayu+1d3NFeDvF6QZa/J6pdoeBdW/iJ93VVV3rGnRWuh2S2EG80tnRHgPOMCnJ7XNAVnsdsJ3XWcs+tUmr2tRhiOcR5PbpyRoa2Z7vywxZNqkeqr31fR4MKWzN3yAdW2jEl757ohzQc0YCSE7me/Edx1p5qCASh1JErCzfrFmADwuMYQ9yONBAfZw/fSvJ5O4SwqDVZ4V7rFw5IVGMsDs43Y6Meo8ZwepxtWrY136ue0eVVWDQcua6tIWkjxZjXMmQQY19HzLCVpPtJvWFl6WcjKZCwZ8Ykm1SfoxnzbTaB5FRQHC25+9mjHA1Il2D/XUdSJrG3dQ0ugSFH39thXpOPKw7hEAeHE7/GuAal4NH60cHrSe4RwccXiXgSIGHsbJUyQCzB4luIzHFIu19Kx6/hld3zDy6fq+a40LTHnZ7N0xBgt6eYDPGeNdzjr3GIR03XlxXAtpa8fkau6mvz1I37xi7Ofc13IeWMrbNwaeor285HVlrXkGXqRUI0TdzRAiOPyH497vmFPu0Jhls7priaF1fyBJHlf3yNvUqwd9PmKiwEjb6xvZ1MQdpZu8OxqzGzg5wFWW/IubOfMjgpfOHoSPaa7uHV70mOyCm+nkrDpozIIKGTNj7fpzXjmOHUXhuKfI1Gxwt7Hvs8JW9UYPMtj7jLulYy7uG2loReTTbh6zp9rgVzP4BLZOIGKrGuHb/OHZYM4Rlb2NaMgNHPx2Sg8VmN5hLjwNPRrkf4omkntR6RcJPTcZ1V0fpRh25RccRiCPSk+z+WSQMbckMKvoQliwOxGdyQkdiTExYgZMetvVqyn3hli0qiH/msC81uhwuz2BVQsqb6ujMhu2fKefseGPgrBTnhmVViWBbMRA0Hg9nDZxW8Nhgxr0XpEdda82dqN0338FSTF86XbkhK3YwWuBT4aI5L/uPFfp6e0yUseiZ75uJqgce2a9xlzyBEMdoXbm8kiRVjZJNNoQ195wQf1kn4mm1/j5exKMGBvXo/ds1rtZXaIUMozGsQ6Dvbv+zuwSUe2CPFZ8KF7LuHHTOE4PzhaTU1RiMsk812h9y+u7eFXdzqcWCIS5zItQ6NRQ6w7Q9n05D0+7GvJ1ho5txHybRhWMspXj6emIS9e6bklc1AJIOwlCR8NRBvLPr5uHzhcPaFYGFMjFO0UBCUfa0zarHHYEO6rBnHPpM+JB25dglNAzOqZvyCbEsGdj8TulaApnrjQrcfkAnFzPXhh2F4SsASNA4k4QnFhGU07PFFXf5Hjg/waB8urmVAxroLQCb8WJPqc9CQL58k+ZSs2TNgcqwZsxWvaQ25W5zl/Gs48FvhQh9ZhiIECqPr3tzXnDs+k0i0ObOotOPbwFAgnatalHM+oh2ArGsycgnTTHCmaM937RFd0DSTAoz0atZJoHS8MCZq0keqsiBNBGhg5FTMTKSuvYZszZAC+aycj4VGqUnzKjNEO8K6euYsG7cVJHg0uyrlOsLSnVIcxU4zhq+SzTBlhEHjMqIzxmHlh+OCrJb2UpAOYGeIJr4Oy4yCHDyea0gwyO7GAEYdfJcW7jD2brjHMU1rCNUoXg33zkdgZx4ugNwNKgxKdtQX2rpeXR99nGoFEWJl+LjCsBJ8gOUrm0ZDdsEC0ZnsZj/lheMMz4lxF/abuCHB4mpNAT2yUIwQcExHON9EZ2aGIQpytRDPjIo1dJg0ivORmmBx8sOzcEaHU2sGMDofFzAaj4cRhiIBz/qQq7tmvA4YtbQ/CCXZFjZMSrKt61aStc7fkNVvLwTmTGrH3bgHMUY2FGKUYwcN28QWJiUWEA+pPV1fSAw7VeIULcDipu6arTVbwSfvPdt1Ox+BYc6d8RG2Abl72guU1ZX0L932sl0z3ewdMnxXTC7xS5nWfFKMkVAhyQRsMX8i7uusemUZi76zhcTMflztmrc/3GA85IgbiMFzSFdmVfz9RR2akW0oysBeNdi2rLVEXNjV+dGbTNzw9IBWIdFvR2eGw6F28bDLzn6KY7x6hks4OoO47mjWYsh6sQyZ+OVMsy/s7+GIhA3tjAqejvrq8Rif15gzjs6gJldCbmMSCWenXuwRryYPjCPxDLJJg8Jc0xVg3NRruEIj8sIOOLqJOLY117Yejhc3BJiBcUiPRCILEiBOtBB3uA5WkYRkPOI1mkrRIjca+Yx+9B6qdvan97UWVA7xNLHPhg2zQJ5N7OPA4Z7ymoVcIkuOcIdoQKXt67ysUY5TgZ1wRFq02+eUDEBY3NlzX49ZgzTLf5SbB8mGdnczBAb2tmS2O1xMKlInMDlTNYcERTJ8KFko32Ob1/7lDe+5H+2CdIYPlzXwyxGGtm22wwcakwbW8WuryASkEOlEXFo1MwCboR8u65pu9o/sCs90tpk2cKyJwwSxOdumzmwKl8+kYjyOZIf9dR47x8JitmtOPHpAF/HCkxJsNGO1p4A4bBPbw4/MictwcqZ4DkQSEqOqq309gDIVZEYOt6+nAZqA/PCmcjSl/sv0M5P9jmNtWwxVzatPHl8I15amnGAh4vadTQBbmKyK6/y8AKTXsmZWR8gWfTIW6/mIZcNV7Rqamx2bYdPfbFpKXfq+dvj68zCxc9PyEWAKkKCw0ikeffCNTY54FSzM8Jl7H4nK9LQP+IpcY10vpzgsMnzEb3Szh2cmReebdb+UIxRZr6VHfOFxiNY90StFLN6NOo8Zo6bh+skYQyCYYLRR48A1XGzliZt0fu/8Dflhy/Q8oiE76QwqcSjALhMb9OW215GlzTFbkSKWbjQiza5Gxq0W4ua+mmE+WUJ7KruDM5YkVKweuXz29rBN2/XYIZoOYPNBPfPD3cN5P3pqHE1yIWvHHn4tUD46hu0wdg5XCLOGXdTq0duzFdyR9P5mAiRAhJ/WKzhB3LaMVaXv69MCQ8Cok22afWNjXiN6eiGsAoYM04xSLkYOh3b8GqadxoyV5MrtgTUgz6/s7QYClGXOrC4+O14Dywa5OWGBhDOU4gAT6UIFuA/L0nbcGt4PSNOhpz239WTkwpB9TVfD5ivL5kvrSU9CilTcnYu7B7zC2r72CMOhBiPWjKTTHiNQCAo/r4rXLKJhpfORsletrsLO9EcOOXhmsh8pLWQAtr7qBICobIrWjrZojiaN1WOniHdfAO7rc6PGYJQ0HLd2zGYAEtlpz3kUqSWhh7iyBUYn5c5dfSeR1dfeUEn+/t62srfr0Si87pZrQDYWYW3hIB0xbGtmxQrtguyfZ5HrJje0NyhXpBAcugRb7PqCXolnrOnVPG9HuNPDiV0LmELkVCu0bT3LBB7RjqtaAV7d9piq6Ra5OH1yIvuF2cMzDolSV5IphE3nUXRFF1AEhObsyhB3XRfkPmf6jl1ygeKZOZMKseu5IHcmhcwPDsi5rnvs8IQKc0eHCpva9oj7PQkUq+xaBL+DuewaFoisXSaN6b02as6b5MKvjBeo44ZIVtMYM1/EFnOOuBul+No2EpNtej01JGCkJemxutBxQoRgpg0A2bApdEU7drHCWDNDDBd+BZsGzzhQhK2B7Igk68Y4TYzGTcMj1UxaEgVpV89FjCyfMGuqVUoeYqimrZnVpEKibmomfoBAK8X7jBh6xMICojuJj/vx29SLR/LDcZh141kEG97TPixgTZ/aK24rxmWFnMfOJnCtYOGn9KfQWRAEkxI8HrUmrafXPB9vxrLtduwfIHMuaOTqBrnMmNWdQucVumbvhMdd1wUSSXxEAEKs7D1Wkz0NfN4i4wxaAUM4R5aROP1x9SMraEAgWnL84XVzf4lezAjNzhBfV3W3JcW2BpQoSC1qDGkGIPKMBVilP+odmWFrRI+gcSdSCXpAdh1NOcN1sgtyno+jHHGIwxA3AEkngLqtWWFW4/A5u6u7WUoDkr1JyONbExbYXNsw7Qf+RcJZ2zRgsggM7soFMfTjCSDLDQ7PsusxZWCI3re62icaKweyvI6MG0auuhl+75bN+jp2HTt+THBGQIyO9t3FbOAIbZs6JHvquSTcmiKV4pfwubJ3/0d7H7PHmXcrSX3Wjx9p6X5mhqHsbHIgLyAx83GNxscqwH60y8eqsZIq2N0MADjiCicZF0TqS5pK1yGah4udjEPS1lfxGXJxUzfeJlvYNZdrsDgu8QSkFl91AtCC4IQKmc7litfnVeyqpDOhzgWGZhZwpGkD8sPhJqxrOPDcM9lZQwlSmzPioJAr2+SKLi7uSTVDHq/sysRFTXaBIWv6U4BD39Ys6CrPJ75dp7ABOcNnxIChmOk6jr3ta1QjPOxr2JQX6hBwtHLE0YMPkqb2+rJspsdpklPRE4dBYnazB5eUGKriWjJBabUIK1OmMUmccOLX43zc5OkKMEMRNFag5myEoTv3nOhF29c9oOvjX37/49dff/rpt99++/nnF0U///zzb6Kffvr11z9+/+U97uuHmszVeT3UYCdxWCh8D1yep59N+UxO11zB6ymmOdzcE7ueqa4sEdKUoDxS9acwFsfrWI5xcOiXYyLzWkey674eajXpCxtAVq8UY/LQrflWN3tJsNgjXnGFR3SGNyMjDLmrL+ERTwvbgGR7pKaua0D5ZqX3OHjdscIfyRO/Z9moKWvmWd7V98hdfw2nhzgacrez715773BoS4bHI56fvwtf+7JeqnEFaR5++ePXn3578R/pt58EzPeqiU8mnQXtTArDcP944Vbyo1WjB9A0BhOGJdk3GkBynN5mPgQm4Q3EowPSvUgRr0cJ9lCGskUqodGK+mutPV4BualSKqbglY+rGdc4aPTazp5tznBnd6TQ2/MVBMhXnRrO57Tw2JfMN4MenVQhpsweyhW6Iak2i1ihuzW3aoxuKS5W4JTecHTlTqkAh9/C2Ls9Lp81ZHl70JBgkm/RxmQP+4Ajc9oH7OPfz6F4Dsvff7gLPVlghDYiWeeA9FXdEz842f/oF+WEZYYAaoWue2icUVg+n070QZzNd8WK+d5TDNuc8cdis6Qb22oJZh5fSPt7yqSBcZoCQ3eTckqFTjdjM7BWkFljCBJXtetFgqwK0UUkrnejjmTkToszvkfi15jYABLyhd35FOY1ctiex2ee1OVOkInKI7nYFbbp/bqvwWOBMsXtWlc21QqjG72cevYndWe6Gl0RhGEvIriAC+4xaMR1nKhIFA0Szafe/8X4PrWe+npOQNwmdbqrepK/L9Vd+9UfA4t/EZV/PHyTlgwC0MW5sbhvZaMbHZAxlr184SlPWdjgMZw9Yc0UDPkRtkxoyoQksgFpAex8Mm4zIGs0OwmQBbzZlqIh2v/qXLObVI+WPAEY67K+mYBcJmBnu+YKYAt7kU7B05EI4XU4e4RIHQ2CQTnzQ+32PDE3wtgY1zCvVmDdu5AFg4j2PQZEWOZTwGYLSGg1ruPK1sEAmQULA4zL6xHh/exnrpnAyDPxb9GvAqVMGoAXDA6rXztvyJxf6Nd13tjiIVljAHGbM7ME+6sNT0O73pAnZxeKATydoAQlIklnG7GgU7kcG54BQQgU9gBDSenFHDYsBG6iNA7OCcl5X8dtnZjMH4RlBEtQiTVzLSJHXMxScz18LY5uxANZWMSkkaggjba8j6DPd3TIPXqfZsOhPtagCF4jd0j4s0Y+FcOOpFzxnQrDQKNE2TEPz9CM/wj99uz3Ql1f2vAWDchpXsdgJLdr0u8z5nStQexyPMbLMc6OQ9eLuScuu5U9mwfkdDzCIcHPamh8LFJmmo0oTbjCYSOSHWgkbk2GeFrWKz3XjhT9yBozDMPlAyBB4cFdkKQ+2nyuTTkXqvFSnPgMMcNwPpaFjZRxfQ8qvdrV3OJaUdCFTVO0NBHnrua2Zi1gDO7tpDK5B7Y7XAEkgknQCP/hw9+fLarx7ypKMFmeR/aCx59bQ36UwuHopnUDcU5BGlCs+Ax8M56Lj6O1OOPr63pVkn5VwyD/MRvllvfxjY1p3WQ/UjXmkZ0ucdCoz0tdRxX2uzcZn+miV/yOCAg8poGdFQvoSJs9gwPSAEjc2qq82uVzy/wZirrS28PHOexr7mrDYzQR9+4UMMxqiUYjbGJxJ14I+VUdKzzhWDS7TXy88hqKKsOHROM/jskEYMsrTqsfsuYiVb8UdOWIzMRRLCRYDBSWL7wRCc3kHhhrnc/lc2iGK5wf3SxFTBs0ZnSmKrGH+5E/Gghnvat5xDv9EcNGp50R2G7KVMkrG0pMWnezgyQZZ+aAZNKwQ7AyfCxYiHbUKZvtwcznYyDMoXH3pFB4hIZ0XA7e4YzVDfeaGDns/Xug5QnpYOTAEeK4PyzOe1SASSFRWxb1uKn/aUw+e+iH5EoAMotnILudwebwgfdppPkEmTaUCMXYTXLB4tonBQmrRIp4QgK+adA4Jv2cAzVnpBDJdst6fUE2Hm+8Q8VwhSMKiyOdAkiiIaPQtclt6+tLYHlt7aT08XqMmMy1eCFSmpF9GSEZU43ZHte9kD6bK+dqZhNxsFi6sWdgI9GPRGdGWk+f33eLhpxccb5wiaMg96dzmQCRhGh+/+XiX6bf/hghmitY3dmdoFsHbGt2J5zxScB34thwR2Yy4JhmdcPv9EB2B59Dcnp6WO7uyYLXzDWTQCLQidMdXkisjikYNDH9ukPXrRxhSd7bjC+DhYfRn4IlKH4ZU151yFcjMZqu66KIRq7wW301MQ6hH4jjpnxG3FCog6edjVKFJf8RC3tvfGG5H7VhgqQhUnKHCBim5/HzP/6Vq3pVkz/XVY0EiQnIYWLX+zFaVXSxQpUcrh7x0I+WVBFjXTs5nDs7fT2nHZExmCtSzvQNy7pWoLEVI2INYo92pOUO9xRI8a5Y0LGoO4hHMi4mjdamP26RY9DhyOmAfgR+MmvaAemt9miRa1rRCd1YIwy9nMv6SHlFF5C0REgEKnI2gGzhcPzpZDsp525i83qM69rotDWDSAfkJ88u/jP65WHnyu5mKbCYiZT9zmablK5/zfqZvrPFtNKM8fi1MWC4ZlV0ajiANDBiYWfGWVs0L7IjJbfMl+KIZF32GiwJPLKp4KoBNKNFxey2F5HrYVajJOkl5R4fhbDJNsOmoXk40ZkxuJBJHyBS17XXc0F+XZuq7K7NWpb26Fe2oFhPR52H8zETztgZJ5wEBKtFrrjLl3YbAiQerRuA6IG7+j8kM3Am/bwxajKPQmed2sBeUimGciwpSOIEd0yWKswNJndmxolocdbzFZALcS+LDWU4Ziy8hWwLm++mmpLawI9EI2wZqjnIpiuIC5hdQJM54rwfrYGP2TSXniPuPXwck9a9hypDdCQWdtk0fWM7ALNzsytISbNlSA/36zota859Ye/f2ZS89mxXJGRoFD/ZEMAtGj7g+F/Tb78nEINfAch6ObI9KXcGrYdtUwdYNbLvFmfRL2XknkHIHRIgRyVXsCRXkTktju0fRySMvQFj5vjA5OohHdfyH2HVKbev6rJqiFtHDqS+YVvDQKLl9+gz4tmYMZmDsbch60eKRSOXTw5kB4OByKB714seKRSzbs0jGxc09jT2TH3cawCZ4Wtw6QGauLX3DZpuKHX138OxteQ0arisK0YjFhPZxYd2bA/k7B3OMkGUxkzsekMuQz7Gfc0HQydSX9g3NYszMq/t4QaH5j1tLBHZEz9u2OZw7GHDzkd0ZhnJ7kk+cwa2Xos6W1qFvSFt6gdakdiMEefKN9NVTfzawRgNxGvosC9SztCTQJKBH1S9Hu2HTjWWa+KTUUgnw9cZNQSHmWfGMqNmx/0oIHp+z38Ox31IXr3geEz1KNI5NOAwY2AjlJ12dVg1cVu7ec2JhFzguDf24x1bNn9mG6AZ7D3ihaLuBlB1hewoVehWe6yGI/3sWZIUvDYM12hhQ5K72t+RB+7sMmpIxmXcMKk+tPHBtrbo9QHj2hPOYLcVLvTXYwRnYA1GS38kZFhEC8jvPEm82+KmZnTWI+PEd0poIHGs6oBi02rVYF3jdrz4/2iaNz87IPUZd9JplhLy+SqBWox+pHNiHNspb+n9jDOfPIPQSmtmGtZGwLGbhseuQA18tO7ZOH2EQNORVHVpY8awBhpnT/uvc6jmaJjC8mFxMAsW+pAF140zn8KzcIXJDxCAUtoxXD0ZLbzXISkaVFBa6A3tm0ZdV2c+vrxTPgMz2yZhqW/pBgAQjWkZ4ej5Pwkn0FU4JH8mdJgucb5ocR85FIufZ05kB4rwYNU+XCJpAnIgUn4e7msdMmI4b+xot8dtzSFSemYf0jJkUJI9YQEQ6g/m59EmG5fvi6UIO3HZ6T3AsZE4G0phxTgebQY2vcPTvtYRCnBaxz16SllRV+b2iIw5LGMauwT3NAa2ZVUooYJmADpzMAo1CQiRCO2VgGAEZ9CNxGY8kn2Cen7hw28XZ0Bylbt+zFj2JidXK9Rg8Y7PpKjWPdn2Ec6hnD6OxL3uFLC7ekOWbW0LCn35npRkjBquLrlNnLfvRv1lOn0wr20ge8cJm25aRYaGjN6PxpsdfPF0PJhhbRULOsjx44XXjUWRBC4ft6rbso7LutN7HJOeZSatiZNHpyBAuQVjRGhCMwqTHIZDvNJ6wCUfjnAO+82aAeXHv1ycCXFv/2xXNvowig1FgHGO5TpNYDHwh2iN6Oj0jvb+c7dHrrl37hyNNWS4QtimF/mAIqhcxrxufD4A0uUawg4rpntJ9bS42E0oxwrQQFRfdw+fyIGUbW11XcQMeUB6HJstLsLXY6aMo9EDhnyc4/EY4UIAKQ7gqrxw0MwRF+0NeE3bOsyZdvWwFvJ83P//tt7e20IkV3ZPWaj03O4kDuM8wNmzPozX+5FPCASOwxm+1wNSYOxRmr7hkL8gfWIc8FtbSYneGjk+2xJscc85s5aknncGdQJkA3JkQI4eZ5PQkXZPXzsqLYZ92Eaub+G31BiS0XPbkIxyLhh0X/UKYjaCBkDq1/ffcxiDC/vYxsxPS8u9mj6jD0I5Lkhc+px9cha39dYreaVnJG6fYce0QxxZUEzeHVPmKKTtfIVOfZQ40bCZ+9rNmbsePiNyWetFMKkVdnVbMyMldx7S+Xhjux+OEaQp5djuHljbM2wubdYhb2xrH66lk+U+msfHwta4IYXRnhanrevam5L6etN4fALlcIVz1MGCMhg1HMRHBx94Q3KlGooEIrtQQefHvY/npB6Dnl0JkFk94yCcYWs4cgnRiCJ0zc5DDi9EGDCL6nhX7ZqnXQ0ce4VF4+pxZPT0qVvbs5I6gI1yZEfNK4SZvXrEuz9FTJ+BebWCjtku5ZqfliDecLy+jhA2FC1JycutrMdIqsj5XProCnA8umZkm5uHU4RpMkQD67kfAcW9kcMeu0a2XWP+8L1+e9qfn83rcSjJB5Iryh0OQ45+uMnnbe2ghFXeY0Wx4e32WQcY+gKTS8FrlWCbC/I9IBmaEcbqe5vr2Z+P/GgPJFg0JiFDOx6OcGTQ6g339o9YNkXoyBqJlE3OxHk16vImNrPpj0vAEMPabmzXit1NypMgOXWTM8Mk4IxKQ7TjohqpwYaqmmtJEo+cHu+65317dHAzeyWSw8V/Pz/1aPTrH6YhTRea5GSMtWjGao3bGpIv+gH4j0oM99OOiQ2763xcWOtGAJkX9RjQBQONk7q40N+ObO9qj8+nqrqW8plJr3XHFNSjbS2IjvY8IH2GoZNbMnlN14l2KXo/mp0dIRovpSFsjX6EC3ueh0tcJrIfjwxFWhJyu4U4ayXgWAORuLQZf823P+IVSH767OJs6YWIZANGZKdTNDZHELGmz3Q+LuS2dQJyoyBXPAK/dIfrC8Z2kqS9mYGx58Qh48BRkz5cUfZ8Lo4cTDd6/UxOG56N9+y6Hh1TkqV6RAYevQCbElcJFKRua4yZQ/nDG45YMq4dw5IBiPzcDi8UiWtbzYwL4tjaRd97+55g3rrn9BCayA2vEQuQ9X9kLxTOnjOzZiYgw9WDipwzsFtHSo44NuWFXTcTVImQ4HInPFPvR/hd3dd5qKsbLOKAlOyIDHsoyIrPwNhxU2vTv4dtWEztuF7YbWFbwasono+V/GgPR/1221qApFeKlgWuoYgX+h9QkARotNhc0THGcHYjjYIFV44Gxw4X1nm8IXedPcazo70Eyw3sk4A85+s6AYmnBxzC/JsofI6+0uK+Lk94z1cAh8Ylgrko5XjHTQ0gCWC3Zc23EIAMq3poydEkBU1phyaejgjhEIdPw7FpDFeAPVfN1YgEjqYbr6HDAdfjwZJ8AKUvwyPwVLIZ0oZeZwvxsmuO8BG99lQzigsLhciRA1nzXXfv63SFv5K6cTeZIoqvz/i6Tg2Zda8VkVnTw5EZv+62KW5gdwy7daOEr0mgD9YmjWhJOOPsj8g3KqOnwSliNFen+LD40h+uPAovwt7k4q7lXHyBydxjpGY8HhnHzsbKVjMAXo/MZbeiLigqXb1rym3e12XW+PgZSShGu2JlY10bHrUkQWU8H2GZcEaksBPOTla8gsmwrNlQZ1PYmuWFn56ldb0FJMgL76OBkl2MldnhVa9QSRXl8wkz2/sBhFJ89AXZt7OdCpkIWu6lSlwtmRE9nOMVjNt1rU+n+XZENhxhcBIfnW/Hc3U6rrgD8tJBCSMlFyVZIz/4GD9zS/kM5NaMmET0pyjZPSBJ7SFhXBL7ujWjyXo+Sj5aYQiDZxH2bn8Kfef9fHRA+o3tYJRsTI66w265Jwr1KOlXtW2hzasMS03CpztceAt51/OGy47pJ6T5IGd4sN3hyIgXrjVdMWcBKMbIYdZ6Y8/mPRJ1W8MSkdeA0aYsiLirmRenSztu6uueN8wkJB8VBxn8AozikscRojlGvz0Bs9sBHCNGw7eFY/h7lgGv+jxgWI9HCZ/2sUevP5z18zGt7IoWlhEDNQ6HH9I+rVFdKOFbsGxIQsjqJ1VNST1A0xWGLnsmUl3O4nlXzyGGCP5WDp+mL9iGxd0MyOcnvGpF/8eig20zYywr1zw+XqVgLSCRMNs021NCbk7mClxi0bAkS0G6y4foNSd1S6F3+NKZIvH4eLcUwOgGDRskTiiu9PvF+ROhQy7ricFE4dqjwi9qGDJ67k0QQuuVfef1M56Qu+3WbKdUjZlrpj2iMvB5U4ecPXLtqnZ3+Gpd37QDctZfGx4XOkRTUqBIMoVMGy5rKF3iCEGR062CNBEiFFnCWfjD+YFWLHc4+2UmELN4RqIlC5Sj4DXrsBeK6sLs2NzOR3aMwV76h/9x8QTohTJoSjnGLx3WgGFbNFDOQjL4oSo3NYbstav9nYAX+rEnz2xP9A7f9LRPMC7JPjVggRUkOGJiY80EWZcz2IwWwnsguxAZXwewCV3jBLciGoTUJJYMV3e4fMRM+HDXt2umJkpSXIyMimMWu24Q6f0p3As55yHhfuznI6tN7NkQoIM0+gURmwGH+8nhZ25eJyCBHY/IeTs3LHu8q0ssmoZilLuCyZowzNFPS8hQe8Rm2G1YRzlXmjIugjcYvaW9duBRIGQFA348HllgsZJ85vgZoJgijZkE5IFJmpTPmFFz6R2lLA83WgIcODso/ZTjFdz/KB7tzXLSaz4jUYwSQDH4qhf7Gbk/DwnN6C4fTqCyXOG7mHwieASQoSBHm1z4VI7hEZf0u7qLuXg5du1MbPgkTBryxPv9GDCcI5HKxSMJm333kKAQLuEff/BkXJw90ZAUgrOBZLdMQTh58BpEPl+JHTPZJYRFi9FY4DAakroTEopmpNBl55vBA5TZH/c7BPJ4dMVYzh59R22qC2FNP+2lP4JFA2L4IEViY3bhGsE+d3dPAzI9jmty+GxwZuDrtnvVwMe7AhQg1/aP7IgUuh8yq16HbgSLOkePs3b1TN848JtBbCgejuaCpGWKICnZSGxqLEayWenHkIdgPBvpC3BpYwsteOjz2MeFDR5pSWpmTJdzdYpPDIgLeeSsZdUK/W5EdJlhj2Rvu3pFJNWu9XaEFyARC/3wVPAoQG564z6SUsE3e/dkhWHHCmdKbgdo7mASYqjJmUWRh/D2bJzhwdmwGIj0fK1rNxAXHInNWBg7EipGUVdHC2PYB+EZ4+hH7SS9GrXxPhIohBOqudQKGLLjrNtaLDumELwOzm0tAU+TBu6GzFEMzYiSHOM0qzdAjUT6aaeHj7sfWZHYs29kf/aE8IhjHPTVHm33BmUp10zJLYNGMm/uPLZ1zagPr8BGT0LO59SPnrNQVC4fZJ/eYo983FCTQykuzsdBPo99bd8DIrVJxCWNwqBIR/sDIu9pp1tgKYPmNlqH56Q4HpJw0f0R9HlWRYRmOKMhSz+2XEsMS03OGzvDMsGjAtuj2Ot8rtefDh5dQ84Y4XT8mDWTw4aroKunGALQjsw0m+nhoPGuvT2sOQBbn2jpBDC7kRoHiSEClFmvIBbp4Tf5epz9AKa3B/XIYe1HSvbjAcs6RiLhEqdmASRmPoUB0tyPuHvMK25AzLlIDkI0JHiE0IzgEfUoosuU13NhWw+bhuTHMUxzIbetOzyDjtxraf/6U8IjgASSTa0np/8R6pma9AEwtVgDsKtsYWlthjs8+5GO3EcTkmnPVECGxSEELIgzwMyAIdyrFSSqvxkksZNSgX1dvkf4pEu7s2mZYn4f6cgDWBQkqwQbyfJwoSedjQk02Zyipw3DCRhqmeuR8pnFuC4SCGFNs3oG5oDMmcOwej0+Uft6ubJhsVyIxRD22JWM62GZnjaMZVNwXIu5vGWzFxj2m7FNG9pTmD1TmGtPuM5dWzhtGTgtpbixCRW+GnNeZ/X1qiG/DlYXdg+/5mBOSB6OcMuo0EmQPGBfp470UgUd0YjeMSVh+SYnMSSJFKkeLWTtHAXp3seuv57dU34aDXxW9VjZjxEvfOQV+aTwKA3ZL0dfsIXcyg4XZGc/+jEyzk7N1EQ9IsrIzoxceNe8+rS4zsCFIdi52FHqWjtqFnLsB64fKMq5tIZq1KHrFcRGDx+iMtlRivi1WdlCoWeHFxDFtJEf6Lu8JWAIHgGiNrSZhF145GAjDD0rV5/ouCjIauDTPXJXc8bbSeUDEiSKQ8vzkf3Zk4jPDA1ZnwixzufqGpoczlVkYPQltj4hgycSkdMXbk/HnMqeOBwOyBqBrc+Zb76b7P5448pxpxspq9VjpONKTDpQqhC1XNciCSSN7aNzzyGA6QM/uK/1+Wj26Nac17bWPTAUkdJj9VwenpEEnYbH0RBgusPZ0IrLzO6xFcaNBwufavx6ubIFwp1kChGynD5pxbDdA7nt4XPCCdlITP9jh64hL3itZnv9fmzDuqFZD8c8AkTcjzCMGe01JzewOB2Q7vRpX48faEhKPwDrUeH1XAzoki2tQ0cLYQKkZYeHRoy4tfhouNeOyCij8dFcb1bOGTRhCSRZywhDKUbQqFXZuNzRQqTYXrXrw8UToxc86WyNz3QGZPXI/YrNsWLY7eBJQ5s9wzOsyIOEkJ11lt5HSb6AX2wTlYa7OMP99IUWgqJCz/CBLzPjar4CDBHdpFhFRGZY19oiWTE+quuggxe9QsZvdVtzb4sLhQFEb7unL9r3bBkANB3JgTyfpaXUjwlGTiezcWuWJg9HfVKMdtpvH/7J+eebrVZ2QJGvqSFZQz/q8dhtmw2B8WNAsSsLq7tZxQtLU1apQs7UREWOV+TSCZLTUrJAuPCtsmaI0bAGGGGtIIHkcl+nUEyGODb+cOsiJa6kitSPt9o6Mfr6tqIzPmWYQ5xFxqvw2vyPlUyhQ2vHmd/jayWBrw1ttGPAEqm9M/Dj27PPxz35hhyjPhY1maO5ELZygKGPeN0mVcx4IVBkE6Rp7Tgua0gYg5WJDSqdjdrXDGEja0IXC/s6Gkut+eERu2YXoRvFJHCNNxYJXRO09jbiB49hC3yZGt4OcU6CooQbNNGLFFDqO0p21LDGFxoqI2B4hC1tU6jm8u+nXfdjvBrdumZ3MsU6jv3JBLBPakjYqiDLjsmFfmz1mA3ER4SmsMgnQlYHAMnYDsccsNAXNZRngJm5PVk9E84e7/xomhHDRoRi5PTIBOyv/bqWnA1yeT7yfrRCLsxs15DX3m9PVEZ2BgxplxKFM51slvaMp5vlvDgO3uFMJ9B4dI/PSt3ZDDkJDM4ZXbC1G2k3f3xiDp8/uTuv5daKIIryERSpyCaYTJkgJIIxlG2q+P//Ya+OakbH8KrTZ6Z75Hsfd/VM52llG812Ug5HMRW95qhXPlSkwzLbSm3WvHoFdub0wEpRVsGr+3zQiN07fOkC6ZaMmJH9DrUIN3Om83s2u+P2tOEJxsoOxxkOEm+0FSi0V2Qqx8KkwjIkiUtBVn64eM2fgfQDUd5wt2B0ZOIH59SQJFI08YMbe0s7+jXNtoejV3RttgS4OgO7Q4cXJ7Kzp38HsggNMAylWIh0ziESfCqtIqhwyYK9JgkiDY7VJ7dWDleY2RSsE2cJGN5wQ2O5H6HTaVR0Idqg+blrXXUcQ7o8DVKSPArFZyiiSTOmZywYHPGIg8WuLtQW84bNoRsRLKIz8YwkmWIp5srV7XFXPFZVVzp8RkHXiscrNGgckBW4nhWvbMdhWddZXPiTcWg2JK2D5/Uw7uO5RxeODB8jCQI0QuMYzlWiTRj+0pHCrlhwK9tSxF1Lai239cjIBXhWQTOKZxKOuqsJXt+CSe/hc8Djc8iCV2waXdXWfE/CvD2igGR3EQeFPW84jGzbphtHIfZoHv4iGi1oGA7xGIlUtD4g/7w+g8YAOcyZxqOnUtQHqx6QHPk1QjOtHzMznMuaY9/Ww/2Y+eF4e/qiboe4M2RSNUw5uUHD9pKunBnHYQwblhDv2EwEDBuLPpKdjAp+MVVTEKSei4U943HC5gxFUnBGzNUj1I2lAowsdKKWDl7UtUwaXi5rqgvX7B6ycQ2IMYAm4jO2ktZ83CuLYE9ADp945D72pc3XBCA9UXyY1VNVfpSQJI6d+nDUc/nhNVha13PkcGMwpRg0rmtquojQZCPINYA9u5sNP/gBNh6RGDW3WsRmqHLtbIo8gUjh78bHF1aLXBaUoKwAtiRQZNcAwzXzETQ63+6YIiiiJMFkviXz+cie/c2uMEIzr+ymNcun67ngmDIZpelY4YzNRIsKN66f0/fY2Y9+/iQ8PtW8h+U0TmCRhRwzDC04kyVdFzMgF1pGu6YzXJI6V33RQdw62d/SVqrfkPgeSYFk/EyZ2AFEyCcOi3QS48YOLCq5R4JShbBlTLZ2bDQiFgrNGAU0fAFDBHy9sb+5ygckgNw2Z7Cr4+QGtiebiXFsLK7VhWHKdD8AFjt+JoHJUX7tv0YYu+M0MSyuByKZt+fDDM7AoJOLvLAbi2HQOBJdds+9r8V9woL4jW0lnB1G0+YHpB6QYVd3hKbdPVFCEym5giSRGYluIn6snB6AGcM0tSN+vVrY1rcHEQb263wUGWppX25p//oVeiALkAscIUqvgSQrzOrwh0MYNk5j9Efe16NlSlo0SAhpYcLRP6qACQd/yB6C3dc1dCqXj4+MMzN7JuT2gIUe+JHUM4fZUoviSge3rDMi12Ti4vnxUgWYBMFCHJA25VVWdqlIZARnyKj4zPw87CCKukw56rvfTBLfitGUNcN3Nldzsy3Au7wfr6MEexuQo56GTLOfqol4Tf5AOP48OBNGtm9W5/V4EuSzndug4QsiUkivlI/CdGloFj/HYkESxgljxj9RPB+b5vtRgg5nkAMRDpn40ZmuaoCJgiT38WC3daVT1FRNnWne8+DO8Cot1DETe/RxxgNuZAUMwO9+DvvQN8EI3yBvUHFWQ+MD4zZJeLxOj08DcnFE5jykGvCa2RSGyTHu41IE20dfW1eAitDEmZPPV5CYUDwbzyUp6EmUfjQZdILZ9Bm4w5E9HZC2R6/m6GbPaRTR2LBhEs+sWwpWjeXjAslDWTZsez9KJ1oXn2xNUb7wovvzWkO/r9mjA2S3N/vvdvZuXWtFMykwyWlj7vA1X9gAssM0nQDJyajdPUb/bgRwoeY1XJBu1EBt0qR+5OTdH1mwc18PG9bzZxCcMkE80nFtZc+9EzuxGDznIeUIwwpfd/U1dKvvR6wagS+MGoqv48oGhRy0pBtvqx8pqWaGRY6ByHuzaRKSXrHgIwwnGGctF9IdPitxW8MCjY1D2IXno9/a13the+hwJQNgjMDOaq5uT+Gg3JiH5Bd1lrsmTUC6C7INGT+NYGFgkf+QDkgIZ7gR42ewZ6AUpRxh7Rj33HB9UFk1zsAhz0gIMGqnXc3iKONa25a2wTEUowESk8Yw+Nnx706BBJbkPXoJtlkzUa2whq+9oT2YfHpa7etIqYh4YahH2IV8CrZQ+cv1XtgAcl7WPTRutmu267p7nOmwNpXyy/rZQ9iAcahGJL4e6DXDY/VrLkt7rTUElDBpRVCJpNGee308ZthwnGlnnR8+psZB5REHhbRL0cFTHwnP4PPR8r720IOlU2DKyCv+UJ5wO1TgMB6PRoStI0W8WgFw4DxdPSy+iylnEb+2tqRmV+uXq8ftjvavv3vNFzaA7HFIlf8YFrYoL+2MzCwNxNcnZHQF6CRcyfNAjQDmatIAOMZzjSMzP8SMunUPC3YCjfmCnN4emGh2x42BSA3HdPVYDRfOHjEreCW1gjs6Zw4/6LPlMRqtUTnzbU2/zpoFwjPHexPesTlDhbBRrwCNfimtIr9w1t3swaJpSe7tjfiMD2O/Vpf4edWh1phAw6HzIFGPEb4ebh7JQdHMHgxm3TVidmw+n4k0cm9zu1ZE5A84l3W1TMGgod51hgsblufNH7tqIRJ8DgXJmImEnqS8UHAUIM0j3uPYMz385jPPyIW8fCaLZ6qVVC6Z1RLCIaFry6YQb/X4WKFCMQBoRa8Xuz/STwpZ05DA4pZ2zJkfVxrD/pfbJ6zqwGQCEUojG/gBzG1AUqmQQ7q6YqF77bGBoQ6IfjsWLtvfU+5IFpvPdGT4HtGRPVRzznidkHRjJpbvcvgcyMrF1WMpPjdc2qUdq92eQ5JUCru1457GxPYk8cg263rXNrK9fc89iFxmGHJTP+IUb4f4WutqJjYLJNoh0Lhh1Lx7JV0gXwTkLHYVMxC6eKuwme/HjQFdzz5jwY1rdqfjwo1Qi5VxVmWvWoi8qJHDukaceDuyolVzJYcvFTRLf9wodmW1QdOvSPLCo2eKZfiUboSn/1EaMiLXDzdwN665rpOOwfvkjXvgYHEUcv0R9zVAhA8oDlBm0JD4TCXkXqpXIN1MERopyKuNGQ5ADoePFOQIGUa4kAckgHQ0br0eM2iNbL94ZZp55YwHsPu52E5IU4tJDcx0h1uxqwhNeLE7RfjCk3q+q74JR8QtupGGzSCRLDO3ZdoVroXvkRNdpaoXAMwNbAdg2ta2sGXoSer118et0Azxwu32ZvB0hkNYMuJesgCbmhHGC/Jqk3wakDOTwkOGnW8Wk7l0GL3sF8o8imdHJIyTjn3C1yPqYewjapjGzQzPdFoudLIeFTFpIZ+QhcUUjUXTiuJQex+dC4dc1DAsGm0PzIDKvK8f2BxoaZ/9SMucYUl2C0jz9GT5Arrxg7BkEAnDFn5fbxDqEFbd9kDj1m39brHvPn/1yukVx+JXYqYb+QkOoWq1d842AIkx8+wVXT6UPRfbFWSkmnkP8TEqbhyEwlKUEaIRDNOoofFj9sgVmV98XtYcoMoPr6qFEjJf4N4YgJCMrBlHornEJTOZAvcjClIwvD1LONNiZzKFPJCEZEAjOMQlHt1S0tmzAhJXuFk1C9nkGXj0f8z3I1iEL5Tq8bvrLOtarOz2+TgOdSyyW5rD8IXza7we3QMpBjkKR60rULSUirizZ+MedlrVMwtSoqcrZIuzQKPOjsbGI9+4rR2MawE2EWsi2LjCBUpxYIh5nVmQUIzo0hMysh/jqk5EfuvuHnERIIzrW8Ds0uvj6Ek6gLlhzgBFH4kUcPTx1y/ErlmWVHH9CtI1JNtXAxKDmjvbxShzXbuHP1uHs8zwQSRPpp+yrz+KAa9d0tW1C4jGI4jMctec0EWVQowx5DjKXQcgK4KNt2d1ifscTaHyHTQjT0h94NDquxyPPVATAxssulXdOWeGRlTkka/aAUTvR/tbNBFvHGLOQKScbfVrjv1pNMkV+fvR7JlNC1vKUYC8qsZ72xoSRKZL/Dw8U50AxDk1Fic8PwoD+7n14iicsZU9fJbmo6EigeCCx5Md/enIxt+DRRNYXCfGVbVr98ntcUhsuM/SJKNC+tAckABQJdh88vwgRT6+kFoFa+DjoBQTORzNylaDMzLOYgQNj0grvtYFTrbZEsCmkktcTIctqlkfUE3B3tSSsq8Bo3Tk1TVOuQTIns0F+6kdj1n2Wnd0JZ1d9Icj/MKeyT1I7GrQmKaM767n0iHWMLL5nE5aIsGQzTqtcBwuH5C49NuzJAoEVTRVzGUYJP/R3I+VaIbz8SHv64rRdIAGDOqEKAekqUSh0kj+x/uNAa9dQLOSPx+1IdBo3p7t9o+EC98FkNfT2f7/AJInpLiTAS+uai+e4W9bNzbq0Tr4dM7jbJcCj9zHTjmDupfUoJFshkFD7Qyq0bLOKqliArLBCAwRYu0Ud/Yj5jWJuJRhp419oKEUFYY6eFMpX1KL2krx6eJr4TCmDsN4OdICUssoGkn5ABpM7Oj/OLEIDMOsWW9rv6htiWLUsDji8usRFSmBV3wHCtLekGARNnIpfoJHrWt1yV2dj1q8G3VIo5rdyhFmF7VkxmXa3xM7Bw0PNHJK9Uj3cG0oATjMmdOcpxntKQKLsJn/eLAuZ96gQjxUZb4dO/3RIzQPgUaERwszPhO1MxIi6//I53WuSAfk44Ck3o6uITfnaVrJgoRb2UAxDhuvR8AIMnehIAFkRgzx94BMB2G3TBHLpnsLHLt6xoyZtxqETZ9EvSvn6j06Eyu0wCOsrOxOf7SBcZ4YTk7u6eKFvbjEu941e4hzX4thVPtsLjjpPbgd4e6B9F729GoWp6ILJFaDM5+v4Kusmfv7SO5B2O98P94LkSNuCH98kr/nUogGIBoq7RQhQy+f2egGYAqSV6TWN6/ugF55P8teR3lhwLJHGbK2rGw3aLTDfmFXNc1r/kuYq4bNxef1DRLnCzIINBKkqZDhae3YPMCIN5xPtNQZckWTGE6Wj65qItj6IgdXf9DmI8dH5AOHU0GCxiqf0eHoHe2BZQcLfWZcNiSdxa52ftqqnvE57OK2oyGARQ23vI+UvIrbA/JaZsf9FyDD08PKUldWesFHpvhC4eqx+YV8tpoZt1M/F9nGkPWrqV2Q3Uacnc7HwqL/luxx7H1jY2YDxjEEG1c4aLQXJG33CGFLWd4ocJhXNsszIP0F+SDHT0ASbqLapWBYp6/neG83tiVSaBO24RHZ45DC9QgHj5v2DEiMqKH5esKi2aZ3eUJKRd5deRS735C2uuUeKMwQjQ+iaVpAKSh2dwrgN8xrNtxyIPPdyBoBQ1r4INsRmcTjEYExo6OD8OUR2D9rVR4FeKxYoeeHc6C0MBrkEsUWMrGyTTtGCiTPR0a8ih4MjJzQj+4X7zHsadFQvUD8Wh9+H0LY7XnMMuysdkWsSIRQjqCRBfMY9uaELrCInuTKvurChX+/Ibt9ONaMYxIhWQkVS/tw3+jImIdUaZB27oZ7wh7CsQdjj9KuoRt7fmFSjniNwpm1h3i172GhHYGju8TLG571XKjHqFXgEN0AuKerwJBnpI0wzHJXt2KqTcWY+nFv5jVDDHk4HjnrNFN85ryPbY/4p1A2lTK2qRZZ34XDR2jU2oWCfPUV+u21P9zgWKkVDsGNbNwysbPetVukxNnhiFWD7JGaTtPi5pgwZDuPglevvf6fE7pAoVd0aR9iaTPcw+cr6IT/G/1o4Rl/PnJ2REozgktvJmVaUdtkjngFiKUkicz4CGKdhEC2jY3rnFxWHDtWuD4hbcFiJrsY30bCWQET9fjnlSeKNyDjniZDPD0+cBHOHo6ORXHE6oDkUK/G1oz5JwERjgSPUFfR+H1t59aQUz36KE2h0V3iU0d+PEbQRCtSruvRFsDVI1e0TtHUnpjhDU7Im8QhwgmTBr34kO5HODgEkAQLi+rGhgyCANToHraU0OD02ax3xaoRg8y4zhzxLZMGmwYlCV3XuK6XABlwhI+WKWDRYHjRJy61OFqI66eob+xi3NSGxUoPR/CdU/+aM9k92+xtcnz4ACeYfGnAa3fwgcNqYpyjUlmQ+H1utbirlQh5KFsmRAawo2kKkEQxumkN9ByZUbAA3UuAOO+Q29Q2TWNToLxMmNcgstyOYHGLwvcoIZKK3IXPJyM1I4KNH1zUxQrwhbJJRejD2eKsflvpTGRTzOEK9RMMjs6kAJH4daSIA8kahXRafD0S4hOTGZpBFGFaM5qLCM0t3nDRDafUilS5slCQyjXzBmcg0qdyZQ12VHT9fYQDSINldrEXFySXlqSP3NUZxN5Uku4Kz+A1mOwA9lrzyjJMGiD34fNJt08BEpkbHbnVoMK0ozcDmIO5YEh/PnYG5HlCLmL4H9kNxyqfgVGwYHd1fAOQ5X+sEYYxTxNPuJnXcAdjpFS8U25xaUa7sN20hiUwz0zrej+mKzykm9THHMqelg3UWFzPXn69NXC4qrlAY2SHwyZVpDA478c/3333yku7ml6xoezZvCfSKmLBtvNxuai7ew88ocj2CYZwrmqUZDshJwZrJpKzTg8HkDwWo8HZ6uyZ5VxY1/CMX8/qGd6RXNW36ES/sa1UQQwswpFh1NC/x7o2Vwokn2tJ20cJbumwaizFRxvs6Sy20uOjfJA9M27Bo5ky1ZYU3+PL+Wbu6wGRol2EsQOQUbPQN3bJbgdw4bqezcNjVRZkT0XiDdlRGTiiZs5wyn72JkVKOvN4IQs0+rro7wmqbs3drjkPkPBnyT3v4HLkBxCkBvtGHnFgWToSOFpPe96Q+uz12K3sw4QJjnTHY4zV1CpaigyfXvCHu/dRJAY5HLcDNO7ywagBj9p7ubENkJlzhuws8ZrOhWjirvZhwyTmjuRHGGRna2MvRPY0VzvNDpClFrt2hgN4tFFIQqWXcwmJHDgXFsXYS+z655kB+WO8H+XwQTFajSGPybCvJcKeMaYJCwwcFiBrfqG3pnB/T3U3I2DtFrWnVYQr3HYI2Jz4IX7Zuu5sCr+xWcY2KrBZrR512EeUpqzsrnPlXHDcCs8IjSy+0omdBFklC64a+7YejaWgmhrHKZUk+xTDXUM7gkXJi9WusO5ICgx9H4xnPylPNLNuKdQWmnUN44e4dCPfA85wRsYpKbc62jso9WHLUNAVFV0k42Z5ITx9PQ3IuKgzRDMv6afKfIRFcjjMr21EGNmweVmzv4uMij8Fxz+/+24nTkgzatIdno9HKNJ7NiLYVsllaFy793CqFuLRzr7fjWs1TYdngGJP/LDATDTy6efjamSfjZ9hj3KuTDZzfojKa7Sk385eQtMen4eYYMgEmjaxgSIU3h6ECDhmyxT39gicKz0amxNenxYN6e7wT2EGP0FyBgsnIMMFiZIUie3oxpaGzKgMIhqSDtfj2m7vPTdqHHfTE25kddcU0YjHPe2QnJhEzPi145J9skckDVNqMpfL05YHki9TH6dNo/vaUnKjwRlmDTis0Ey7fKQio9z1VowyLr+sRYhIEb/vEdg+Li5mYG9QAJKNuFiCjULUKUpodKgCQ9hqzgBHsMgS7SSvoqzsKMBu40a/RgbkGi/EwG6P4+wersMnhkZ2mzOj1LV7AOSfK7HHxdvhDxcPa0bnUYXdWPQmkN75MbnhMQsWiF7T2ozaQp3QjIrUoB6zzvDBNCStAJir2d2au/uj5VGM6Iy9HuHEri/SH4bG8vhs2jOOxGrZDBw3neKAMSxsOGbNjmxs15CimqvpYsZn+hTRGX2BQFHnVMTZGuRm/cwooUmeCrJHK/hq+sEgKfhhZa/enlk+AxoRpSAr4UzcksItLZeD5VQ4MKNXSoYMYQ/iUpHdQNzD147JqqDh0RgRwiM/kAXBUfP6qI+1WT/Ts10Njn54qeY1no52W0cMe183tgBZvSns3tbHssOFei62ZfeMVilQITJrukinKNuaXUAMnkisC/vUKhJzRqwa5MLYQzuOhFyx0o7iYLEb+GDWMFYTRSmSbW1TDA9lX1tuuI+Mu0E1BiUiua8l/aLGoAmfj5DIeKT7oRZ9dQefp0cs7O3+j5ZNEda1ha8lNyuwHYuS0pOOR9hevOIAMlvaR+oja74g16nDdLRve2Yk5ELREYC44cCf1jiWBzKejo7I6t8DIsc1fbpY8erK0S/r0pGejOujkIREN7Pxi+MUz+AMCpKlTXiGjlLVsLkHGLJwQCYcuZ8tdg1Zkwqvopm5Zt0upZIgN/LNJGBZ0TU77iEajaUk7ab+E0Da+nMvcWwHpCj7kPqJ81b82gjhl3aZMl3N5Rz1qF32dLPutwd17uMJxvLscHZqRsA4egIsDaVm8546RsTQmlNEEx9hz5tA1hRsB+VnpEDiD89qLhja0bhE6MS2Z5B1Xd97ztmEYydBbnXc60HDph+9YfOGNWPjZ94tDyS6EabzTlJz2w8ZLsjZvWfLzLbxCn4/j9g1y1iO6NIXOGQPzShELu0fWaBSWCQ8g3YUuZU9O6bMegVsa7uzF8K4ZuMP9zFdjIyz8q5s/BivyKjFxgOZ1Vzw7NTsdJ81CwxCyi4Vx8wzOyYO7a7uGQtGj+uMVxRj13LFIzJBuFnyamm5BsJ4QUrsJ/MsAOkdU9wZLpFGTK92PuJ+BHZ0Ek80so0HI/2RY/vDA4wFTET3gjQc1vhrnSWEQgvUrKHCE3gcGtKmDSP60dhtAajk8pb2+MR1NYvxmRNSzD+RTXiVhmxjxhQk2ywZMXf36AwktQDhalfbPV1VhmP+zOJ/RDc6JNPGTiBuhGjM9ch1rXyK0JHi3/25H6ePAFneHs+DLECugRrBLLrugcuhIVkdMNTSuVMoEofsRGH/W7wfCWHL73g6a7e3xq5DTBp1hWP8DMFCC85wVWNfS0uaUswNRf4jsRkrWWA5HiGLFLqq/Dvah+MCFzDD+ygGzUZSf0QjAJ6Q1TocthR0VXo4ibiSW+Fr3+jDcED+yXL6/dUd0SsRkIki7GXixzRoPD7zPMYNn6nHKMMuVThSe8a0he5vplORNWqW4A1ZaPxh7UfKKf2PCO8rFdQR7IO1aLYrW75HfD2OxpElzvYWkDelHs2s9mWEyN5m92AxxmBHw+a6sTmBxXw6vlRgiCFjDvEsnhHfHhgHGKtBRV7VMH7s6QlpGrKbnWVZ16WSrueIz4iN3mYdMKwWPh0wHFM/OA1bZqaHe6yQAI0HZlwMJTmNGS5qb1DBF4WFEm1mC4xexvWjtCNMfnDL8dHBu6U4Nq2X1M1Z654YyE6D3LBovMbQyl1BpIUMIf0ID+RoIl6ZuHZ6Ws1ri2AHHGEZNLw83TUqZ2zF1rev4oV2+/iUBVGiEL4GaPCIeyE2BBabOMMBW9jXw54pFVkp4qUgEad0hwNIH6bJMntmpcaja8eOXx9i5LCYllVgEzEEiTQ304p+e84ZiaRtEzUxZ26Gw8fLDI9H7TauDZqWF651hI+wjBqn9JCFwOEbF9VjHHKMYQewg635FOHyCbX4p93YOyo3TEC2ekQ7+tquVxAia7QriwOSE/UKnMCaI9NX39tAEd6dzaplCsvMa6uhAYZjiOFpJIgnWX64duKxBtAYGvV13x5pRiD5tS0dotqVFB+i2DDz9cBcQ3r7HnbP0TQ/uDsgo2Uz4ByZZqNtSo7oWhWkn7L9oyNy28BGP3r8WiuvbDj0y6t7oldQhuF8HGZMn549PxzCuM6AIQIJ2QFAst2+niMMQ4DHGq4Qy/09VfJKbAb2fyayR/C6c3HhkLfuubV2UolMaUUScw+Z+ogkcH3LEGwhMxtAGhwRMYiGKDaKUUyc2DX6kS2ClUt8HWMIPWmtTh/Q2C5IFhd24nFNpnDlmPFrZNLdflLPDJAVpWnTGrHGC9lQ4XD6IMmA9PhMux3nNM0xYcEt6/Oh7MQJpR+jmKsfj9P/yOp44bBkxIwLgFg1HLwWm8bh1GG7HZNjFjjr+9Zn0PhVbUCUyIQKzb8+IuE2YAGeqT1HGFqyixS07bCVjtsXtZnXkY7bw2e2Q4aRbxYPSZw9ice7HQWyAaSlVISpDV8ouzVHm7MCY2IRkiQ7HDhWzxR2rilBI3R+Y2PM2DjNah0ucTpHo9GoV6gCGvBYZBni3NqWlXvLrU0erpanQeYMQwoMdUBHxrwPd/dAAqHnh7OtjU/m5UIduj6mekQO3fh02f1oihHuT8es6ioobqdAesVCmDP2gNylTcOV3aNnMhESAbfbmk9EkaHN/egePs3TyK7e4bb8Ew1oOhadZUoupQrWEkByeHo2G1QAQ585XHQwNEZloQ3TRDtyuDlQRhMNclkubWKcdCQGzYMD8dsGJRAEjfccatyHuR5ZR05Ba4dcbJnNGhpCNKwYihQodHnRnEE7apeRTeSQA7Qzm4ZIjSFQhLxI75mVfZbcg5zjCz/xmq4qwV47m/Wp8ymA5Qlp1TMgEn/4xWYAKySj2rWJM3j82tr3RGaP5T6Kg8eKEnLmBB4zWOimDMKs60gOj7Iuu6oBow8yFAAFyPA6wicmwx++TV0/w9fJ4RzWXvae2mNMujEv6zBu9tMhoB3jfD+NoR/j+RgJ4vo6D3fMRfKZH8IiSBQikaNX8/A+eltSSXaZM6eYqMk2q5o7e50WhzBvj+fjGibbvvaNARMXtjSklczgfzzUwDjIEAkWfXwhBwOl29Z82DJVYJhPSFCZmvG+ugBMNAqML478gDBmYhhSdO/Ztq9hoBEcepbPoLsdJec6IHNGl20YhJwEDuu2ZsPzh037CDCyYROT1pqCZdni3T48HD7i4X2EBMulAHt08Ik+4mVid0KudWt2NSkg4uThIUlfAFHEsT2VAiQSxCZA44D0V2RP6fK3YxrYBkMJq+rSqdtTaI0GPj7zgw2tCT6inLQAHl/st+chbMdi2zINyr104TsD5EBfx2mmkc3bEerrmtUXNqvHabb7sfJ7ppGd2lEcMVqIJyhPmw4fK+fqfIq+ukkzewcgHqwtqeEx2tjniC4AKWEcAN6Iue8REufiPp4niBsGHYeW3iNhZs1S7PrYQ15pu3e5fMZSwsX5wGb08IFvtTjjvnb12LhM+vLXPWWLGyADhv41dcQQ1r3Dx7zhtmVc9v08532ART/OjgAZnwGHFqOxMPYYN7yM6CI1vNtJAUU2aIx4IUFrgRG7BhI+dbZ2pJC7ex5gKp8RKLtcwTHIXa2l7Zd1ThqmA6TPWRiasXRjs6cXJhgCSgcjLMLX+lgXXZA4elgGRVG9HgHl3bt3X+7MyMao2RxgCAl9AHK0Iu2r+zU4iT1m0AxXeCOTR6Nkq0ctKN+OJw6d4DOpIzRTQ86GUmDRnY8CpEin28zyoUuuha7LmPH14OEZqMxqncTZRmAwKfPCUY7Oc8rCVI8s2Oa8YXBY+Y+Wl3sxRuPFCshAJAg0F2RpRwPknsoXKlKTe2ITU8aLXaE2rOEuA44BRi3f6yAayE5ra1yYKUgvVzjB5sAPaI7THJFCiXg94hHn/YiS9GpXeXysWQpYdBS6B5LccB3MkukhNJFPYSZNlxcCSiui8QGGhkLHZsERQEbvnvBBTkA+6a5mgUcdHIzimUyx3W4P7imQAUZWX9hf3n25owrYurIvesNBIxc2RvZzxgsRrLysGYcEJG0Z9AYAWewRmhk9U6jioojG7ZjNflLT2ePR6+4h7vkUgUbuasGRy/qGx6Q3phDB2DweJWlR4Qln2VGqUiqEvQ5gkyBOpk/c3PRMWeq5IL+rn+R9bP3YHSqCVY1hF3VtmDNY1gLjuKsnGGEC5L4i2QBy+ntmgzN97u5hh4AnKjGtO1iN1EqTBopTUw1XOJWKlHq0IYadT7HY2A7F8Ihrz56kB5G4D1iwMHaEsLGuhT3d3mHHIJCCYbTv0Snej2lfHyWqL25EC61qRqfA3mpfw7Kh/XaDXJZD0dmmctRCM3KW8BRI0sThRnds1pc78/qEUVPWNaxVpJe8VgdIlyPjzHtU5EXd6WZ1RY9kCqBo/FTdcX37dZ2JZzN+DU8qICJnzQLvRq5qnzqMGUOyeGQ+evSaHTkVNzmYC2nCy6+P1c8+QIl69BGvb+h3PR874UxfUWnEOnRuOAIgdsM9GBkVm91x7XNR1Je143IvrcUbkOV6nIDkojZrJhpKNSghCc/vgRGfYbU7PAOGHrdu22ZMn4G8QYW1OTM8io1q18CkK8hYP4/2ZrAqMESgJ71XCmrxIO43dbcRB3+0tA8NWXBkixBHThE2vNeXtdcgcoRninw211YBNnCMaUjZQvzljgCZhauDXOGmIpv+LKNGd/bO3JB2ZS83NtFrrmySKoZtPcpedVuDxI7OOB6HgV2wjNqZrC4Uxx3O6W2WIXGNGMZKQML6tjZcRncziZiwYCNorHLBQBjtH8X5FZFsXdg3rhjbmgGIUTqDFQOri9t8j1oS0BhdGOsJseXuMRgi7AkpQjWiI4d5vY4cZnVyOOVcdV8DR70g9wjINUXcxw0bMxz2cAX2aFBqmbhI4Lc0BNA33D0dvBYYM4hNTgWuyHxBBgOFxm1BYNDihucDulIxRtdw/JBRqqAfAULPyRVRsUBaOOwhlCMMihTIezdrkN60WZKWKcoyw8RelGPf2U+UKkiu49jzBSk4Zj4Fn4Q4a5AwGB0qhhcc6eKOGxtc/ipAfrkzv3i7faCpId12QVSpq5875Uw1r5Hgcw5CW23GtLsn4AilNCCScZZQbEMm5Hk6rjh4rBD2wR6QlkbB0xFA6hfo05n4NZiMLJ+YqSkNqfLrmn/NjvY9EkfyH9OghvjlDc4iF7frZ7L+mg0Oq0HFmiFeTUlHdaEgeTkH0vSheFrYJJvhCofbMX3id+I784sTOhw0irAdkpCDsEfPcMTZQ9lrvxvrhChDBpkiYte18UA2GCd1+8cqd8XGnkPjoEg5A44+KY6TTGw3ryP7MeqvbxyLDHlNfw8cMKa7577uaqpdpR6JXNsWcyS2SdPa8bFzIJ+GbZ1ZkGXQ5ITXjfKZ73KsJqBc6UuhEZNG+1dpyP0BctQrpEXjSHyGl2090is8hG2YHK32CpxIviikKWOG06mTct+OucOr/5HdBg1IFKEmDYmsgOaPZlmbq0ckqW4p3iUX0snXrTcPV9WCQMmQ15w4nNuIJHFxjg5CUNmtcbNjCqzJvT1rQ/svWrS7BxHdH1fKdinV3gzhinHxievC/vXubmeBGruyWbObFLY1aAxkGv5GDx+zZWK6whqS6ZRcdjvF4VCWz1CwkNf17P/Yj0coawvnwOFukavFpQ0avXjGTJlMfmTxCZA64fF5CFdPFnOBRsoLwSMTh6O+EH94pPZUqLBkJ/fEAocLfZo8Mip4Pobka5oFXcCxGuRizIRZkw7xOw7QrzsEZEYM257hy3SKxiOE6JyKDmB3mWs7fOq2DgKL/DyFLWN2jWGvWu4tvvAQQmCN1LQNr/YUZE8IjjjF9R28xvXHA1hsjw+SSi4Kuj7j2s708B6A7fVcHcXm7Ok9LLTjtGVgnfr4pO8CdcwQGMJcS15u4gMUvWdztshN6scjN/av0o+YNFo7ixwaINeJH+q3Z37xjl13LU1n5WqVUV0wXKg14xgYh7dH4tTF1/PCXvqbiYmLDuHvYR8QOMQ9kYJmKZgycV1nsQJHil2FxRv645Z6rCk0aEhk5T9Ss4DAMU7xzFSRj5zyCPPrOtumrE7IqOhiez6u2KIjv2NBVanwHXuCEQP7V7Np7vSE3F0o+1/5kB4spKGUrb6m4+jc34amHztQyDc6AcBMpGnTHnFTj8Lhh+UKZy9UcMS+Zqd9PQfGcVXTKUWFM+YI927NGNcRx9YW80lINKgQ80BNaMbI8mFZ0DrIHI9HcdIh05h5NN70JpvvpSE03ncv2oeHt2djYBy77m0KFtL52Ak+wNLekHfa+9aQH7GoVugSw07J5cDnnkctOwHEZNqjbqGVIxwJ816klUyxYrHMmc6APE8Qn3SgmMvzKmgizrg4VqZTwNGOGNgP5D/m+OsPXE22chTzYlfYvXdN8T5n0B8Iz8cd6WbeoWILi97bDGZkI4cjJ3e7RS4ciot65ONKJ6IkhUwUJDf3/jTkOjLO2knpcD4yrjSmRPrDK+lsidBgV89CGjRkuXtA4Ide7po5kDMhdzggQWNMWCgNeTh4rQKZjzBiM+BRKhLFyI/KxnVYfmYlCzc9e4abGkT2RQ0wke4VNw2JNZNm9XEM1Zzkj8gLZOm4zuyujkTxF6qv+WoeEl97H83Xg7zDI87WO/LVnVECssexC3rPrLikSz+Go0cJZ7geZ0JuX9hLRymoruzTKfJ7xE9pyET4+jQfkKMEmy1IVgUNRLUCPKZpQiDRtKOOYWHnuGEScrmvYzyXd4BkuavHQzT+i9vaMWld7S+B8JGd1TMGyMv2NUjMp2McY/71VqqPg1A0QjRs14xA0gwasS/v9gjI92clF44f9GOnP/IlZVP7T7obAGze2cHTMz6ubEAZ6T2jgc/i60kKMLJnCbZHri0r17qRercULfAovTj6m1l7s6xY8CLDGu3KCevaI4ZkVHBdw8rANjXZA7qanjbGK1RsxsKF2plPMbpJrRSOxxz5Md3hIJJ1Byx/dR25Q0DOJyQl2M9ROAPlqUtgX4vw9cAglKWGH54Nwh7zZ+J08pEzqSCbTtkaN/jP/YCkkGaQBQxvSREHiwx4NSwSnsngzG3qyAcJ1RdGAiSfZCAxm+19ljMMnY6W4uNdAbJSoQ0ajm7PbHeABIPwaCIeAZqqnoEv5VymGN3Gbky2pkQ7Co3aIPFXacdfJV/dGb2yxrB1Xwt88Z0ROEU1dkOA1oaw1pU9vRCq5PDMyOXp2ImPp+RrPZeDEuXYJYad4PO1+cS9lRTxGR3Cz3Mw3t+D/I9hY1e1q0QCEp7lXG+IA0W+0R23qaLXYdM8XpxhCPfrWoJPtF2uECnimQSZF/UwsLUxsOPtaOULe/ZDWgcfbbeqczcWYZkjDhyhmePDuVVjyG5PcfLuuFS7Rn0h30bFAiwCNDmOHdkzFtz/aE1yEZ52Jl6tzTiEsIHsfVdXSgVorBEL2dHek8RRkOJhWE8w8pV1zbcVoTHD2gya7EiKkb3drxkeeOypSK0fIeGQFySEutyrlW0DurCqfSh7YNHkrOhKFVlmdRcuzDflqJ7RPoVyNF1IGfZCp8h+zOg1OzsCAMnZ44wj87k8YGiTkKwvLluH6P7IlW2+Hn6ryDDSzWJlPm5N+YCzXD9iYsMrQhMiEh/jLLkRnomk3LiuMWNecj9GezOQKAKVDsX2iJtNAxYdlCjJXTrGgSNoNPUY/R/5hoEtYdnh7Jz4IRqGNdtEzzGEsbM3heeIZ2dcBJLd05CKd2xmWjQHN7BFkZSLA/KgIE1Z16zb4N9aKq4j8CYrC8WRbVVXTm7FC4VDv7UB4hFma3rEo6cUJL4k5QLKyhAnNtOYLNkDutL7qAXL+3pi0sDoVjaI/HXHjnG5w3k6JlWSeGfiipduLHd4wZIzMlFYp0jtYQNB9sk4tPp7OloI8xJsEazrFURCooiXIw1yzQWJjuzYjC+FC3E+3og5MB8//fOX70W//Pn6EzD0wq6/vYG4titFbfHwhbuoCDYrTJnHS1a2OR7toBMUfp8XS7reNZYKEjCKJxQFPWcgMsWvv2Jp7zS5AgTyiux7GjaVpMMyx7KzYaUV0+cDCm0NNZn119YiNyzslE1zoKaw2CRoLlM/9GiMSkORAfCQA7DZTuDQVCWQfPOv77/55pvvP//++8+NfgOTUF7XKEYPXmuLaHS2pvgAQtbTVjZuFF9n+YztxbxOetd1JIuP1R7IiBTeecUCixANcNQZSO4QkDlRE5bFXDObwrDoX+IOGrm4cFpJwQKKbItb50wk65Zy0qW9RdMLmaM0A4glfJgm2RRoStrkWj9Sg2L5w5G6rqUhy9fz6ffffG54NJKAv46TJ/J7QKQO4kc9HO9n6uMjMiH5tMauJyoxZwqSEcLeIAHRlWTC0Y2Zis4IijJp3Bf+a2BSYNSdvcsEXdeQHsNujYjozIpON/MwzaW5rjN8DUmMCa/WjFT4rJcjKjLsmWWC4TuWIT7GGELRHdccPYdoH263tJk2Hb/Oz8q5HszCftI9DRi/kSxAIj8NDemELXOc1ddrPsWbL5KBMIu5tO0BuQ3HaCcFZQJkacg7EIkz3GLX+uK25mCKcreAdNt6ji00fNaILnZisAsV0rjxnvZa46LWRvroQi95rSzc9a4eaIz5hT+z2FAVGGJdW4SGeq7DLSni2XAvjRqxb3GGY8lIS37wJ5f1NwIge9Jvj+bk4bb2icPHpb4QGg1J9V1UkuhFttvXLrPoFdpouAcqnTJ4PW1s8/V8CdMJ1Uhihdgei7ykGt0LmVf0QGIUz9hAdvH0O4o6VMMyVo2aERjXzkQCYtQqBBzhwyPObsITbiCE9zx2VjaUsjmaaEY05EGfl8187Q4fzrh9wtXzBtqxFCO7CSVJyBDlSC1XGdUQh7XEUFDcalEhynou7RzOJSHOXgYi+SGmaUIm+tK2BJ87snIjpwIgityu2VnL+3+6O68ViYogDI9ZEREDimDArKM4uoaBNa5ivBB8/5fx/ypO2XN09MqdOt1VPXu38FPdlQFkDhzu52NpSEkT0Y101irM1o/OozNFKMnb04Ef6MfuY4/4PGS3kypvuMcKWS7mrAV3Qsb7Ea9PuMOPcNePMLkfza6W3+clqcfP3Jjh0oZNehefo0cO27wOO2Ze2gVF+FaHMxGsg9dlYq/kIz+i5DUu7SSBLzXkq4lF/D0SwFHa8qvrq8uWu4ecXDRkz+jq5nuwLL4WMAOSs8MZO4LYpx3OwqbBnPHyGa2EY5df8wU7HbDAav0ICI/gUDwyKrBqJGmX4iFswFiI/FjC4te6tIVHYJhL55XelcsnSrl8KFLh0vDYE+NgG/MV2HCpRdyQjsm/fT6yxQBkxq0HtYYEitg0IjhH05eHq2ulElmQ1TK8XI8uazoXKtLxWEZ2Ox77uu75192OVGikXiF94Y3GmeQD8wiNd8jlwh6vRxga0chQ+Z4YYBQ3NLad/bE4Q+NkX4NHVCOolJ29Qe+aywcCjnJJ4u4ZKWcVM4Scr/m47HQ9ck3rnH5w9jqUXbxva04JS0/t0UGKMN6PphhdQwJM9uHqmk29VX7I7rjXAcMxESkv7ELkKYVBU11ytbM3Baa1p4av3cOrG2kryPBDimbKWXSUUpwGOwZkvimGSxx1STvIbrl3p0+gNJsG89rACBo3AfkZ7aQyrWKGsDmFZiyrRuf1rrbLunqHIyP1cWtClyAp5skUAieCrYVarIwzfaYWb1zAMLO/+vrDr7765Pnrot3P2UV8mthOSKlGWJjVEKcEZnrFZwR71HNBUXrtCwKYbWCzRoAGGvZ1PR3tpj7iE9eJaUhxWRdDsN5/D4vG3o8ino8HELlJB2tO+n0NWZjpj64b7dC39QrIyKWAvRiux82S11ctXihmBk3EZliQ2THeMoWnoseu2TfhFTe/z+HDq0v32b1FdnjRwGMcgGSh76RXSqxu1zxnD1fyoxe8loGtvywasgte3eXjraSmLxw/j4TyzOiPawYNrnGyzTr9kU1URlik2lUeSPC458JOI3uTPq2RH99SOjOM6+4HMNrjLrHr6m8GDAXLnF+4nY57kpTLYWbkoh1xiL8KAj2OLS4ClBjZX11dqGbX44aBX5z5YdrRZrziChcoq4sPsgQ7CUfkaX3hrb0dYbeZSbFxYQ/y6Ax7VHPBLEyIhS0mPNISgITc6G+W/Sn4hEVt3dcHrmpIiOTbJrRiGTL+ahyE+3HLuu48Ci02RL5Z0zoB25Zb1x6fWc0Z0AgS2ShGDjDo8PXhq8PhyjzjO16PjcIxwdDjhUBRvBUkNK9uWAdpWjtGvYKrR2tydrb8GgG5gjQ0GjsObw9tzV6JrlIiPI4x6kNExUIaNAKjhQvZP1nsWqt14zbdCIavez1X0ehHWqPYt+q5pCRH9QyX9hYoPckM3u5wu7NDO9rnZoxpRC/ELksb9XiQgjxcmSMSDZkh7FmNXUY2OISNUR9wvpFxNh6Psd3jIxt7Y4DhKC+0C3tmU3Q2rrjwGAM/BEhiM+HuCVRGwjjmDEORCBce+PCJw/8JkdzWXrPAFonXoC4ua76NgUhmYJPokwk+hkRhcms8F/xTqDVjVnaZRcP9LI4QFonMwNIp/tUNYNSPw5U5InfVqTl4YPEFhHjczdg006ppI7ujMx3Dvs0r+3P0I56fjUYA4sjAosRoZx8/QCKYVNjw6OrRaq8JFuLwqf4Ud5Lad3Q3YyaS60duax6S/0yf9pCF1cSOK3ulpZUUC3+PmOvI7R4+nnPGPt/UHpXoDnEJItgsPr0eD4evvj58eG2OyJ33k+LzNcwZbmtAOWdpwpPmmAV4V9DQwEdQhDIsM9EIZ4FDPq0RmzkKk8cCJIqxetm/aQ5xv6kxagREUAm/U1MpEirCvjbzes8u2nb9+JWtb9YsVD6uxGwj/oF9gNB94d2uWWuicU0Rd5fPCkiPz4T/0RQjB1FGD3VdS0V+dfjw+vw+WNm2nM2KBcpdR8NwNn8Yr8dqAemsknsyPZyV9vVS8wpDQEJiKEjx4YKUAzKG0AiNMmPoAqkl/ZjWtTjdSCGGDRPAxh/uAcP9JfSd9kujQcWYN6x1toDGAck8dnGvw/ZIYfcDEDjXCI2/H1+kr9k68uNGW8xc4Wz3g38dvwVDkQSHw5X5fXZjaBzMNaPLrpwZ9Vwi2dPa4l3vCuOk+/rWqwtFyn7siGFIjhOUaEZYV2AfJeBHRnRZfo+O2gCS8Qrv4YK0AHbhEctaJ6ER4v2IfrR0s0vQyH6xG+75oXNyRcaXflIemkkwsu26tsPa3qwSzmwJlj2haw0WZvw6snL5G5DUVa27Gh359Ve6u6/LzN4ZHGcOpMcK36p2Ur7YBcuWpSFHxSuINB9kDhpuLHLIBEg2FL2aI0ATwOx4oanGL8gRx6SRThSLgR9oyKSPOb8v6fpRZPe1+D/iUR/rB+7rjlzPLpDVr3mGrwVCCSCY8z4sA5KfmwFsMOgO8bKvG462oYgORnjGy14ldF1rfXiAI67LzN4VGNnV+pFfAJCYocScpMmPzkOrKhp40W16ed7w/o+ejruZBIlNDR7Xmi4ihe7s+QIw6rMiQ1SkJ5yZmX1n5TM8Ht+TNXOX6bgZmrlARYr233327WglVWdYvxznCJr08eSMV2KFiFCRWzO6AGQNHJ4UFTT2dNQ5ASlmsPyKX+GE5O6+Lqtml4qRr1YXK7w2AoWzkmb0s4cy1wyy8Vzi3jLlTFruX9PDaz7XTKrwai4xnTxH3O3rY04aZgNHMEn5jDb2jGlHAHnZGxINqV3RwsajmzJeQrNdQ8ONHVqyi6/XnIoqL+TCLo+PVXUlGRoxYGDhCcf9GDFDPRrBpqDIAxK2f/6aSIAc7cN5ProwhziUol+T/dfZFIDVbe3N2TN94bcNRfgYqClRNkzb2TG/UJz9Bc5H3OFknEUj+8BjVHQpWviex2cMiYQNL9CQ34FGPn88zmZ7YHHLokEtip+mhgNMi2GfrefiqkZmKdfq7xHexCDDI/ADjJDb29zUeMUxbQ5ah6uyavLKBox1EPC65nXWdXWzlEFdQkPY2p6Q3mxvbVARprXk0JARomEf1SMXVPrm0ej+cOVU4PLxCuxu1szBbRpejzp6/Dou7EssGj6RmDfuYY2ru8yZtT1FBwxr7HAPodkgzOvp6gkVaYY1wtHHChs7pMDopvXXuq4l4ddl1WBlj+KugGVowNfivTjDhoXHvsLHRHYrwGax06JeMdn0JSuv6mMlVCDJ7WH09SvAklYAcomLZ05PZ1Tcxa195/b13pJ7JC6h74IAZCASVrOvtwKG6e3JaezAELGBw9SSFjN0HIq6dqY2l3VoR5AIM/612TQ3HxoQtVGRh+uK1ey6HUA2bK603G5qhhjp4euFnWQdKnyoZjwdG5Rds9DpZh4x5A05+1Mc06SRs0f7GA5IqmaOAUQtqKayU7Jw5/FrtKM9IS+mAiQ9zur5WBM1DZb4e2Y6BTznK8BSM/5NlrhlneVghXljC4glqVCgZsYejmIOzIOORGkERFu/iV9Xjq4DUjsvbMvG7SYpsAbgzDQbJQtlzXisMLzg0TNlCV/DkjBnFk94IJL8W3QikWu84Th88Ik76VjhGQUMsa7fuwOPvBpRj5ciEW5ymDSgEVQ2DPuEGYN6jEqFuLXDIX72/egBbFb0tAeUDcuqeBXyPEkc6ImjGSEC2DgfgSNkKhI8XtcjMt6Q2jAAyWkkUHSIZjYlRWS35iYACQJ9AA3sXBRby2sV0I0WoNHiNFr40E0KJEbFK0fXjBLxdLzzgywZCxeafW2INBfkBT6fej5Cih3W0Dj25gxs8IiChBk0q394jS/cjhkOg2Y0bEYzsuzViACHnp9biCRNHAKKJq8rAw1AVo6PwAhJjjejTuPXaB5eOrJzIJn5ITwuaLztAsOuVRiXNTBs4uWIF1LLWj9ah9yYOiymBeODvPMj/h6IoOEF1vV38EbkN5YDqeXMsIhc8chGO4qVje0+ni3vI0jklIEZ+CTUogk3qx2EcXXj6YG3u8dt7E+Eyqt6RO56+HCNdxUb+WXs2SoX3uWuEMLMGZ+JBBC9rdS4rm/TmmF3RZdWeSB7wKt5fPA+RgIkDvHjMRPNTLBsWJyI/uFmzzQg/wmOpSOTPj3ND+dzRJ7FY3QhbVhymoHrVTVWSVfGsDmhHJ26dY8HCdO2MYCiHQ+uHGNBAPK756+HdiMB8p23gJppyuGAHAJIdkZuJ/cIhiQ/+rThbOADKBOOxvQNPL5SsUJYuHoCkgDxPTEyxM205jeQ9C7i/nikYEHmDCEa6UcsGbECo87/6PCRDHrJksRhkMSIW68tm0tDRu+eTTB2+qOxv9gyUVz4qs1E+jr8PG7FIIDoIXw+vjBq8r7G4r6iMoZdFxe+46a1Z/n0+7EO2Z6iLewlYkiumfRk1HCBRcR8OyKCPOFsEHBsl497xN8TGhmpaaO6vFohKgzvfMSCMsTVxYf6a8hsbHB4sf8RAR2GNSP1uHFb9yMyawvB5awvXCHpSRWda4bPZxjY+tIdjnRnDye23dLU0EiYkf2b4fE3wfGTa8oa351Y2K4aR6wa2bBEAD/4cPloQcJhzKCBGodrwLATfFCPtlCVlpF75OXoGvK99Pe8x7IZNCARyuGFH4sByvQ/Wgn2nnXJExIoNv1Qz0ePz2wWYINGm4k0hsUZNP+OEo1ZQAODcuaHuF/axkEmr0cWOLzRBpaoRBaHT34Dj9eUpLvrds3sdPmIdR5kA5JTuXrYIuRtuXxQixGdWZJyu/6649dswFjzr8v/KMLl4xULANE1YwdptCw8gyS/56eMX3uE5pIXJIA05vTTTO/58e9qunpgnGFycT6uHQEin2I1aKpqwYPYbCExu6U4NFGHGNmWKA4UQaIDU/uKHD+7agPpURlsmgLh6CXVVLa1obHUY1Vhg0ZfRfOqrhdk1buyj7XleEQqUohq5Jo+WlaP9tHjMr7vWKoyZAS254eH+1ESugCQEAK66QTxyjRD+nEOdwWS5eyJcKFkXdirC1JkHh/171nIYUgcxggswuD88qQKMRCpgzZg5Lo2aP72yfU4fqQhG5KA0XDZKeFdU7jaNl1gGA9ILQI1YWHPPFxW98dl80U1F+sYUUP/yKg4Erj2u1pHhtFENkU3BvDJ13dWXwihHv9Vjnji8XdMmpMHpFgBETngaLnh1STXK2fgCK2lH2lPV5jVXGjGEK4JDZHhDw+vDwxfuKTAGNbMb+KsoGu6s3eRARkzaLBmgOPoB7BQuXm6xRleR2LYhcU1o0KMDwKLrMAjSBQre4bsR8Ni9O8BlCeOnibCM7qusz8Fd7Xtf47OlPux6Yewr9lrPddPAcdsCtDxGR81jNwOYTsgs9xVOxvkBihDFUa35nQ9Slrdq7l7tKCAIeKTr7QPn4hdUbBmZ/7wtwCjDuCw347J+Nm/ACCHcoxnuStwjMSK29vFup7XNSuiNN3+MQ5UF9Ky+egtAYCkFdGM/HCX78vApqW9+8M/qwDNJTTQKBW5f6mjhkJjhgzhw8YOM8a5xwvZm04fYGgGNqdWjX64ya5SwmP2skdT5g+Y51fInAGVjkwZMzpiYOv4yeGagjW7t3rWB58D0DE4AtrsqsD2Ve1IwaM5H20ItudU3MLHrT1u7MzInYRSFCLRjgZHwdCb7+k00h+1CF9LfoyFnf0fDYsSF5jXYoimnjzzIyXYSRORAUcY26zrCM/oj+eVY0+eYTUcWcBQqNSSUozEHi12+MdNUYYjkus6LBrQ6EyI1LqaO9v9kJaMy4a6eoYd4BypZ/bBasIrHp9oTzHSw4f/sTulRIxGJ9aIXyPsCenDNClY8InstMmtITTSjNo2WaHqXYEkmDxcoB2NQUuQBnsGdtYDGc7wgKNAiODw9y0go3iGrY+kM1i+IXk8wiQqDTcjh1zY/Gs4wzt2DUNFgkTYNd3ZuxxhGJ7HITglj7Y9EBLeRa/UX1ugJmOFt6ygMGjgcV0LhjEDO43stLCpLtQVrX2UgiQyQ7M9gTF7nAUXGinnElMlDfnhqMe2Z+AXmNdNv/9Ql7W3lPqpC7qmga0tFuZMD2Rnn7+w0ZOAcYZnQOVNTGXXEgqlLQOVCUjYAYNbdrX+5uqxGFe1lgh+Nb7xHa5w292UYlYqsLfMGjahGeuWki9HjuztnvY9SzPk8Tg72nNdi4AiSBQ0BcJjXtcu76JRrtXPVAbkv0qAbHo1HeLhfPxxo+MeoMxLWzyakSK2KBr4QI1JVjsgvXZLrAhV2UZ2KEaYvt9CO2qZunRgXk1S5E6mDCQun3gHZFiBy/jR068ReV8DSJFVX0fJwvBBCn/whKTVFnrSWVYsAEa2Y5KMM25pFga2IZLbWqy8PSIbgM3zMfqlcFfbvjhiOPHYtHlf4+lJb3gx6l03XOFwmFszvsUrcGj1M1HsGsUKSBPREgB7++CAzCxIUnJDLxocc1+LWcOVTbRw5vPkH3o4F7Iu6qowZMua4Z7uFhU6zpIuWOY/+lXd2T2z7d57R7iVKdi8uKyeoTWpUTfIJQMy+pvhfrzUtA7lOEH5w2lP+/CGb1UYtsMnYtjbwRmb9JEBmqTuU4FmtJihxE2bMfaJ3MChoAv+YRgxcDnCHY4Qr0joWnLQdp4EmUqRb/jEG5DdVArWDSCdBD9Bs9zhq0nT/h4u7YHGbGkvowX1KI+Pd/ChCJtwoXY7fKQc3eHjDnHDo1k0lxjXrSEnHmsEtshAuUGhIYFjZvhsplOEPaO9WNhV75pGjKAZCtF+SYoBUqoLQz0icYjXPa0zwOQI21+HWbPDntEu/yNrRq/HEOyasNA97fmg+XQElu0K18ku7NKTc6SmVV3zgUpziNsv9WtGRoMzPteOwuT7PvGD92O4HmGX+B4RTb8Lj6MIm8rX6REv9dgzkYx1B/HtjFw2UOyEiravfVmP3AgcOgwl8h1JLgXaEQnp2UgIGyX5m1/YsMDldZg1HqkpT/hIC4e9MWuwa+QwyjGekKjGGIrkqJyX9TrgdWScHZPTncJa7gmOlL0SvKaYRhLSoSxsPrr4EC88QHu/sy9uCdA08TjV4zpQ0+ciGSH6AYnYiM9kQ9K+rDto6PFqPu8FACYrWxxPuKzr9Pb8ZiyuaQAYmlHCAfnrVahIXdnZInegkePA5ugdblDEBQ5jZcnr1JCAEVw2GtGRqRlLfsE6CokRmFFkhjejjjSUMhi6p8fTe2hQwcnze2zcB2gUu8CaCT252jPZ32zQOnbY3Y+AsWzshaqYK+fPgEcyfLLyNSM0MCh1og/9QAiZhw9vgCQUT0eE2demKgOOMEfodWRYcGVnKkX7wf1r89rfjPB2Pd4iBTwJWpyFVmzzekawv0wjGzN7VZICIg33gKRpSOv/iGokAU0HUafkYswASPBotQqXdgQAiqt+7JqFH3MK9jlCNbrLhy/u6g82lKNN+0A4Hl1Rsjtm+DXsBuqEXHimVRzMmon2FBkwPFgIW0bNb64gnQKZV+H52Qlso2tKe344lDFTd3Y024vSa6DouhG2+h5zoxzZVVp41J79HwGlNjaNNUqJ2sL3ED1xWLYMLaVEbwqP3hHg8prXETDkAflD5z+GOEN+VVc2bnfK3co00/b7ui9pTkU2EEm7eqaYid3txKPPnpQkF3bgkTvbFKTej/1ydIaSvBLPz46IYU+/bv9jq8yKX48JNEARNRkPxxJdfT3Lr4nNhIENJJt4Ob6n5ZMVFKI5HqUeC4lQuiBJe+TX+3fvZbwwZ36IX3Jhs3RoPCb5QHZu7TWfgm1NfDx8TXoPh8jvkVjua/f5pLunNWPTjQ14dbVok6/t48BfLLtHiDQIwi1DHCyCPPF4QSL6QXkVAe1dxLADkrMXZOXhIiU4wDIfF1h2f4pBt+YP54PMG+5ILKsGVw8MKeYlr+/psx5nIgLYUbIQqLQtVFa/Zp8YJ/mf4jPgsRUkwcLMy50UapFbO47eAVJ7s3qm/DwctMe0YUgtpbBjvNFZJENCZtj4kRxxjxdC5vUxKizy+Yqb+wqKvXbZxQdEllpsTFaqGZQT2SXBIpd1DETyxe7Ka4kuMBRl+x6oJTAUOypqGP3NVNBl7ZoNip0gHuPiJGkJEP1xLUWc9V/iMzelHMULj9DqDce8FjItNRz2dx7IeERq8xGUcXi2+1HsBhkzFsKkyW4A+kF4hp01CvC0ZOzGTvdj2tjQVeT87Lq8MG7rHseub7TagzJeKAXp/QCsh091yYWzPWBYcNTnL0i2q8UQ7C/8vgaSR1IgPTv8SFKuVqJRpPY9qlegA6T0Y6SHx7Dhy3Xj6u/58W8b7nFZC5ClH6NRCjf2Fii5r83IzqYAs5wrp8YByuzeIx5aUg/Iw9dc1zRu7mwzbOu4rQGirwSklvZVGNq7UTsTrA2cvrU5pG40BiZhlVABaypA9gCabGg/STh8DzNbJ0D5pvh75D9SRhNtKVxTMuGVeR92X7tpDUNeBshp0PyS07Ap5/o7b49PjQtn+OkAbD9P6n7NaMUe7jopYoQgESh66LqChwdubYNk6EgY2hFsOhxP3JHOr0ZF7qrvY8dl+JOjsa9sM6/TvrYBC7wgRS97VsWKxKKKX0cCZDSzj3QzQoXW4QwS9o7i3r657mtQ6Z32JOngE/3NxMDjZfWFEHzx96AWxefjcR3xqmXKUSyv7K0nJFCEVerjtGWQVYJdQZrwRh5uLLtHv2Hh7wGLzg6lHqFQjw3IKzC0d/lmZC3xms7DRZS353OAGcFCODQ6powhht6NtHLOKv/RvY+g0+e7IkjKtYkfZJxxrpbNdKi4U/RaRo3lh18QvZ6gnB7xX2oGDfaMw3KzQW50qHC1WAUL289HfeV45DAx6QkVeUdb6ll2qzBECoiAsMHIVc3b0fAXeyDxml6Ru0AjDOqf7YbMy9p0YjSTon7GDZpM7cnozOiYAhhZOX9GAjDGZR32zNEyzUxD4vA5HnNcXFK8I8376PYMocIIXgPLi4sLWz92friWGtlLnk2lMBWJFIHL6Bu+nfxorL3gLVMzYmF7Onjc15UEKSiGSQMyvQTbqq+zaqGsmUJh/ERC9/8VuQsbJrVj/jjp/WhM3MkQ+Tk999olDhgh5JqRK50IlzhHzF7Xna3FgAUtoPdFQzHC2DJnZNJ4P9II0ER05iIPpEhywSPWNWurP66Wm9dlzgBJiU3ixq4iGtapYtRGkgRpKHSeU9m10JE2Lw7vI7a1Ldviv1W9QkVnXATtYb/f84j2Lk1s4746XOh0Orswiq9RjNFEnGNS60cWhIL0EDYmds0vPGYDH+xqEWDU2asWgCQ4PBr3RTcp3dduz0ChIC+IGYLAjXghbLoeOfV9zQKQoNGA2Blnm2jMkcPZsxmZmMTjk51Sou+jQzGA6UVdnm8GIt39CAS7oMt/IdkQnA2790k/btSAyNmnGY6AtTscQEbe4y1PSVeP7X4s3t4elvYMz0D4w8nIjf5mQp3h8j2JTO1B6CCiQS7zNHN+IakUBsV/AmOyc/6ebrWHWPPDTUY7e5DoUxbauoZNzSgWZs2wrjklJOOiJv+xotcw4U+nAw2l2EHoxUzygX3CHok+RfuU99s7nm9ICWggspqlcEyi3tUVY1UZriHszvCBG42ZwxmhgfOCZBGiETYNgNTQJCT99LFFDKM/rjt9ApT6Lk85m/FCw+NGfCbc4N0BMqAIbbfd48nIJ1/4X6sVqkWuBFoyu5LqLAYX/KyU64BRwyFBmYHDQGKZNmnNwJrud+r4LnN6JiQzgl0GdlH1AMAjboRI8zqc4nPiR2Nwyo+sgsbjhAbFLzKjIi7qyDmTYnzfp3T5fb2373BBgzO7q+NU9nWOWMjH42bLPVDoaExQAsltQKZtDc0hrx+6K5wamq8djFU+w4fGRGUSK2RGF51JD54CiYb8LZPM4Hy2OHPaFx6vwq7ZhWk9mlOEFYMo5WiCTnvUYEMbLVOMZbkrt3XVFsKOpzFD/OGWUQET/rC3u7dZEHFCfqntntUraDkkL0w2g6VuhG7S+9gFNKt+zNejPSARZsdwX3NasimccWNH7LrgOOsLwSQMTAYOiWS7XS0oSjN6S/vKN4uHI7d1XdaxEp6T7r1ds6uUCnbjseEIEtPlQ8jQBmr2sI+mKr/uAhqj6ic1W9pjwwiRHi6UMSOqRlJ8EaKJG5uhSOhHfaLocHbhlNf1/eieR1DIj7P+xzCyM0ITOZBbytFKZzgEEhH4xMuk8eg1Xh8+CN1Y/ZqJyogfbrztHkoSzfhV3tCc6p5mL2rxWi5tAAkks0szzvA12SfTHwliiyr3ET7ptH9PDRteLRoa+GBXi4hev6kfbsfQzh4G0Z4CjHqTM+ZzdTEX7CIsnsnv6YSKGqW53tdAEH9PdYDkhJZcsBhwDKOGAYZFs5+UuFsw+W6UqBJsfoPDmKmpHnsoSEya8WRs7gzJ3hcaf/3kk/uc9ZPJFUzS1B61XLAQUo6WFW7ZPVgy7AnE4P14BIc6pGZ0eWS9p2VAdI+PRbCJGAJG8Ji99uTs0QHno+X3dINcS8vl+E/3tcTAI2icIUNENRLv/o9EsKOTjwVptKHVA+ljkLCuHZOmFBGwJqERlj3DnaInJKrS72zvRsrHYptt3YUKHAuIsVb69R7nju8yLIOYBg3U9zXeHrw+lZELW+chjZquAuPocYYRAyo97ZFm9tjX3jecF2T4fDhgyNxBOY/dO6bg77msZfPE5M3sBsDCrlkekG5foyVPnD459eNswSuYI1McSPbzsZpA+gzD0wmadozXJHiMTIo0Z7x9eIWvA4fjuuaEXOh+OyN3j8RAJAtc69QzP7RZ8okTnbHwtdszI70HNnpABpl2nJM+4EcwSQdxBrJT9AocrZgLuyaBCKeBuPdrpuY14tdra4rLO/gMfw8JPmT6rJe129OedgZlV7PUjqtNoy+62bODlpxcLuwAY/Tdw6QxPzgOSJ/Vnu6ezMg1Vdmu7zCt53W9/4t6/PWTe3xpP7F7qp2PGS5sx/jpxDjojdEvZdIYf+3Zj6Cy03ELl0yf0eLWjqJXc4Zri/CKV8BQvh7Sw7mvgSPa0fh/AiR4nA7xrYwK140wz6oQ34rMjB5n0DrBsHuSBhJNK+YPmAVneEYeqH0NNLpw9diux1SOs8Sr0Rhsf18t7Wd2j/ptPXMsHIkmbv0DjOb3cdcj78jG5GwI8GXY1unyIZ2CkGG0SaFYwXEYJPOmygr94oawZxQqfI9xcZ5P4QOHJS4vV2B3/uMJBRTPWjRc11k145c1tJUA+WrWK2Q/AFZhMazqjF+TkdseHzBJ2qME3R8JXxOjiWSKiByme2eCcGJxpV/vq6X92O7hdkO2o+ekZcptV3X5TE13+axPSBGsBiIlKpcZhl8YLNGPWu8drQ5bx0qlsO/OjWtej/Tb897hgcgLCRhOf3iD0dk6dzgKZ8TD1dN5Z6Bvu6F9ABLRIRqLyYg1MgnJBBrRjXlla1vd69c9DwlmK2B4enF3+tkKRO7sva7tX++ne/zp3ZOzSymsr2pYj0QyQ1tyxmfmuOH2PwYSa+JH39dU0Ph0Lvr3gEs3r4/H9kP6whtOveuhGoh/9h/Sw7uB+I/a8XTUoWm6IKMlAJ+1gNyGJHjMNyRwxPe49tsDiDnCMFJxHZ6cGKZJ1UKl9oilq0d/GHlmMATbOQ/IlYTIT/bf3ctn5HO73SOz72MmQVakEG7de0gPx+uztO+BhnbUR06uQVFrVNBYtFA4xB9OIZdpSmbFZd9HyAS9KbxfCj7wHPpxAYHFzX57aEd4WdeI1cYWh3A82upA9iShEBVZDe3Rj9OYIRvXjGkAGZPY8yUpnQgqKcDu0PVv4FIi26bAJFpJIu285+di0oDGT/b7T/64h8/IJ3a73cOdCtn+Ry3IJyLRGJegIeYM+8x8rkHZnsIACHMuKewJjtFNSuQJ4rq3sWbiIdlxmo/z/RgJFaDxckDCup9Uz3flouZwtgI7euMi3b7OQV2d3rNqyKWHeA/V1LY7O82Xm7qz2Vq0asbgPmTao3c4y2TcurD5CpDnb+o87vl+3e9/vYfPyGcFyAdejgv7jWCns4bDwrZEyLJiRg0NqnGa2CjH4FDGDCkqlEAh6sqmRoEqbFEPQ6pkMx1J79F4hbSvo2fzpY9H9tKv+cea8Bq0grIyKaLgFbE5Dclt608LklVgmNJChTH0I/w9X3dKrooLkbweM7cH7q5wYNlqcUkTd0IPQhOOQuOvAHJ/D7MsHtiJHhQQuyGpk1dgR28zfZ4D2Zi8tcP6hKT8Wgscdslrsy/EXEfifyRSCBgtSNPp4fSzf5+Es+xnnxk+NJW6CI+s6Q/P+a6hHH/aej2iHUEjG+FJuVvtw9ngsjTjuYFxqMebGEIT85DctjGLW5c1fcR7HjsS1ZhUGOx8XFYcA4b6fAmHHPY6Y9jct2fkYzvogUdOMs8q+5Ed1a5uXIuXR/x2OsNZTvF6HP2kjl2tABaPcN3YKlcQRbUCJa/Z4gwLG/9jxgv12QKOl87AnnjsgUgGx9W6/qDva9OJPRFJP7d6QIJF9GLsMmPqcMOHfoyUHpg3bI6iGvqb4fEBh1KTfD6SHawBzIJm39jN5qXNFxe2wdGM7XvmjXxCChJ6PDs2I9msW8OkwdFGz+jYwRl4TxvueoXKOKsM8YakQJgzNfGH06HCJyxITUaZQuSGs/E/Yl/H63GJXG8jMr5hXwcYuxnASq4cq0Ou68ft8QokUmRDKVbDsAkwIoBhYBIkxvvR0SmzBkiWn4dHZELRKGXX0iStkERg0vCKFBci75dh8/gu6EHu7FHTVdM+XnaX+FSQsFaRnf8Ief8e+IzQWDdSYdIqXgVOCQvPoCIFyELknd3UdzZw2PLNsmLhguj10v7x93o/JiR/2mq3h2YU9xaQ2drM2IZ69P6PZc1sNASQRzz6pUgYCu0U4ivvTSGzBg5VxLoyz+AmXG6g0fWjJHjc+5/2WvepLJYL2+mhRw2QXV5oxjUSW4a6mYphd4fcLi6EBUV0hg9xbN8jgqZ7aV9jW/ucVxv74d0AACVLIZqMF0ozWtFrGDYXUJjYv//++8ingHwGzfmC12y5l4EaN63PW9efujkjkZc1RszST8phiE2DXiRynWPZMWkMjsRnfCgSy1N7RkLFJ34c6nEzIZIHJExLTDryPpnajz20O0EkOjKGX1s6BUeKFMgPf5kNnUvxafMaOCKTTp+RqMYjShEs6hMQ0YzZ30yHVJKEr23CK/ZMVWCjISUvKOhCLPMVklo3roDszEctGFf2kh8OAcRAJJrRGJJTk2f4eM9mmG9AGVWG2Df08Tm4SZMMgodyjBVsDV43GJ0DR39A4vkR3ZfEH8NjI/LBMXuGfctnj0d3+fitzeG21ONQkeAxfOGw2REA9fgRE7o8NBNj2VGPWlVgeGeQ1I3t+biWGx4wdPH3iNzqB9DR62WGYeIRBhoTkQAxutqfe0DCqjVFWzQ6RnCGBEgAmZM+/NqWcCR+pfPhgGM8cGjiE6pnOJhZE6BcteD6eiwsgkSWTuCR757EECcesWweMTwWfW4XNgjU2Z+PsLUVADLJ+pvlnV31M2ZX06ECTeljFYREqclMNut4Ift9++360Yq5vJP4RfYMa8Rnvu/xrgbCczYNGPQqwy4w5L4WO3td89FuL5RjFyoAzLqyBUJiNJ0EWRniHCmfOVgI233h8N+i6LVNGgRrbQgw0Yg2xP1ogRo3Z/QnSPw+IPKJsmeaHnhQ0OOyTkJBapldI7Y0tB/zXfkiP7xTw2ECIg0BQGR0ENcix4wANnULkGNTJKPGxn1QX5gdm2H/qoFP54ePAM1mdWFrRxOuFrfrC3vUB6wHanb1jNDoChLqTIo0tYVBacnKCs8OPgZHzBkyINfuPXlYNaQpRFscUItOv4LK73799bv/PSIfM3/PCsmHHzF/TyyUI9YMCwwu5vXbcCRIrBi2dzgDjRnDjvxH7wigHbFDV4zCpsjCM/geSfGxfNwYiCQBuzy/Z+Sb4YGMaR9rtLDByJaO7CZnm+M04/VoLGhx+dxgzogDRJFP+0BHijytgrta+wCDopOUJeTqrF+Idn+zmqapLQC61kQIiglIf0HCvtv/vxH5xLPAcYOefPjRpx55Oa5sIAkiPStXbKlYaHuGhftxOsMJX3NEPYJBQZFSVySBQ08OFwvBbFfhkfs6E85E1gzgYu3ITv1YFYYMQ9rquNcdcssDGeOvz1vXPfCDL7s1l468CU8Piw/i+WjDPozh5oFL6L/jERmpFN0kZekeLgnqCppNXNPO9+IGSF6RQTpDv/9PQzZPPPPY089NBP4JjmnU5hqtKnwAAAAASUVORK5CYII=);

			.img-box {
				right: 14rpx;
				bottom: 14rpx;
			}

			.gocom_btn {
				background: linear-gradient(90deg, #FFB052 0%, #FE961A 100%);
			}
		}
	}
</style>
